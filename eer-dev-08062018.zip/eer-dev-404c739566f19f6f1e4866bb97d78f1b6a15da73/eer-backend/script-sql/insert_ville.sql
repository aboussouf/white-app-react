insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KENITRA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MEKNES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SAFI','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TAROUDANT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MOHAMMEDIA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','NADOR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','BERKANE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','OUJDA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','INEZGANE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TIZNIT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TETOUAN','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KASBA TADLA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','BENI MELLAL','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','OULED TEIMA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MOHAMMEDIA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MONT AROUIT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KENITRA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','EL JADIDA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TEMARA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KHEMISSET','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AIT MELLOUL','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SALE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TIFLEFT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KHOURIBGA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MIDAR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TAZA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SIDI SLIMANE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MEKNES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AL HOCEIMA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MEKNES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','OUARZAZATE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','OUJDA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','LARACHE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','BERRECHID','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','NADOR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MEKNES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MEKNES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SALE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MOHAMMEDIA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SETTAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KENITRA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','LAAYOUNE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TETOUAN','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','ESSAOUIRA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KELAA DES  SRAGHNA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SALE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SALE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','EL JADIDA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KENITRA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TEMARA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TAROUDANT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FNIDEQ','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MEKNES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TETOUAN','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TETOUAN','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','BIOUGRA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TETOUAN','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AIT BAHA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TEMARA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','OUJDA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','LARACHE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','EL JADIDA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','BERKANE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SALE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','OUJDA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MEKNES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MEKNES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TETOUAN','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','ERRACHIDIA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','OUJDA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TEMARA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','OUJDA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MEKNES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SAFI','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','DEROUA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TEMARA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KHOURIBGA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','ZGHANGHAN','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KENITRA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SAFI','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TAOURIRT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','BENI MELLAL','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','OUJDA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','BEN SLIMANE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','ESSAOUIRA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','EL JADIDA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TAMESNA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KENITRA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SKHIRAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','BENI MELLAL','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SALE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SIDI KACEM','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FKIH BEN SALAH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','OUED ZEM','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','NADOR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SAIDIA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','GUERCIF','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','DRIOUCH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TAZA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SALE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MOHAMMEDIA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SALE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KENITRA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TEMARA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TEMARA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SALE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','NADOR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MOHAMMEDIA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TIT MELLIL','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','INEZGANE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SALE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MEKNES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SETTAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SEBT OULAD NEMMA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','BERRECHID','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AIT MELLOUL','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','FES','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','GUELMIM','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','EL JADIDA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AZEMMOUR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SALE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SIDI BENNOUR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','HAD SOUALEM','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SALE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KSAR EL KEBIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARTIL','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TETOUAN','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SEFROU','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','BENGUERIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KHENIFRA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','DCHEIRA JIHADIA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AZROU','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CHAOUEN','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','OUJDA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','BOUZNIKA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TIZNIT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TANGER','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','LAAYOUNE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KENITRA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','GUELMIM','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','RABAT','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','BENI MELLAL','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','ESSAOUIRA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','DAKHLA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','BOUSKOURA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AIT MELLOUL','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MOHAMMEDIA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','EL JADIDA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','AGADIR','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KHOURIBGA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KELAA DES  SRAGHNA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MOHAMMEDIA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','KENITRA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','TETOUAN','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','BERRECHID');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','MARRAKECH','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','SALE','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
insert into ville (
        idville ,
        latitude,
        libelle,
        longitude
    )  values ( nextval('id_ville_seq'),'','CASABLANCA','');
commit ; 
