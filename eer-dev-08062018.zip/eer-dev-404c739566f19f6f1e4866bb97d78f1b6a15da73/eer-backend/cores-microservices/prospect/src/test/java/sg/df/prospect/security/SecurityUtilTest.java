package sg.df.prospect.security;

import org.junit.Test;

import static org.junit.Assert.*;

public class SecurityUtilTest {

    @Test
    public void generatePassword() {
    }
}