package sg.df.prospect.resource;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import sg.df.prospect.dto.ProspectDTO;
import sg.df.prospect.service.ProspectService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.apache.http.entity.ContentType.APPLICATION_JSON;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@WebMvcTest(ProspectResource.class)
@RunWith(SpringRunner.class)
public class ProspectResourceTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private ProspectService prospectService ;
    @MockBean
    ProspectResource.GeolocClient geolocClient;

    @Autowired
    private ProspectResource prospectResource;

    @WithMockUser
    @Test
    public void findProspect() throws Exception {
        //Given
        MediaType halJson = MediaType.parseMediaType("application/hal+json;charset=UTF-8") ;
        Long idProspect = 1l ;
        ProspectDTO prospectDTO = ProspectDTO.builder().firstName("firstName").lastName("lastName").address("adresss").idProspect(idProspect).build();
        //when
        when(prospectService.findOne(idProspect)).thenReturn(prospectDTO) ;
        //then
        mvc.perform(get("/"+idProspect))
                .andDo(print()).
                andExpect(status().isOk())
                .andExpect(content().contentType(halJson))
                .andExpect(jsonPath("$.idProspect", is(1)))
                .andExpect(jsonPath("$.firstName", is("firstName")))
                .andExpect(jsonPath("$.lastName", is("lastName")))
                .andExpect(jsonPath("$.address", is("adresss")))
                .andExpect(jsonPath("$.lastName", is("lastName"))) ;

    }

    @WithMockUser
    @Test
    public void identifiantProspect() throws Exception {
        //Given
        MediaType halJson = MediaType.parseMediaType("application/hal+json;charset=UTF-8") ;
        Long idProspect = 1l ;
        String identifiantProspect = "string";
        ProspectDTO prospectDTO = ProspectDTO.builder().firstName("firstName").lastName("lastName").address("adresss")
                                    .idProspect(idProspect)
                                    .identifiantProspect(identifiantProspect).build();
        //when
        when(prospectService.findByIdentifiantProspect(identifiantProspect)).thenReturn(prospectDTO) ;
        //then
        mvc.perform(get("/identifiant/"+identifiantProspect))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(halJson))
                .andExpect(jsonPath("$.idProspect", is(1)))
                .andExpect(jsonPath("$.firstName", is("firstName")))
                .andExpect(jsonPath("$.lastName", is("lastName")))
                .andExpect(jsonPath("$.address", is("adresss")))
                .andExpect(jsonPath("$.lastName", is("lastName")))
                .andExpect(jsonPath("$.identifiantProspect", is("string")));

    }


    @WithMockUser
    @Test
    public void prospects() throws Exception {
        //Given
        MediaType halJson = MediaType.parseMediaType("application/hal+json;charset=UTF-8") ;
        List<ProspectDTO> prospectDTO = new ArrayList<ProspectDTO>();
        ProspectDTO prospectDTO1 = ProspectDTO.builder().firstName("firstName").lastName("lastName").address("adresss")
                .idProspect(1L)
                .identifiantProspect("string").build();
        ProspectDTO prospectDTO2 = ProspectDTO.builder().firstName("firstName").lastName("lastName").address("adresss")
                .idProspect(2L)
                .identifiantProspect("string1").build();

        //when
        when(prospectService.getAllProspects()).thenReturn(Arrays.asList(prospectDTO1,prospectDTO2));

        //then
        mvc.perform(get("/"))
                .andExpect(jsonPath("$", hasSize(2)))
                .andDo(print())
                .andExpect(status().isOk());
    }

    @WithMockUser
    @Test
    public void getAllTrancheRevenus() throws Exception {
        //Given
        MediaType halJson = MediaType.parseMediaType("application/json;charset=UTF-8") ;
        //when
       //then
        mvc.perform(get("/trancherevenu"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(halJson))
                .andExpect(jsonPath("$[0]", is("ENTRE_0_7500")))
                .andExpect(jsonPath("$[1]", is("ENTRE_7500_10000")))
                .andExpect(jsonPath("$[2]", is("ENTRE_10000_25000")))
                .andExpect(jsonPath("$[3]", is("ENTRE_25000_40000")))
                .andExpect(jsonPath("$[4]", is("PLUS_40000")));
    }

    @WithMockUser
    @Test
    public void createProspect() throws Exception {
     //Given
     MediaType halJson = MediaType.parseMediaType("application/json;charset=UTF-8") ;
     Long idProspect = 1l ;
        ProspectDTO prospectDTO = ProspectDTO.builder().firstName("firstName").lastName("lastName").address("adresss").idProspect(idProspect).build();
    //when
    when(prospectService.saveProspect(prospectDTO)).thenReturn(prospectDTO);
    //then
      mvc.perform(post("/")
                .content(toJson(prospectDTO))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated());

    }

    private byte[] toJson(Object r) throws Exception {
        ObjectMapper map = new ObjectMapper();
        return map.writeValueAsString(r).getBytes();
    }

    @WithMockUser
    @Test
    public void getAllStatusProfessionnel() throws Exception {
        //Given
        MediaType halJson = MediaType.parseMediaType("application/json;charset=UTF-8") ;
        //when
        //then
        mvc.perform(get("/statutprofessionnel"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(halJson))
                .andExpect(jsonPath("$[0]", is("SALARIE")))
                .andExpect(jsonPath("$[1]", is("RETRAITE")))
                .andExpect(jsonPath("$[2]", is("SANS_ACTIVITE")))
                .andExpect(jsonPath("$[3]", is("INDEPENDANT")));
    }

    @WithMockUser
    @Test
    public void findAllFamilySituations() throws Exception {
        //Given
        MediaType halJson = MediaType.parseMediaType("application/json;charset=UTF-8") ;
        //when
        //then
        mvc.perform(get("/situationfamiliale"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(halJson))
                .andExpect(jsonPath("$[0]", is("CELIBATAIRE")))
                .andExpect(jsonPath("$[1]", is("MARIE")))
                .andExpect(jsonPath("$[2]", is("DIVORCE")))
                .andExpect(jsonPath("$[3]", is("VEUF")));
    }


    @WithMockUser
    @Test
    public void findAllRendezVousByIdAgence() throws Exception  {
        //Given
        MediaType halJson = MediaType.parseMediaType("application/json;charset=UTF-8") ;
        Long idProspect = 1l ;
        Date date = new Date();
        Date date1 = new Date();
        System.out.print("date -- : "+ date);


        ProspectDTO prospectDTO = ProspectDTO.builder().firstName("firstName")
                .lastName("lastName").address("adresss").dateRdv(date).codeAgence("6253")
                .idProspect(idProspect).build();

        //when
        when(prospectService.findAllRendezVousByIdAgence("6253")).thenReturn(Arrays.asList(date,date1));
        //then "/{idAgence}/occuppiedtime"
        mvc.perform(get("/6253/occuppiedtime"))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(halJson));

    }

    @WithMockUser
    @Test
    public void updateProspect() throws Exception {
        //Given
        MediaType halJson = MediaType.parseMediaType("application/json;charset=UTF-8") ;
        Long idProspect = 1l ;
        ProspectDTO prospectDTO = ProspectDTO.builder().firstName("firstName").lastName("lastName").address("adresss").idProspect(idProspect).build();
        //when
        when(prospectService.updateProspect(prospectDTO)).thenReturn(prospectDTO);
        //then
        mvc.perform(put("/")

                .content(toJson(prospectDTO))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }

    @WithMockUser
    @Test
    public void updateValidatorOBProspect() throws Exception {
        //Given
        Long idProspect = 1l ;
        ProspectDTO prospectDTO = ProspectDTO.builder().firstName("firstName").lastName("lastName").address("adresss")
                .idProspect(idProspect).build();
        //when
        when(prospectService.updateValidatorOBProspect(idProspect)).thenReturn(prospectDTO);
        //then
        mvc.perform(put("/" + idProspect + "/acceptence"))
                .andExpect(status().isOk())
                .andDo(print());
    }

    @WithMockUser
    @Test
    public void deleteProspect() throws Exception {
        //Given
        Long idProspect = 1l ;
        ProspectDTO prospectDTO = ProspectDTO.builder().firstName("firstName").lastName("lastName").address("adresss")
                .idProspect(idProspect).build();
        //when
       /* prospectService.removeProspect(idProspect);
        OngoingStubbing<T> when = when(prospectService.removeProspect(idProspect)).thenReturn(null);*/
        //then
        mvc.perform(delete("/"+idProspect))
                .andDo(print()).
                andExpect(status().isOk());
    }

    @Test
    public void user() {

    }
}