package repository;

import com.netflix.discovery.converters.Auto;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import sg.df.prospect.dto.ProspectDTO;
import sg.df.prospect.repository.ProspectRepository;
import javax.persistence.EntityManager;
import sg.df.prospect.domain.Prospect ;

import static org.junit.Assert.assertNotNull;

@Ignore
@SpringBootTest(classes = ProspectRepository.class)
@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class ProspectRepositoryIntTest {
    @Autowired
    EntityManager entityManager ;
    @Autowired
    ProspectRepository prospectRepository ;

    private Prospect prospect;
    @Before
    public void setUp()
    {
        prospect = Prospect.builder().firstName("firstName").lastName("lastName").address("adresss")
                .idProspect(1L)
                .identifiantProspect("string").build();
    }

    @WithMockUser
    @Test
    public void findByIdentifiantProspectTest()
    {


        entityManager.persist(prospect);
        assertNotNull(prospectRepository.findByIdentifiantProspect("string")) ;
    }

}
