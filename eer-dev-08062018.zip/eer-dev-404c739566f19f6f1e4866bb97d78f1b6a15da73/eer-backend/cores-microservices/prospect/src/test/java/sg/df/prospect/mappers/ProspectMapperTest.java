package sg.df.prospect.mappers;

import org.junit.Assert;
import org.junit.Test;
import sg.df.prospect.domain.Prospect;
import sg.df.prospect.dto.ProspectDTO;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

public class ProspectMapperTest {
    ProspectMapper prospectMapper= new ProspectMapperImpl();

    @Test
    public void prospectToDtoWithNullProspect()
    {
        //Given
        Prospect prospect = null ;
        //When
        //Then
        assertNull(prospectMapper.ProspectToDto(prospect)); ;
    }

    @Test
    public void prospectToDtoWithProspect()
    {
        //Given
        Prospect prospect =  Prospect.builder().firstName("firstName").lastName("lastName").address("adresss")
                .idProspect(1l)
                .identifiantProspect("string").build() ;
        //When
        //Then
        assertNotNull(prospectMapper.ProspectToDto(prospect)); ;
    }

    @Test
    public void prospectToDto() {
        //Given
        Prospect prospect = Prospect.builder().firstName("firstName").lastName("lastName").address("adresss")
                .idProspect(1l)
                .identifiantProspect("string").build();

        //When
        ProspectDTO prospectDTO = prospectMapper.ProspectToDto(prospect);
        //Then
        assertEquals(prospect.getFirstName(),prospectDTO.getFirstName());
        assertEquals(prospect.getLastName(),prospectDTO.getLastName());
        assertEquals(prospect.getAddress(),prospectDTO.getAddress());
        assertEquals(prospect.getIdProspect(),prospectDTO.getIdProspect());

    }

    @Test
    public void dtoToProspect() {
        //Given
        ProspectDTO prospectDTO = ProspectDTO.builder().firstName("firstName").lastName("lastName").address("adresss")
                .idProspect(1l)
                .identifiantProspect("string").build();

        //When
        Prospect prospect = prospectMapper.DtoToProspect(prospectDTO);
        //Then
        assertEquals(prospect.getFirstName(),prospectDTO.getFirstName());
        assertEquals(prospect.getLastName(),prospectDTO.getLastName());
        assertEquals(prospect.getAddress(),prospectDTO.getAddress());
        assertEquals(prospect.getIdProspect(),prospectDTO.getIdProspect());
    }

}