package sg.df.prospect.resource;

import io.swagger.annotations.ApiOperation;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import sg.df.prospect.domain.type.*;
import sg.df.prospect.dto.AgenceDTO;
import sg.df.prospect.dto.ProspectDTO;
import sg.df.prospect.security.KeycloakAuthenticatoin;
import sg.df.prospect.service.ProspectService;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.invoke.MethodType;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.Principal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.GET;

@CrossOrigin(origins = "*")
@RestController
@EnableFeignClients
public class ProspectResource {

    Logger logger = LoggerFactory.getLogger(ProspectResource.class);
    public static final String GEOLOC_SERVICES = "geoloc-services";
    public static final String URL_GEOLOC_SERVICES_AGENCEBYCODE = "/agence/{codeAgence}";


    @Resource
    private ProspectService prospectServices;

    @Resource
    GeolocClient geolocClient;

    //TODO externaliser non service eureka register
    @FeignClient(GEOLOC_SERVICES)
    interface GeolocClient {
        @RequestMapping(value = URL_GEOLOC_SERVICES_AGENCEBYCODE, method = GET)
        ResponseEntity<AgenceDTO> findAgence(@PathVariable("codeAgence") String codeAgence);
    }


    @RequestMapping("/testMail")
    public void envoieEmail()
    {
        ProspectDTO prospect = ProspectDTO.builder().firstName("firstname").lastName("lasname").birthDate("birthdatre").numeroTel("+212665186448").numeroMobile("0665186448").email("anis.khai@socgen.com").sexe(Sexe.F).
                  civilite(Civilite.Mme).acceptCgu(Boolean.TRUE).boisson(TypeBoisson.C).dateRdv(new Date())
                .heureRdv("08:02").typeProspect(TypeProspect.P).codeAgence("015").identifiantProspect("identifProspect").build();
           prospectServices.saveProspect(prospect) ;

    }

    /**
     * Endpoint to recover one prospect with agence
     *
     * @param id
     * @return
     */
    @GetMapping("/{id}")
    @ApiOperation(value = "Récupérer un prospect par un identifiant")
    public ResponseEntity<ProspectDTO> findProspect(@PathVariable Long id) {
        ProspectDTO prospect = prospectServices.findOne(id);
        if (prospect != null && prospect.getCodeAgence() != null) {
            prospect.setAgenceDTO(geolocClient.findAgence(prospect.getCodeAgence()).getBody());
        }
        return ResponseEntity.status(HttpStatus.OK).body(prospect);
    }


    @GetMapping("/trancherevenu")
    @ApiOperation(value = "Récupérer la liste des tranche revenu")
    public ResponseEntity<List<TrancheRevenu>> getAllTrancheRevenus() {
        return ResponseEntity.status(HttpStatus.OK).body(Arrays.asList(TrancheRevenu.values()));
    }

    @GetMapping("/statutprofessionnel")
    @ApiOperation(value = "Récupérer la liste des statuts professionnel")
    public ResponseEntity<List<StatutProfessionnel>> getAllStatusProfessionnel() {
        return ResponseEntity.status(HttpStatus.OK).body(Arrays.asList(StatutProfessionnel.values()));
    }

    @GetMapping("/situationfamiliale")
    @ApiOperation(value = "Récupérer la liste des situations familiales")
    public ResponseEntity<List<SituationFamiliale>> findAllFamilySituations() {
        return ResponseEntity.status(HttpStatus.OK).body(Arrays.asList(SituationFamiliale.values()));
    }

    @GetMapping("/{idAgence}/occuppiedtime")
    @ApiOperation(value = "Récupérer la liste des horaire reserves")
    public ResponseEntity<List<Date>> findAllRendezVousByIdAgence(@PathVariable String idAgence) {
        return ResponseEntity.status(HttpStatus.OK).body(prospectServices.findAllRendezVousByIdAgence(idAgence));
    }


    @RequestMapping(value = "/user")
    public String user(Principal principal) {
        return principal.getName();
    }

    @RequestMapping("userInfo")
    public Boolean getUserInfo(HttpServletRequest request, HttpServletResponse response) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication instanceof KeycloakAuthenticationToken) {
            return new KeycloakAuthenticatoin((KeycloakAuthenticationToken) authentication).isAuthenticated();
        }
        return authentication.isAuthenticated();
    }

    /**
     * Endpoint to create new Prospect
     *
     * @param prospectDTO
     * @return
     */
    @PostMapping
    @ApiOperation(value = "Ajouter un nouveau prospect")
    public ResponseEntity createProspect(@RequestBody ProspectDTO prospectDTO) throws URISyntaxException {
        ProspectDTO prospect = prospectServices.saveProspect(prospectDTO);
        URI location = new URI("/"+prospect.getIdProspect());
        return ResponseEntity.created(location).body(prospect);
    }

    /**
     * Endpoint to get all prospect
     *
     * @return
     */
    @GetMapping
    @ApiOperation(value = "Récupérer la liste des prospects")
    public ResponseEntity<List<ProspectDTO>> prospects() {
        List<ProspectDTO> prospectDTOs = prospectServices.getAllProspects();

        return ResponseEntity.status(HttpStatus.OK).body(prospectDTOs);
    }


    @GetMapping("/identifiant/{identifiantProspect}")
    @PreAuthorize("isAuthenticated()")
    @ApiOperation(value = "Récupérer un prospect par son idUser")
    public ResponseEntity<ProspectDTO> findProspect(@PathVariable String identifiantProspect) {
        ProspectDTO prospect = prospectServices.findByIdentifiantProspect(identifiantProspect);
        if (prospect != null && prospect.getCodeAgence() != null) {
            prospect.setAgenceDTO(geolocClient.findAgence(prospect.getCodeAgence()).getBody());
        }
        return ResponseEntity.status(HttpStatus.OK).body(prospect);
    }

    /**
     * Endpoint to modify a prospect
     *
     * @param prospectDTO
     * @return
     */
    @PutMapping()
    @ApiOperation(value = "modifier un prospect par un identifiant")
    public ResponseEntity<ProspectDTO> updateProspect(@RequestBody ProspectDTO prospectDTO) {
        ProspectDTO prospect = prospectServices.updateProspect(prospectDTO);
        return ResponseEntity.status(HttpStatus.OK).body(prospect);
    }

    @PutMapping("/{id}/acceptence")
    @ApiOperation(value = "modifier validatoteOB d'un prospect par un identifiant")
    public ResponseEntity<ProspectDTO> updateValidatorOBProspect(@PathVariable Long id) {
        prospectServices.updateValidatorOBProspect(id);
        return ResponseEntity.status(HttpStatus.OK).body(null);
    }

    /**
     * Endpoint to remove prospect by id
     *
     * @param id
     * @return
     */
    @DeleteMapping("/{id}")
    @ApiOperation(value = "supprimer un prospect par un identifiant")
    public ResponseEntity deleteProspect(@PathVariable("id") Long id) {
        prospectServices.removeProspect(id);
        return ResponseEntity.status(HttpStatus.OK).body(null);
    }
}
