package sg.df.prospect.domain;
import java.util.Date;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

import lombok.*;
import sg.df.prospect.domain.type.*;
@Entity
@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
public class Prospect {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "id_prospect_seq")
    @SequenceGenerator(name = "id_prospect_seq", sequenceName = "id_prospect_seq")
    private Long idProspect;
    @NotNull
    private String firstName;
    @NotNull
    private String lastName;
    private String birthDate;
    private String numeroTel;
    @NotNull
    private String numeroMobile;
    @NotNull
    private String email;
    @Enumerated(EnumType.STRING)
    private Sexe sexe;
    @Enumerated(EnumType.STRING)
    private Civilite civilite;
    @NotNull
    private Boolean acceptCgu;
    @NotNull
    @Enumerated(EnumType.STRING)
    private TypeBoisson boisson;
    @NotNull
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateRdv;
    @NotNull
    private String codeAgence;
    @Enumerated(EnumType.STRING)
    private TypeProspect typeProspect;
    @NotNull
    private String identifiantProspect;
    private Boolean validateOB;
    private String address;
    private String addressComplement;
    private String zipCode;
    private Long idBirthCity;
    private Long idCity;
    @Enumerated(EnumType.STRING)
    private SituationFamiliale situationFamiliale;
    @Enumerated(EnumType.STRING)
    private NbrEnfACharge nbrEnfACharge;
    @Enumerated(EnumType.STRING)
    private StatutProfessionnel statutProfessionnel;
    private String secteurActivite;
    @Enumerated(EnumType.STRING)
    private TrancheRevenu trancheRevenu;
    private String numeroPiece;
    @Enumerated(EnumType.STRING)
    private Piece piece;

}
