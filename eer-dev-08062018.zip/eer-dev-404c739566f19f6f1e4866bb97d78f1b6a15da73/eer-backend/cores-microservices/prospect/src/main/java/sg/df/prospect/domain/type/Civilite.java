package sg.df.prospect.domain.type;

public enum Civilite {
    Mr("Mr"), Mme("Mme") ;
    private String libelleCivilite ;
    Civilite(String libelleCivilite) {
        this.libelleCivilite = libelleCivilite;
    }
}
