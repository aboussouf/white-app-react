package sg.df.prospect.util;

import org.apache.commons.lang.time.DateFormatUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.mapstruct.ap.shaded.freemarker.template.SimpleDate;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {

    public static String formatDateRDV(Date dateRDV) {
       return  DateFormatUtils.ISO_DATE_FORMAT.format(dateRDV);
    }
    public static Date formatDate(Date dateRdv,String heureRdv)
    {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy") ;
        return DateTimeFormat.forPattern("dd/MM/yyyy HH:mm").parseDateTime( sdf.format(dateRdv)+" "+heureRdv).toDate();

    }
}
