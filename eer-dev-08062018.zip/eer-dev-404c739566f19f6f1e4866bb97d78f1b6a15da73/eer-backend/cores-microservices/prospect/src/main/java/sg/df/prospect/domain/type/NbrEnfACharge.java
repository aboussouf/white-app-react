package sg.df.prospect.domain.type;

public enum NbrEnfACharge {
    N0("0"), N1("1"),N2("2"),PLUS_3("3 et +"), ;
    private String nbreEnfant;
    NbrEnfACharge(String nbreEnfant) {
        this.nbreEnfant = nbreEnfant;
    }
}
