package sg.df.geoloc.exception;

public class AgenceNotFoundException extends Exception {

}
