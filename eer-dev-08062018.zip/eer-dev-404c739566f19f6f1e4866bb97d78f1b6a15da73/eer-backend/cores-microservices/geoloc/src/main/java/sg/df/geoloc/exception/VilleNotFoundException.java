package sg.df.geoloc.exception;

public class VilleNotFoundException extends Exception {

}
