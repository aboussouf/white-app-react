package sg.df.geoloc.resource;


import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import sg.df.geoloc.domain.type.TypeAgence;
import sg.df.geoloc.dto.AgenceDTO;
import sg.df.geoloc.dto.VilleDTO;
import sg.df.geoloc.service.AgenceService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.is;

@WebMvcTest(AgenceResource.class)
@RunWith(SpringRunner.class)
public class AgenceResourceTest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private AgenceService agenceService;
    @Autowired
    private AgenceResource agenceResource;

    private  AgenceDTO agenceDTO;
    private  AgenceDTO agenceDTO1;
    private VilleDTO villeDTO;
    private String codeAgence = "6215";
    @Before
    public void setUp(){
        villeDTO = VilleDTO.builder().idVille(1L).latitude("33.26598").longitude("27.226569").libelle("casablanca")
                .build();
        agenceDTO = AgenceDTO.builder().codeAgence(codeAgence).adresseAgence("adress").libelleAgence("Hassan2")
                .numTel("0664262021").typeAgence(TypeAgence.ACP).codePostal("20700")
                .latitude("33.256987").longitude("27.23659").ville(villeDTO)
                .build();
        agenceDTO1 = AgenceDTO.builder().codeAgence("7221").adresseAgence("adress").libelleAgence("Hassan2")
                .numTel("0664262021").typeAgence(TypeAgence.ACP).codePostal("20700")
                .latitude("33.256987").longitude("27.23659").ville(villeDTO)
                .build();
    }
    @WithMockUser
    @Test
    public void saveAgenceTest() throws Exception {
     //Given
     MediaType halJson = MediaType.parseMediaType("application/json;charset=UTF-8") ;

    //when
    when(agenceService.save(agenceDTO)).thenReturn(agenceDTO);
    //thenReturn
        mockMvc.perform(post("/agence/")
                .content(toJson(agenceDTO))
                .contentType(halJson))
               // .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());

    }



    @Test
    public void getValeur() {

    }


    @Test
    public void agences() throws Exception{
        List<AgenceDTO> agenceDTOList = new ArrayList<AgenceDTO>();

        //when
        when(agenceService.getAll()).thenReturn(Arrays.asList(agenceDTO,agenceDTO1));

        //then
        mockMvc.perform(get("/agence/"))
               // .andExpect(jsonPath("$", hasSize(2)))
                .andDo(print())
                .andExpect(status().isOk());
    }

    @WithMockUser
    @Test
    public void findAgence() throws Exception{
        //Given
        MediaType halJson = MediaType.parseMediaType("application/hal+json;charset=UTF-8") ;

        //when
        when(agenceService.findOne(codeAgence)).thenReturn(agenceDTO) ;
        //then
        mockMvc.perform(get("/agence/"+codeAgence))
                .andDo(print()).
                andExpect(status().isOk())
                .andExpect(content().contentType(halJson))
                .andExpect(jsonPath("$.codeAgence", is("6215")))
                .andExpect(jsonPath("$.libelleAgence", is("Hassan2")))
                .andExpect(jsonPath("$.adresseAgence", is("adress")))
                .andExpect(jsonPath("$.numTel", is("0664262021")))
                .andExpect(jsonPath("$.typeAgence", is("ACP"))) ;
    }
    @WithMockUser
    @Test
    public void updateAgence()  throws Exception  {
        //Given
        MediaType halJson = MediaType.parseMediaType("application/json;charset=UTF-8") ;
        //when
        when(agenceService.update(agenceDTO)).thenReturn(agenceDTO);
        //then
        mockMvc.perform(put("/agence/"+codeAgence)
                .content(toJson(agenceDTO))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }
    @WithMockUser
    @Test
    public void deleteAgence()  throws Exception {
        //Given
        //when
        // when(prospectService.removeProspect(1L)).thenReturn(null) ;
        //then
        mockMvc.perform(delete("/agence/"+codeAgence))
                .andDo(print()).
                andExpect(status().isOk());
    }
    private byte[] toJson(Object r) throws Exception {
        ObjectMapper map = new ObjectMapper();
        return map.writeValueAsString(r).getBytes();
    }
}
