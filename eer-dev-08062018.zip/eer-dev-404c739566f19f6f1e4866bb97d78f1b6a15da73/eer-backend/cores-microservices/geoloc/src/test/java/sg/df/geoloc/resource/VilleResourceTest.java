package sg.df.geoloc.resource;


import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import sg.df.geoloc.domain.type.TypeAgence;
import sg.df.geoloc.dto.AgenceDTO;
import sg.df.geoloc.dto.VilleDTO;
import sg.df.geoloc.service.AgenceService;
import sg.df.geoloc.service.VilleService;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static junit.framework.TestCase.assertTrue;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(VilleResource.class)
@RunWith(SpringRunner.class)
public class VilleResourceTest {

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private VilleService villeService;
    @MockBean
    private AgenceService agenceService;
    @Autowired
    private VilleResource  villeResource;
    private Long idVille = 1l;

    private VilleDTO villeDTO;
    private VilleDTO villeDTO1;
    @Before
    public void setUp(){
        villeDTO = VilleDTO.builder().idVille(idVille).latitude("33.26598").longitude("27.226569").libelle("casablanca")
                .build();
        villeDTO1 = VilleDTO.builder().idVille(2l).latitude("33.26598").longitude("27.226569").libelle("Rabat")
                .build();

    }
    @WithMockUser
    @Test
    public void saveVille()  throws Exception {
        //Given
        MediaType halJson = MediaType.parseMediaType("application/json;charset=UTF-8") ;

        //when
        when(villeService.save(villeDTO)).thenReturn(villeDTO);
        //thenReturn
        mockMvc.perform(post("/ville/")
                .content(toJson(villeDTO))
                .contentType(halJson))
                // .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }
    @WithMockUser
    @Test
    public void villes() throws Exception{

        List<VilleDTO> villeDTOList = new ArrayList<VilleDTO>();

        //when
        when(villeService.getAll()).thenReturn(Arrays.asList(villeDTO,villeDTO1));

        //then
        mockMvc.perform(get("/ville/"))
                .andExpect(jsonPath("$", hasSize(2)))
                .andDo(print())
                .andExpect(status().isOk());

    }
    @WithMockUser
    @Test
    public void findVille()throws Exception {
        //Given
        MediaType jsonForma = MediaType.parseMediaType("application/json;charset=UTF-8") ;
        MediaType halJson = MediaType.parseMediaType("application/hal+json;charset=UTF-8") ;

        //when
        when(villeService.findOne(idVille)).thenReturn(villeDTO) ;
        //then
        mockMvc.perform(get("/ville/"+idVille))
                .andDo(print()).
                andExpect(status().isOk())
                .andExpect(content().contentType(halJson))
                .andExpect(jsonPath("$.idVille", is(1)))
                .andExpect(jsonPath("$.libelle", is("casablanca")))
                .andExpect(jsonPath("$.latitude", is("33.26598"))) ;
    }

    @WithMockUser
    @Test
    public void updateville()throws Exception {
        //Given
        MediaType halJson = MediaType.parseMediaType("application/json;charset=UTF-8") ;
        //when
        when(villeService.update(villeDTO)).thenReturn(villeDTO);
        //then
        mockMvc.perform(put("/ville/")
                .content(toJson(villeDTO))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(print());
    }
    @WithMockUser
    @Test
    public void deleteVille()throws Exception {
        //Given
        //when
        // when(prospectService.removeProspect(1L)).thenReturn(null) ;
        //then
        mockMvc.perform(delete("/ville/"+idVille))
                .andDo(print()).
                andExpect(status().isOk());
    }
    @WithMockUser
    @Test
    public void agencesbyVille() throws Exception{
        //Given
        MediaType halJson = MediaType.parseMediaType("application/hal+json;charset=UTF-8") ;
        //when
        when(villeService.findOne(idVille)).thenReturn(villeDTO) ;
        //then
        mockMvc.perform(get("/ville/"+idVille+"/agences"))
                .andDo(print()).
                andExpect(status().isOk());

    }
    private byte[] toJson(Object r) throws Exception {
        ObjectMapper map = new ObjectMapper();
        return map.writeValueAsString(r).getBytes();
    }
}
