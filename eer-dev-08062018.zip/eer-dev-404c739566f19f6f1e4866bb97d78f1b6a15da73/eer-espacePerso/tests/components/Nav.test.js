import React from 'react'
import { shallow } from 'enzyme'
import { expect } from 'chai'

import Nav from '../../src/components/Nav'
import * as user from '../asserts/images/user1.png'
import un from '../../src/asserts/images/menu_icons/01.png'
import * as deux from '../../src/asserts/images/menu_icons/02.png'
import * as trois from '../../src/asserts/images/menu_icons/03.png'
import * as quatre from '../../src/asserts/images/menu_icons/04.png'
import * as cinq from '../../src/asserts/images/menu_icons/05.png'

const elementsMenu = [
  { href: 'index.html', image: un, titre: '  Mon Espace', enabled: 'true' },
  { href: 'pages/widgets.html', image: deux, titre: '  Mon Profil', enabled: 'true' },
  { href: 'pages/ui-features/buttons.html', image: trois, titre: '  Mon Agence', enabled: 'true' },
  { href: 'pages/forms/basic_elements.html', image: quatre, titre: '  Ma Banque', enabled: 'true' },
  { href: 'pages/charts/chartjs.html', image: cinq, titre: '  Coffre-fort', enabled: 'true' },
]

describe('Nav', () => {
  it('renders the icon if provided', () => {
    const wrapper = shallow(<Nav icon={user} nom='Sara El Amrani' type='Particulier' options={elementsMenu} />)
    expect(wrapper.find('img')).to.have.length(1)
  })
})
