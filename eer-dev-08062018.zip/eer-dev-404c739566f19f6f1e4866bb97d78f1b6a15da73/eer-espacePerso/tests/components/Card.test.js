import React from 'react'
import { shallow } from 'enzyme'
import { expect } from 'chai'
import { spy } from 'sinon'
import * as user from '../../src/asserts/images/user.png'

import Card from '../../src/components/Card'

describe('Card', () => {
  it('renders the icon if provided', () => {
    const wrapper = shallow(<Card icon={user} titre='Mon Profil' soustitre='Votre profil est complet à 25%' label='Compléter mon profil' classNameI='mdi mdi-alert-octagon mr-1' />)
    expect(wrapper.find('img')).to.have.length(1)
  })

  it('renders a Button component', () => {
    const wrapper = shallow(<Card icon={user} titre='Mon Profil' soustitre='Votre profil est complet à 25%' label='Compléter mon profil' classNameI='mdi mdi-alert-octagon mr-1' />)
    expect(wrapper.find('Button')).to.have.length(1)
  })

    /* it('renders a progressbar button', () => {
      const wrapper = shallow(<Card icon={user} titre="Mon Profil" soustitre="Votre profil est complet à 25%" label="Compléter mon profil" classNameI="mdi mdi-alert-octagon mr-1" progressbar="true"/>);
      expect(wrapper.find('progressbar')).to.have.length(1);
    }); */
})
