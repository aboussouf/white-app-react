import React from 'react'
import { shallow } from 'enzyme'
import { expect } from 'chai'
import { spy } from 'sinon'

import MenuItem from '../../src/components/MenuItem'

describe('MenuItem', () => {
  it('renders the icon if provided', () => {
    const wrapper = shallow(<MenuItem className='nav-link' icon='ffdf' label='Test' />)
    expect(wrapper.find('img')).to.have.length(1)
  })

  it('renders if className not specified', () => {
    const wrapper = shallow(<MenuItem icon='ffdf' label='Test' />)
    expect(wrapper.find('nav-item')).to.have.length(0)
  })

  it('renders specific className', () => {
    const wrapper = shallow(<MenuItem className='nav-link' icon='ffdf' label='Test' />)
    expect(wrapper.find('nav-item nav-link')).to.have.length(0)
  })
})
