import { connect } from 'react-redux'
import Nav from '../components/Nav'
import { TOGGLE_MENU } from '../../../store/actions/Inputs'

const mapDispatchToProps = (dispatch) => ({
  toggle: () => { dispatch(TOGGLE_MENU) },
})

export default connect(null, mapDispatchToProps)(Nav)
