import React, { Component } from 'react'
import PropTypes from 'prop-types'
import MenuItem from '../../MenuItem'

import '../../../asserts/css/style_profil.scss'

class Nav extends Component {
  constructor (props) {
    super(props)
    this.handleClick = this.handleClick.bind(this)
  }
  handleClick (e) {
    e.preventDefault()
    this.props.toggle()
  }
  render () {
    return (
      <nav className='sidebar col-xs-12 col-sm-4 col-lg-3 col-xl-2'>
        <h1 className='site-title'>
          <a href='#/'> Espace EER</a></h1>
        <a href='#' className='btn btn-default' id='menu-toggle' onClick={this.handleClick}>
          <em className='fa fa-bars' />
        </a>
        <ul className='nav nav-pills flex-column sidebar-nav'>
          {this.props.options && this.props.options.map((o) =>
            <MenuItem id={o.id} href={o.href} icon={o.icon} label={o.titre} />
          )}
        </ul>
        <a className='logout-button' href='#/' target='' onClick={this.props.deconnect} >
          <em className='fa fa-power-off' />
          Déconnexion
        </a>
      </nav>
    )
  }
}

Nav.propTypes = {
  options: PropTypes.array,
  deconnect: PropTypes.func,
  toggle: PropTypes.func,
}

export default Nav
