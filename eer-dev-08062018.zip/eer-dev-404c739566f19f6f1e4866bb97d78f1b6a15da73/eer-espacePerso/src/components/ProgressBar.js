import React, { Component } from 'react'
import PropTypes from 'prop-types'

class ProgressBar extends Component {
  render () {
    let width = {
      width:  this.props.progress
    }
    return (
      <div className='progress progress-custom'>
        <div className='progress-bar bg-primary'
          style={width}
          role='progressbar'
          aria-valuemin={this.props.valuemin}
          aria-valuenow={this.props.valuenow}
          aria-valuemax={this.props.valuemax}
        />
      </div>
    )
  }
}

ProgressBar.propTypes = {
  progress : PropTypes.string,
  valuenow : PropTypes.string,
  valuemin : PropTypes.string,
  valuemax : PropTypes.string,
}

ProgressBar.defaultProps = {
  valuemin: '0',
  valuenow: '100',
  valuemax: '100',
}

export default ProgressBar
