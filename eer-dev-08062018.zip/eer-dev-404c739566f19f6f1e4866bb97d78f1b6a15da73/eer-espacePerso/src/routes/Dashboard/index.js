import Dashboard from './containers'

export default Dashboard
