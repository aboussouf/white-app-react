import React from 'react'
import PropTypes from 'prop-types'
import * as constants from '../../../utils/constants'
import Input from '../../../components/InputText'
import Select from '../../../components/Select'

class Coordonnees extends React.Component {
  render () {
    return ([
      <div className='form-group row'>
        <Input
          storeKey='prospect.address1'
          label='Adresse 1 '
          error='Veuillez saisir une adresse valide'
          pattern={constants.REGEX_PROSPECT_ADDRES}
        />
        <Input
          storeKey='prospect.address2'
          label='Adresse 2 '
          error='Veuillez saisir une adresse valide'
          pattern={constants.REGEX_PROSPECT_ADDRES}
        />
      </div>,
      <div className='form-group row' >
        <Select options={this.props.villes} storeKey='prospect.city' label='Ville' />
        <Input
          storeKey='prospect.zipCode'
          label='Code postal '
          error='Veuillez saisir un code valide'
        />
      </div>,
      <div className='form-group row' >
        <Input
          storeKey='prospect.email'
          label='Email '
          error='Veuillez saisir un email valide'
          pattern={constants.REGEX_PROSPECT_EMAIL}
        />
        <Input
          storeKey='prospect.tel'
          label='Téléphone '
          error='Veuillez saisir un téléphone valide'
          pattern={constants.REGEX_PROSPECT_PHONE}
        />
      </div>
    ])
  }
}

Coordonnees.propTypes = {
  villes : PropTypes.array,
}
export default Coordonnees
