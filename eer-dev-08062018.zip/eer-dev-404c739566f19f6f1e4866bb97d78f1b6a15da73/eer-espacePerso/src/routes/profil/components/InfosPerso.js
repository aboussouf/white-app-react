import React from 'react'
import PropTypes from 'prop-types'
import * as constants from '../../../utils/constants'
import Input from '../../../components/InputText'
import Select from '../../../components/Select'

const civilityOptions = [
  { label: 'Madame', value: 'Mme' },
  { label: 'Monsieur', value: 'Mr' },
]
const identityOptions = [
  { label: 'CIN', value: 'CNIE' },
  { label: 'PASSEPORT', value: 'PASSEPORT' },
]

class infosPerso extends React.Component {
  render () {
    return ([
      <div className='form-group row'>
        <Select options={civilityOptions} storeKey='prospect.civility' label='Civilité' />
      </div>,
      <div className='form-group row' >
        <Input
          storeKey='prospect.lastName'
          label='Nom '
          error='Veuillez saisir un nom valide'
          pattern={constants.REGEX_PROSPECT_NAME}
        />
        <Input
          storeKey='prospect.firstName'
          label='Prénom '
          error='Veuillez saisir un prénom valide'
          pattern={constants.REGEX_PROSPECT_NAME}
        />
      </div>,
      <div className='form-group row' >
        <Input
          storeKey='prospect.birthDate'
          label='Date de naissance '
          error='Veuillez saisir une date valide : 12/04/1998'
          pattern={constants.REGEX_PROSPECT_DATE}
        />
        <Select options={this.props.villes} storeKey='prospect.birthCity' label='Ville de naissance' />
      </div>,
      <div className='form-group row' >
        <Select options={identityOptions} storeKey='prospect.typePiece' label='Pièce d&apos;identité' />
        <Input
          storeKey='prospect.numPiece'
          label='Numéro'
          error='Veuillez saisir une piece valide'
        />
      </div>
    ])
  }
}

infosPerso.propTypes = {
  villes: PropTypes.array
}
export default infosPerso
