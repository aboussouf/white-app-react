// We only need to import the modules necessary for initial render

import React from 'react'
import Route from 'react-router/lib/Route'
import CoreLayout from '../layouts/PageLayout/containers'
import Profil from './Profil'
import Dashboard from './Dashboard'
import Agence from './Agence/containers/Rdv'
import Rdv from './Agence/containers/DetailsRdv'

export default function createRoutes () {
  return (
    <div>
      <Route component={CoreLayout}>
        <Route path='/' component={Dashboard} />
        <Route path='/Dashboard' component={Dashboard} />
        <Route path='/Profil' component={Profil} />
        <Route path='/Agence' component={Agence} />
        <Route path='/RdvDetails' component={Rdv} />
        <Route path='*' component={Dashboard} />
      </Route>
    </div>
  )
}
