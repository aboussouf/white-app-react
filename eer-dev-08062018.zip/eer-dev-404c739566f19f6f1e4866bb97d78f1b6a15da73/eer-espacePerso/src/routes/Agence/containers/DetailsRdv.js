import View from '../components/DetailsRdv'
import { connect } from 'react-redux'
import { fromJS } from 'immutable'
import { getBranchesByCity } from '../../../store/actions/Geolocs'

const mapStateToProps = (state) => ({
  cities: state.geoloc.getIn(['cities', 'result']) || fromJS([]),
  agences: state.geoloc.getIn(['cityAgences', 'result']) || fromJS([]),
  selectedVille: state.prospect.getIn(['ville', 'value']),
  agenceSelectionnee: state.prospect.get('agence'),
})

const mapDispatchToProps = (dispatch) => ({
  getAgencys: (payload) => { dispatch(getBranchesByCity(payload)) },
})

export default connect(mapStateToProps, mapDispatchToProps)(View)
