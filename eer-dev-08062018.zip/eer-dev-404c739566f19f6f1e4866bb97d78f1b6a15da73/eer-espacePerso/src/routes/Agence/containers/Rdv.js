import View from '../components/Rdv'
import { connect } from 'react-redux'
import { fromJS } from 'immutable'

const mapStateToProps = (state, props) => ({
  prospect: state.prospect.getIn(['prospect', 'result']) || fromJS({}),
})

export default connect(mapStateToProps)(View)
