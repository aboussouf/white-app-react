import Agence from './containers'

export default Agence
