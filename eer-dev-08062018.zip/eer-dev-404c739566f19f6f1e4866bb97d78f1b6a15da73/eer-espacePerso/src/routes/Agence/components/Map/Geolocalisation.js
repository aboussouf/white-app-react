import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { GoogleApiWrapper } from './index'
import Map from './Map'

class Container extends Component {
  render () {
    return (
      <div>
        <Map
          google={this.props.google}
          loaded={this.props.loaded}
          city={this.props.city}
          agences={this.props.agences}
        />
      </div>
    )
  }
}

const Loading = () => <div>loading container</div>
Container.propTypes = {
  google: PropTypes.object.isRequired,
  loaded: PropTypes.bool,
  city: PropTypes.object.isRequired,
  agences: PropTypes.array,
}
export default GoogleApiWrapper({
  apiKey: 'AIzaSyALWPNUAcR9SSUTQUBxV1tVpJ_ZMmi7LuQ',
  libraries: ['places', 'visualization'],
  LoadingContainer: Loading
})(Container)
