import React from 'react'
import PropTypes from 'prop-types'
import InputSelect from '../../../components/Select'
import Map from './Map/Geolocalisation'
//import Calend from './Calend/containers'
import Rencontre from './Rencontre/containers/Rencontre'

class DetailsRdv extends React.Component {
  componentWillMount () {
    this.props.getAgencys(this.props.selectedVille)
  }

  componentDidUpdate (prevProps, prevState) {
    if (prevProps.selectedVille !== this.props.selectedVille) {
      this.props.getAgencys(parseInt(this.props.selectedVille, 10))
    }
  }

  render () {
    const _cities = this.props.cities
      .map(city => ({ value: city.idVille, label: city.libelle, latitude: city.latitude, longitude:city.longitude }))
    return (
      <div>
        <div className='row mt-3 mb-2'>
          <div className='col-xs-9 col-md-7'>
            <InputSelect id='select' storeKey='prospect.ville'
              options={_cities}
              label='Ville :'
            />
          </div>
          <div className='col-xs-3 col-md-5'>
            {this.props.agenceSelectionnee && this.props.agenceSelectionnee.get('libelleAgence') !== ''
              ? <div>
                <label className='col-form-label'>Votre Agence sera </label>
                <h4>{this.props.agenceSelectionnee.get('libelleAgence')}</h4>
                <h6>{this.props.agenceSelectionnee.get('adresseAgence')}</h6>
              </div>
              : null
            }
          </div>
        </div>
        <div className="row">
        <div className="col-sm-12">
        <Map
           agences={this.props.agences}
           city={_cities.find((city) => city.value === parseInt(this.props.selectedVille, 10))}
         />


        </div>
        <div className="col-sm-12">
        <br></br>
        <br></br><br></br><br></br>
        <br></br><br></br><br></br>
        <br></br><br></br><br></br>
        <br></br><br></br><br></br>
        </div>
        </div>
        <div className="row">
        <div className="col-sm-12">

          <Rencontre storeKey='prospect.heureRdv' />
            </div>
        </div>
      </div>
    )/* */
  }
}

DetailsRdv.propTypes = {
  cities: PropTypes.array.isRequired,
  agences: PropTypes.array.isRequired,
  getAgencys: PropTypes.func,
  selectedVille: PropTypes.string,
  agenceSelectionnee: PropTypes.object,
}
DetailsRdv.defaultProps = {
  selectedVille : '1',
}

export default DetailsRdv
