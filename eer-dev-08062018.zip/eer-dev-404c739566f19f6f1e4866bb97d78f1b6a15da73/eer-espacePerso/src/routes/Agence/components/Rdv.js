import React from 'react'
import PropTypes from 'prop-types'
import moment from 'moment'
import Card from '../../../components/Card'
import * as agence from '../../../asserts/images/agence.png'

class Agence extends React.Component {
  render () {
    return (
      <section className='row'>
        <div className='col-sm-12'>
          <section className='row'>
            <Card
              cardPicture={agence}
              cardTitle={`Agence ${this.props.prospect.getIn(['agenceDTO', 'libelleAgence'])}`}
              buttonLabel='Modifier mon Rendez-vous'
              linkTo='/RdvDetails'
            >
              <div className='articles-container'>
                <div className='article border-bottom'>
                  <div className='col-xs-12'>
                    <div className='row'>
                      <div className='col-2 date'>
                        <div className='large fa fa-calendar-check-o' />
                      </div>
                      <div className='col-10'>
                        <h4><a>Date</a></h4>
                        <p>{moment(this.props.prospect.get('dateRdv')).format('DD/MM/YYYY')}</p>
                      </div>
                    </div>
                  </div>
                  <div className='clear' />
                </div>
                <div className='article'>
                  <div className='col-xs-12'>
                    <div className='row'>
                      <div className='col-2 date'>
                        <div className='large fa fa-clock-o' />
                      </div>
                      <div className='col-10'>
                        <h4><a>Heure</a></h4>
                        <p>{moment(this.props.prospect.get('dateRdv')).format('HH:mm')}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </section>
        </div>
      </section>
    )
  }
}

Agence.propTypes = {
  prospect: PropTypes.object,
}

export default Agence
