import React from 'react'
import PropTypes from 'prop-types'
//import Calendar from 'react-calendar'
import InfiniteCalendar from 'react-infinite-calendar'
// import '../../Eer/css/style.scss'
import 'react-infinite-calendar/styles.scss'
class calend extends React.Component {
  constructor () {
    super()

    this.state = {
      date: new Date(),
    }
    this.onChange = this.onChange.bind(this)

  }


  changeString = (date) => {
    return `${date}`
  }

  onChange = (event) => {
    console.log('event', event)
    this.props.selectDate(event.toISOString(), this.props.storeKey)
  //  this.props.getRdvPrisParAgence(this.props.agenceSelectionnee.get('codeAgence'))
  }
  componentWillMount () {
  //  this.props.getRdvPrisParAgence(this.props.agenceSelectionnee.get('codeAgence'))
    // console.log('dateNum :', this.props.occuppiedtime)
  }

  fonction = () => { console.log(' fon here') }
  render () {
    console.log('here------', this.props.occuppiedtime)
    // const day = this.props.occuppiedtime.map(occupp => ({  }))
    var today = new Date()
    var dis = []
    // var dis = [new Date(2018, 5, 1), new Date(2018, 5, 5)]
    this.props.occuppiedtime.map((occup) => dis.push(new Date(occup)))
    console.log('dis --- ', dis)
    var lastWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate())
    // var lastYear = new Date(today.getFullYear())
    var eLocal = {

      headerFormat: 'ddd, MMM Do',
      todayLabel: {
        long: 'Auj',
      },
      locale: require('date-fns/locale/fr'),
      weekdays: ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'],
      weekStartsOn: 0,
    }
    var ethem = {
      accentColor: '#448AFF',
      floatingNav: {
        background: '#e2001a',
        chevron: '#FFA726',
        color: '#FFF',
      },
      headerColor: '#e2001a',
      selectionColor: '#e2001a',
      textColor: {
        active: '#FFF',
        default: '#333',
      },
      todayColor: '#e2001a',
      weekdayColor: '#e2001a',
    }

    return (
      <div className='row'>

        <InfiniteCalendar
          height={250}
          width={'100%'}
          className={'col-md-12'}
          selected={today}
          disabledDays={[0]}
          minDate={lastWeek}
          disabledDates={dis}
          locale={eLocal}
          theme={ethem}
          displayOptions={{
            showHeader : false, }}

          onSelect={this.onChange}
        />
      </div>
    )

  }
}

calend.propTypes = {
  action: PropTypes.func,
  storeKey: PropTypes.string.isRequired,
  selectDate: PropTypes.func,
  agenceSelectionnee: PropTypes.object,
  getRdvPrisParAgence: PropTypes.func,
  occuppiedtime : PropTypes.array,
}

export default calend
