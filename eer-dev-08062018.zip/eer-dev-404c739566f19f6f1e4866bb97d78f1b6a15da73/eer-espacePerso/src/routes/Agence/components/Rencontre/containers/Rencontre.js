import Rencontre from '../components/Rencontre'
import { connect } from 'react-redux'
import { inputChange } from '../../../../../store/actions/Inputs'
import { getRdvPrisParAgence } from '../../../../../store/actions/Prospect'

const mapStateToProps = (state, props) => {
  return ({
    dateRdv: state.prospect.getIn(['dateRdv', 'value']),
    heureRdv: state.prospect.getIn(['heureRdv', 'value']),
    agenceSelectionnee: state.prospect.get('agence'),

  })
}

const mapDispatchToProps = (dispatch) => ({
  selectHeure: (value, id) => { dispatch(inputChange(value, id)) },
  getRdvPrisParAgence :(value) => { dispatch(getRdvPrisParAgence(value)) }
})

export default connect(mapStateToProps, mapDispatchToProps)(Rencontre)
