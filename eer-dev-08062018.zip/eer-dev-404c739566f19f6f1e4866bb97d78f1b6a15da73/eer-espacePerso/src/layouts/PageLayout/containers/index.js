import View from '../PageLayout'
import { connect } from 'react-redux'

const mapStateToProps = (state, props) => ({
  firstName: state.prospect.getIn(['prospect', 'result', 'firstName']),
  lastName: state.prospect.getIn(['prospect', 'result', 'lastName']),
  typeProspect: state.prospect.getIn(['prospect', 'result', 'typeProspect']),
  toggled: state.prospect.getIn(['toggle', 'value']),
  keycloak: state.keycloak,
  path: state.location,
})

export default connect(mapStateToProps)(View)
