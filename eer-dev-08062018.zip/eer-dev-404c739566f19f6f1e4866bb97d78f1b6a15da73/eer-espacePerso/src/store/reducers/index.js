import { combineReducers } from 'redux'
import locationReducer from './location'
import prospectReducer from './Prospect'
import geolocReducer from './Geolocs'
import keycloakReducer from './keycloak'

export const makeRootReducer = (asyncReducers) => {
  return combineReducers({
    location: locationReducer,
    prospect: prospectReducer,
    geoloc: geolocReducer,
    keycloak: keycloakReducer,
    ...asyncReducers
  })
}

export const injectReducer = (store, { key, reducer }) => {
  if (Object.hasOwnProperty.call(store.asyncReducers, key)) return

  store.asyncReducers[key] = reducer
  store.replaceReducer(makeRootReducer(store.asyncReducers))
}

export default makeRootReducer
