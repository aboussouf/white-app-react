import React from 'react'
import PropTypes from 'prop-types'
import InputSelect from '../../../components/Select'
import MapContainer from '../../../components/Geoloc/MapContainer'

class MapView extends React.Component {
  componentWillMount () {
    this.props.getAgencys(this.props.selectedVille)
  }

  componentDidUpdate (prevProps, prevState) {
    if (prevProps.selectedVille !== this.props.selectedVille) {
      this.props.getAgencys(parseInt(this.props.selectedVille, 10))
    }
  }

  render () {
    console.log('agences : ', this.props.agences)
    const _cities = this.props.cities.map(
      city => ({ value: city.idVille, label: city.libelle, latitude: city.latitude, longitude:city.longitude }))
    console.log('all city ------- : ', _cities)
    return (
      <div>
      <div className='tab-pane' role='tabpanel' id='step4'>
      <h1 className='text-md-center'>Choix de l'agence</h1>
        <div className='row mt-3 mb-2'>
          <div className='col-xs-9 col-md-7'>


              <br />
              <br />

            <InputSelect id='select' storeKey='prospect.ville'
              options={_cities}
              label='Ville :'
              // className='col-md-9 col-sm-12 custom-select form-control'
            /></div>
          <div className='col-xs-3 col-md-5'>
            {this.props.agenceSelectionnee && this.props.agenceSelectionnee.get('libelleAgence') !== ''
              ? <div>
                <label className='col-form-label'>Votre Agence sera </label>
                <h4>{this.props.agenceSelectionnee.get('libelleAgence')}</h4>
                <h6>{this.props.agenceSelectionnee.get('adresseAgence')}</h6>
              </div>
              : null
            }

          </div>

        </div>
        <MapContainer
          ref='map'
          agences={this.props.agences}
          city={this.props.cities.find((city) => city.idVille === parseInt(this.props.selectedVille, 10))}
        />
        </div>
      </div>
    )
  }
}

MapView.propTypes = {
  cities: PropTypes.object.isRequired,
  agences: PropTypes.array.isRequired,
  getAgencys: PropTypes.func,
  selectedVille: PropTypes.string,
  agenceSelectionnee: PropTypes.object,
}
MapView.defaultProps = {
  selectedVille : '1',
}

export default MapView
