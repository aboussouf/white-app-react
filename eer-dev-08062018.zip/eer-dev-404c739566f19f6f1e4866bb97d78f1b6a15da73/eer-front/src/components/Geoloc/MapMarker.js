import React from 'react'
import PropTypes from 'prop-types'
class MapMarker extends React.Component {
  render () {
    return (

      <div id='content' >
      <div className='card-block'>
                <div className='articles-container'>

                  <div className='article border-bottom'>
                    <div className='col-xs-12'>
                      <div className='row'>

                        <h1>{this.props.agence.libelleAgence}</h1>

                    </div>
                    <div className='clear' />
                  </div>

                  <div className='article border-bottom'>
                    <div className='col-xs-12'>
                      <div className='row'>
                        <p>{this.props.agence.adresseAgence}</p>
                      </div>
                    </div>
                    <div className='clear' />
                  </div>

                  <div className='article'>
                   <p>Lun-Ven 8h15 à 16h15</p>
                   <p>Tél : <a href='tel:'>{this.props.agence.numTel}</a></p>
                    <div className='clear' />
                  </div>

				  <div className='article'>
                    <button className='btn btn-primary col-12' onClick={this.props.action}>Sélectionner</button>

                  </div>

                </div>
              </div>
		</div>


      </div>
    )/*<span><i className='' /> {this.props.agence.codePostal}</span><br />
    <span><i className='' /> </span><br />
    <span><i className='fa fa-home' />{this.props.agence.typeAgence}</span><br />btn btn-lg btn-primary next-step next-button hidden
*/
  }
}
MapMarker.propTypes = {
  action: PropTypes.func,
  agence : PropTypes.object,
}

export default MapMarker
