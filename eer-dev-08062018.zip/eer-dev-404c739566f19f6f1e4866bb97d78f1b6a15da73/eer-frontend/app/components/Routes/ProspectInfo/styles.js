export const styles = {
  displayFlex: {
    display: 'flex',
  },
  bg: {
    backgroundColor: 'red',
  },
  floatRight: {
    floatRight: 'right',
  },
  container: {
    minWidth: {
      minWidth: '60%',
    },
    formProspect: {
      part: {
        marginRight: {
          marginRight: '10%',
        },
        buttonColor: {
          backgroundColor: 'red',
        },
      },
    },
    cv: {
      width: '25%',
      float: 'right',
      marginRight: '34%',
    },
    buttonChoseAgence: {
      float: 'right',
      marginRight: '-40%',
      marginTop: '10%',
    },
  },
};
