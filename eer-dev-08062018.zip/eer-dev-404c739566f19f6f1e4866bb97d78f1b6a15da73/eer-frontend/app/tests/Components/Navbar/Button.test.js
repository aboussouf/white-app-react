import React from 'react';
import { shallow } from 'enzyme';
import { expect } from 'chai';
import { spy } from 'sinon';

import Button from '../../../components/Kit/Inputs/Button';

describe('Button', () => {
  let action = null;

  beforeEach(() => {
    action = spy();
  });

  it('renders an input button', () => {
    const wrapper = shallow(<Button label="click me" action={action} />);
    expect(wrapper.find('FlatButton')).to.have.length(1);
  });


  it('dispatches a event when the value changes', () => {
    const wrapper = shallow(
      <Button label="click me" action={action} />
    );
    wrapper.find('FlatButton').simulate('click');
    expect(action.called).to.equal(true);
  });

  it('renders the icon if provided', () => {
    const wrapper = shallow(<Button label="click me" icone="ffdf" action={action} />);
    expect(wrapper.find('img')).to.have.length(1);
  });
  it('renders a disabled button if Disabled', () => {
    const wrapper =
      shallow(<Button label="click me" action={action} disabled />);
    expect(wrapper.find('FlatButton').props().disabled).to.equal(true);
  });
});
