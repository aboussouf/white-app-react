import React from 'react';
import { shallow } from 'enzyme';
import { expect } from 'chai';
import { spy } from 'sinon';

import Navbar from '../../../components/Kit/Navbar';

describe('NavigationBar', () => {
  let goNext = null;

  beforeEach(() => {
    goNext = spy();
  });

  it('renders 2 Buttons', () => {
    const wrapper = shallow(<Navbar nextLabel="Suivant" />);
    expect(wrapper.find('Button')).to.have.length(2);
  });
  it('renders 1 Button if displayBack false', () => {
    const wrapper = shallow(<Navbar nextLabel="Suivant" displayBack={false} />);
    expect(wrapper.find('Button')).to.have.length(1);
  });

  it('passes the  disabled props to the second button', () => {
    const wrapper = shallow(
      <Navbar
        goToNext={goNext}
        disableNext
      />
    );
    expect(wrapper.find('Button').nodes[1].props.disabled).to.equal(true);
  });
});
