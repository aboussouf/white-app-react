/* eslint-disable no-unused-expressions */

import React from 'react';
import { shallow } from 'enzyme';
import { expect } from 'chai';
import { fromJS } from 'immutable';
import Step from '../../../components/Kit/Timeline/Step';

describe('Step', () => {
  const step = fromJS({
    step: 1, title: 'One',
  });

  it('should render a step', () => {
    const wrapper = shallow(<Step step={step.step} title={step.title} />);
    expect(wrapper.find('.label-step')).to.have.length(1);
  });

  it('renders active className if active step', () => {
    const wrapperActive = shallow(<Step step={step.step} title={step.title} active />);
    expect(wrapperActive.find('.margin-top-step-label--active')).to.have.length(1);
  });
});
