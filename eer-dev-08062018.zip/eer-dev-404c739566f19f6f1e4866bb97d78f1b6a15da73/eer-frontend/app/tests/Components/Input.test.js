import React from 'react';
import { shallow } from 'enzyme';
import { expect } from 'chai';
import { spy } from 'sinon';

import Input from '../../components/Kit/Inputs/Input';

describe('Input', () => {
  let inputChange = null;

  beforeEach(() => {
    inputChange = spy();
  });

  it('renders an input text', () => {
    const wrapper = shallow(<Input storeKey="myStore.myKey" />);
    expect(wrapper.find('TextField')).to.have.length(1);
  });

  it('selects the given value without dispatching a event when a value is provided', () => {
    const wrapper = shallow(
      <Input storeKey="myStore.myKey" value="world" />
    );
    expect(wrapper.find('TextField').props().defaultValue).to.equal('world');
    expect(inputChange.called).to.equal(false);
  });

  it('dispatches a event when the value changes', () => {
    const event = {
      target: {
        value: 'hello',
      },
    };
    const wrapper = shallow(
      <Input storeKey="myStore.myKey" inputChange={inputChange} />
    );
    wrapper.find('TextField').simulate('change', event);
    expect(inputChange.called).to.equal(true);
  });

  it('renders the icon if provided', () => {
    const wrapper = shallow(<Input storeKey="myStore.myKey" />);
    const wrapperIcone = shallow(<Input icon="check" storeKey="myStore.myKey" />);
    expect(wrapperIcone.find('.icon')).to.have.length(1);
    expect(wrapper.find('.icon')).to.have.length(0);
  });
  it('renders a disabled input if Disabled', () => {
    const wrapper =
      shallow(<Input icon="check" storeKey="myStore.myKey" disabled />);
    expect(wrapper.find('TextField').props().disabled).to.equal(true);
  });
});
