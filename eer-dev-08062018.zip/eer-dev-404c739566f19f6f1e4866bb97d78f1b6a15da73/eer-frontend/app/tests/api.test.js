import { expect } from 'chai';
import { spy } from 'sinon';
import { browserHistory } from 'react-router-dom';
import configureStore from '../configureStore';
import api from '../store/middlewares/api';


describe('Middleware API', () => {
  let store;

  beforeAll(() => {
    store = configureStore({}, browserHistory);
  });
  describe('API', () => {
    it('always calls the next middleware', () => {
      const next = spy();

      api(store)(next)({});
      expect(next.calledOnce).to.be.true; //eslint-disable-line
    });
  });
});
