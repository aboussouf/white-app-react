export const REGEX_PROSPECT_NAME = /^([a-zA-Z ]){0,30}$/
export const REGEX_PROSPECT_FIRST_NAME = /^([a-zA-Z ]){0,30}$/
export const REGEX_PROSPECT_EMAIL = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
export const REGEX_PROSPECT_PHONE = /^[(]{0,1}[0-9]{3}[)]{0,1}[-\s\.]{0,1}[0-9]{3}[-\s\.]{0,1}[0-9]{4}$/
export const PROSPECT_FORM_PARTICULIER = 'PARTICULIER'
export const PROSPECT_FORM_PROFESSIONEL = 'PROFESSIONEL'
export const STEPER_INDEX_LIMIT = 4
