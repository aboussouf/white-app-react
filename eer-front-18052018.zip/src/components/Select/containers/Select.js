
import { connect } from 'react-redux'
import Select from '../components/Select'
import { inputChange } from '../../../store/actions/Inputs'

const mapStateToProps = (state, props) => {
  const [store, ...storeKey] = props.storeKey.split('.')
  storeKey.push('value')
  return ({
    value: state[store].getIn(storeKey),
  })
}

const mapDispatchToProps = (dispatch) => ({
  inputChange: (value, id) => { dispatch(inputChange(value, id)) },
})

export default connect(mapStateToProps, mapDispatchToProps)(Select)
