import React, { Component } from 'react'
import PropTypes from 'prop-types'

class Select extends Component {
  constructor (props) {
    super(props)
    this.onChange = this.onChange.bind(this)
  }

  onChange (event) {
    this.props.inputChange(event.target.value, this.props.storeKey)
    this.props.getAgencys(event.target.value)
  }

  render () {
    return (
      <div>
        <label className='col-md-2 col-form-label'>{this.props.label}</label>
        <div className='col-md-4'>
          <select
            value={this.props.value}
            onChange={this.onChange}
            disabled={this.props.disabled}
            className={this.props.className}
          >
            {this.props.options && this.props.options.map((o) =>
              <option value={o.value} key={`item_${o.value}`} > {o.label}</option>
            )}
          </select>
        </div>
      </div>
    )
  }
}

Select.propTypes = {
  storeKey: PropTypes.string,
  label: PropTypes.string,
  value: PropTypes.string,
  disabled: PropTypes.bool,
  className: PropTypes.string,
  options: PropTypes.array,
  inputChange: PropTypes.func,
  getAgencys: PropTypes.func,
}

Select.defaultProps = {
  className: 'col-md-9 col-sm-12 custom-select form-control'
}

export default Select
