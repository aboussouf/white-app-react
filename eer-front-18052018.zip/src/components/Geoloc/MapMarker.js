import React from 'react'
import PropTypes from 'prop-types'
class MapMarker extends React.Component {
  selectAg = (agence) => {
    console.log('here agence ', agence)
    this.props.setAgenceSelectionnee(agence, this.props.storeKey)
  }
  render () {
    return (

      <div id='content' >

        <h3>{this.props.agence.get('libelleAgence')}</h3><p>{this.props.agence.get('adresseAgence')}<br /></p>
        <span>Téléphone : <span><a href='tel:'>{this.props.agence.get('numTel')}</a></span></span>
        <span><i className='' /> {this.props.agence.get('codePostal')}</span><br />
        <span><i className='' /> </span><br />
        <span><i className='fa fa-user' />{this.props.agence.get('typeAgence')}</span><br />

        <p><button onClick={() => this.selectAg(this.props.agence.get('codeAgence'))}>Sélectionner</button></p>
      </div>
    )
  }
}
/* <p><button onClick={this.props.action}>Sélectionner</button></p> */
MapMarker.propTypes = {
  // action: PropTypes.func,
  agence : PropTypes.object,
  setAgenceSelectionnee : PropTypes.func,
  storeKey:PropTypes.string,
}

export default MapMarker
