import React from 'react'
import PropTypes from 'prop-types'
class MapMarker extends React.Component {
  selectAg = (agence) => {
    console.log('here agence ', agence)
    this.props.setAgenceSelectionnee(agence)
  }
  render () {
    return (

      <div id='content' >

        <h3>{this.props.agence.libelleAgence}</h3><p>{this.props.agence.adresseAgence}<br /></p>
        <span>Téléphone : <span><a href='tel:'>{this.props.agence.numTel}</a></span></span>
        <span><i className='' /> {this.props.agence.codePostal}</span><br />
        <span><i className='' /> </span><br />
        <span><i className='fa fa-user' />{this.props.agence.typeAgence}</span><br />

        <p><button onClick={this.props.action}>Sélectionner</button></p>
      </div>
    )
  }
}
/* <p><button onClick={this.props.action}>Sélectionner</button></p> */
MapMarker.propTypes = {
  action: PropTypes.func,
  agence : PropTypes.object,
  setAgenceSelectionnee : PropTypes.func,
}

export default MapMarker
