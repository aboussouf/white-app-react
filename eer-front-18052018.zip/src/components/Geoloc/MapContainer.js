import MapView from './MapView'
import { connect } from 'react-redux'
import { setAgenceSelectionnee } from '../../store/actions/Prospect'

const mapStateToProps = (state) => ({
  agences: state.geolocs.getIn(['cityAgences', 'result']),
  ville : state.geolocs.getIn(['ville', 'result']),
})

const mapDispatchToProps = (dispatch) => ({
  setAgenceSelectionnee: (agence) => { dispatch(setAgenceSelectionnee(agence)) },
})

export default connect(mapStateToProps, mapDispatchToProps)(MapView)
