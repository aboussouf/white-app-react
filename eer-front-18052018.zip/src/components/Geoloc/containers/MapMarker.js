import { connect } from 'react-redux'
import MapMarker from '../MapMarker'
// import setAgenceSelectionnee from '../../../store/actions/Geolocs'
import { inputChange } from '../../../store/actions/Inputs'
// const mapStateToProps = (state) => ({
//   agence: state.geolocs.getIn(['agence', 'result']),
// })

const mapStateToProps = (state, props) => {
  return ({
    codeAgence: state.prospect.getIn(['codeAgence', 'value']),
  })
}

const mapDispatchToProps = (dispatch) => ({
  setAgenceSelectionnee: (value, id) => { dispatch(inputChange(value, id)) },

})

export default connect(mapStateToProps, mapDispatchToProps)(MapMarker)
