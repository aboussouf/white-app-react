import Input from './containers/Input'

export default Input
