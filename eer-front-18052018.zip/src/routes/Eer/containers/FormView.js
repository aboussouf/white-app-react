import FormView from '../components/FormView'
import { connect } from 'react-redux'

const mapStateToProps = (state, props) => {
  return ({
    dateRdv : state.prospect.getIn(['dateRdv', 'value']),
    firstName: state.prospect.getIn(['firstName', 'value']),
    lastName: state.prospect.getIn(['lastName', 'value']),
    tel: state.prospect.getIn(['tel', 'value']),
    email: state.prospect.getIn(['email', 'value']),
    prospect :{
      dateRdv : state.prospect.getIn(['dateRdv', 'value']),
      firstName: state.prospect.getIn(['firstName', 'value']),
      lastName: state.prospect.getIn(['lastName', 'value']),
      tel: state.prospect.getIn(['tel', 'value']),
      email: state.prospect.getIn(['email', 'value']),
    }
  })
}

export default connect(mapStateToProps)(FormView)
