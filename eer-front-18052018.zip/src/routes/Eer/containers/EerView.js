import EerView from '../components/EerView'
import { connect } from 'react-redux'
import { getCities, getBranchesByCity } from '../../../store/actions/Geolocs'
import { saveProspect } from '../../../store/actions/Prospect'

// import { makeSelectCitiesList, makeSelectAgencesList } from '../../../store/selectors/Geolocs'

const mapStateToProps = (state) => ({
  cities: state.geolocs.getIn(['cities', 'result']),
  prospect :  state.prospect.getIn(['prospect', 'result']),
})
const mapDispatchToProps = (dispatch) => ({
  // persistProspect: (prospect) => { dispatch(saveProspect(prospect)) },
  getCities : () => { dispatch(getCities()) },
  getAgencys: (payload) => { dispatch(getBranchesByCity(payload)) },
  saveProspect : (prospect) => { dispatch(saveProspect(prospect)) },
})

export default connect(mapStateToProps, mapDispatchToProps)(EerView)
