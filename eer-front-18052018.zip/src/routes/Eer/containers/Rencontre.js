import Rencontre from '../components/Rencontre'
import { connect } from 'react-redux'
import { inputChange } from '../../../store/actions/Inputs'

const mapStateToProps = (state, props) => {
  return ({
    dateRdv: state.prospect.getIn(['dateRdv', 'value']),
    heureRdv: state.prospect.getIn(['heureRdv', 'value']),
  })
}

const mapDispatchToProps = (dispatch) => ({
  selectHeure: (value, id) => { dispatch(inputChange(value, id)) },
})

export default connect(mapStateToProps, mapDispatchToProps)(Rencontre)
