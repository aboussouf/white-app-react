import React from 'react'
import PropTypes from 'prop-types'
// import '../../../../node_modules/bootstrap/scss/mixins/_grid-framework.scss'
// import '../../../assets/css/font-awesome.scss'
// import '../../../assets/css/custom.scss'
//  import '../../../assets/css/bootstrap-float-label.min.scss'
import '../css/buttons.scss'
import '../../../assets/css/style.scss'
import '../css/TimePicker.scss'
import Calend from '../../Calend/containers'
import TimePicker from 'rc-time-picker'
// import DatePicker from 'react-time-picker'
import moment from 'moment'
// import Moment from 'react-moment'

class Rencontre extends React.Component {
  onChange = (value) => {
    const heure = value.format('h:mm')
    this.props.selectHeure(heure, this.props.storeKey)
  }

  render () {
    const format = 'h:mm'
    const now = moment().hour(0).minute(0)
    return (

      <div className="tab-pane" role="tabpanel" id="step3">
                                <h1 className="text-md-center">Rencontrons-nous</h1>
                                <div className="row">
                                                                                                                                              <div className="col-lg-6 mb-4 sgma-background">
                                                                                                                                                             <Calend storeKey='prospect.dateRdv' />
                                                                                                                                                             <br/><br/>
                                                                                                                                                             <div className="input-group bootstrap-timepicker timepicker">
<div className='form-control input-small'>
                                                                                                                                                                             <TimePicker storeKey='prospect.heureRdv' defaultValue={now}
                showSecond={false}
                minuteStep={30}
                onChange={this.onChange}
                format={format}
              />
              </div>
                                                                                                                                                                             <span className="input-group-addon pt-3"><i className="fa fa-clock-o"></i></span>
                                                                                                                                                             </div>
                                                                                                                                              </div>
                                                                                                                                              <div className="col-lg-6 mb-4">
                                                                                                                                                <div className="card mb-4">
                                                                                                                                                             <div className="card-block">
                                                                                                                                                                             <div className="articles-container">

                                                                                                                                                                                             <div className="article border-bottom">
                                                                                                                                                                                                             <div className="col-xs-12">
                                                                                                                                                                                                                            <div className="row">
                                                                                                                                                                                                                                            <div className="col-2 date">
                                                                                                                                                                                                                                                            <div className="large fa fa-building-o"></div>
                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                            <div className="col-10">
                                                                                                                                                                                                                                                            <h4><a href="#">AGENCE</a></h4>
                                                                                                                                                                                                                                                            <p>HASSAN II CASABLANCA.</p>
                                                                                                                                                                                                                                                            <p>Horaire : 9h 13h</p>
                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                             </div>
                                                                                                                                                                                                             <div className="clear"></div>
                                                                                                                                                                                             </div>

                                                                                                                                                                                             <div className="article border-bottom">
                                                                                                                                                                                                             <div className="col-xs-12">
                                                                                                                                                                                                                            <div className="row">
                                                                                                                                                                                                                                            <div className="col-2 date">
                                                                                                                                                                                                                                                            <div className="large fa fa-calendar-check-o"></div>
                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                            <div className="col-10">
                                                                                                                                                                                                                                                            <h4><a href="#">Date</a></h4>
                                                                                                                                                                                                                                                            <p>{this.props.dateRdv}</p>
                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                             </div>
                                                                                                                                                                                                             <div className="clear"></div>
                                                                                                                                                                                             </div>

                                                                                                                                                                                             <div className="article">
                                                                                                                                                                                                             <div className="col-xs-12">
                                                                                                                                                                                                                            <div className="row">
                                                                                                                                                                                                                                            <div className="col-2 date">
                                                                                                                                                                                                                                                            <div className="large fa fa-clock-o"></div>
                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                            <div className="col-10">
                                                                                                                                                                                                                                                            <h4><a href="#">Heure</a></h4>
                                                                                                                                                                                                                                                            <p>{this.props.heureRdv}</p>
                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                             </div>
                                                                                                                                                                                                             <div className="clear"></div>
                                                                                                                                                                                             </div>

                                                                                                                                                                             </div>
                                                                                                                                                                             </div>
                                                                                                                                                             </div>
                                                                                                                                              </div>
                                </div>
                                <ul className="list-inline text-md-center">
                                    <li></li>
                                </ul>
                            </div>
    )
  }
}

Rencontre.propTypes = {
  dateRdv : PropTypes.string,
  heureRdv : PropTypes.string,
  selectHeure: PropTypes.func,
  storeKey:PropTypes.string
}

Rencontre.defaultProps = {
  dateRdv : 'Veuillez choisir une date',
  heureRdv : 'Veuillez choisir une heureRdv',
}

export default Rencontre
