import React from 'react'
import PropTypes from 'prop-types'
import Calendar from 'react-calendar'

class calend extends React.Component {
  constructor (props) {
    super(props)
  }
  state = {
    date: new Date(),
  }
  onChange = date => this.setState({ date })
  render () {
    return (
      <div>
        <Calendar
          onChange={this.onChange}
          value={this.state.date}
              />
      </div>
    )
  }
}

calend.propTypes = {
  updateValidatorOBProspect: PropTypes.func,
  visible: PropTypes.bool,
}

export default calend
