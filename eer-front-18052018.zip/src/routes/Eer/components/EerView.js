import React from 'react'
import PropTypes from 'prop-types'
import '../../../../node_modules/bootstrap/scss/mixins/_grid-framework.scss'
import '../../../assets/css/font-awesome.scss'
import '../../../assets/css/custom-stepper.scss'
import '../../../assets/css/style.scss'
import Map from '../../Map/containers'
import Rencontre from '../containers/Rencontre'
import Recap from '../containers/Recap'
import FormView from '../containers/FormView'
import Felicitation from './Felicitations'

class EerView extends React.Component {
  constructor () {
    super()

    this.state = {
      selectedStep : 1,
    }
  }

  componentWillMount () {
    this.props.getCities()
  }

  next = () => {
    if (this.state.selectedStep <= 4) {
      this.setState({
        selectedStep : this.state.selectedStep + 1
      })
    } else {
      this.setState({
        selectedStep : 1

      })
    }
  }
  form = () => {
    this.setState({
      selectedStep : 1
    })
  }
  navBar = (index) => {
    index === 1 ? this.setState({
      selectedStep : 1
    })
      : index === 2 ? this.setState({
        selectedStep : 2
      })
        : index === 3 ? this.setState({
          selectedStep : 3
        })
          : index === 4 ? this.setState({
            selectedStep : 4
          })
            : index === 5 ? this.setState({
              selectedStep : 5
            }) : this.setState({
              selectedStep : 5
            })
  }

  render () {
    return (
      <div>
        <div className='row mb-5'>
          <div className='col-xs-12 col-sm-4 col-lg-3 col-xl-2' />
          <main className='col-xs-12 col-sm-4 col-lg-6 col-xl-8 '>
            <section className='row'>
              <div className='col-sm-12'>
                <section className='row'>
                  <div className='col-12'>
                    <div className='card mb-4 without-border'>
                      <div className='card-block'>

                        <form className='form cf'>
                          <div className='wizard'>
                            <div className='wizard-inner'>
                              <div className='connecting-line' />
                              <ul className='nav nav-tabs'>
                                <li className='nav-item'>
                                  <a data-toggle='tab' aria-controls='step1'
                                    onClick={() => this.navBar(1)}
                                    role='tab' title='Informations de base'
                                    className={`nav-link${this.state.selectedStep === 1 ? ' active' : ' disabled'}`}>
                                    <span className='round-tab'>
                                      <i className='fa fa-pencil' />
                                    </span>
                                  </a>
                                </li>
                                <li className='nav-item'>
                                  <a data-toggle='tab'
                                    onClick={() => this.navBar(2)}
                                    aria-controls='step2' role='tab'
                                    title='Agence'
                                    className={`nav-link${this.state.selectedStep === 2 ? ' active' : ' disabled'}`}>
                                    <span className='round-tab'>
                                      <i className='fa fa-map-marker' />
                                    </span>
                                  </a>
                                </li>
                                <li role='presentation' className='nav-item'>
                                  <a href='#step3' data-toggle='tab'
                                    onClick={() => this.navBar(3)}
                                    aria-controls='step3' role='tab'
                                    title='Rendez-vous'
                                    className={`nav-link${this.state.selectedStep === 3 ? ' active' : ' disabled'}`}>
                                    <span className='round-tab'>
                                      <i className='fa fa-calendar' />
                                    </span>
                                  </a>
                                </li>
                                <li role='presentation' className='nav-item'>
                                  <a href='#step4' data-toggle='tab'
                                    onClick={() => this.navBar(4)}
                                    aria-controls='step4' role='tab'
                                    title='Récapitulatif'
                                    className={`nav-link${this.state.selectedStep === 4 ? ' active' : ' disabled'}`}>
                                    <span className='round-tab'>
                                      <i className='fa fa-share-square-o' />
                                    </span>
                                  </a>
                                </li>
                                <li role='presentation' className='nav-item'>
                                  <a href='#step5' data-toggle='tab'
                                    onClick={() => this.navBar(5)}
                                    aria-controls='step5' role='tab'
                                    title='Validation'
                                    className={`nav-link${this.state.selectedStep === 5 ? ' active' : ' disabled'}`}>
                                    <span className='round-tab'>
                                      <i className='fa fa-check' />
                                    </span>
                                  </a>
                                </li>
                              </ul>
                            </div>

                            {
                              this.state.selectedStep === 1 ? <FormView />
                                : this.state.selectedStep === 2 ? <Map storeKey='prospect.cityAgences' />
                                  : this.state.selectedStep === 3 ? <Rencontre storeKey='prospect.heureRdv' />
                                    : this.state.selectedStep === 4 ? <Recap action={this.form} />
                                      : this.state.selectedStep === 5 ? <Felicitation /> : <FormView />
                            }
                          </div>
                        </form>

                        <ul className='list-inline text-md-center'>
                          <li><button type='button'
                            onClick={this.next}
                            className='btn btn-lg btn-primary next-step next-button'
                          >Suivant</button></li>
                        </ul>

                      </div>
                    </div>
                  </div>
                </section>
              </div>
            </section>

          </main>
          <div className='col-xs-12 col-sm-4 col-lg-3 col-xl-2' />
        </div>
      </div>
    )
  }
}
EerView.propTypes = {
  // cities: PropTypes.object.isRequired,
  getCities : PropTypes.func,
  // agences: PropTypes.array.isRequired,
  // getAgencys: PropTypes.func,
}

export default EerView
