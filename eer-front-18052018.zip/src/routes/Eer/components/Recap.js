import React from 'react'
import PropTypes from 'prop-types'
import '../../../../node_modules/bootstrap/scss/mixins/_grid-framework.scss'
import '../../../assets/css/font-awesome.scss'
import '../../../assets/css/custom.scss'
import '../../../assets/css/bootstrap-float-label.min.scss'
import '../css/buttons.scss'

class Recap extends React.Component {
  render () {
    console.log('Rencontre :', this.props)
    return (
      <div className='tab-pane' role='tabpanel' id='step4'>
        <h1 className='text-md-center'>Récapitulatif</h1>
        <div className='row'>
          <div className='col-lg-6 mb-4'>
            <div className='card mb-4'>
              <div className='card-block'>
                <div className='articles-container'>

                  <div className='article border-bottom'>
                    <div className='col-xs-12'>
                      <div className='row'>
                        <div className='col-2 date'>
                          <div className='large fa fa-building-o' />
                        </div>
                        <div className='col-10'>
                          <h4><a href='#'>AGENCE</a></h4>
                          <p>HASSAN II CASABLANCA.</p>
                          <p>Horaire : 9h 13h</p>
                        </div>
                      </div>
                    </div>
                    <div className='clear' />
                  </div>

                  <div className='article border-bottom'>
                    <div className='col-xs-12'>
                      <div className='row'>
                        <div className='col-2 date'>
                          <div className='large fa fa-calendar-check-o' />
                        </div>
                        <div className='col-10'>
                          <h4><a href='#'>Date</a></h4>
                          <p>{this.props.dateRdv}</p>
                        </div>
                      </div>
                    </div>
                    <div className='clear' />
                  </div>

                  <div className='article'>
                    <div className='col-xs-12'>
                      <div className='row'>
                        <div className='col-2 date'>
                          <div className='large fa fa-clock-o' />
                        </div>
                        <div className='col-10'>
                          <h4><a href='#'>Heure</a></h4>
                          <p>{this.props.heureRdv}</p>
                        </div>
                      </div>
                    </div>
                    <div className='clear' />
                  </div>

                </div>
              </div>
            </div>
          </div>
          <div className='col-lg-6 mb-4'>
            <div className='card'>
              <div className='card-header bg-primary'>
                <h5 className='text-md-center white-text'>Informations de base</h5>
              </div>
              <div className='card-block'>
                <div className='form-group row'>
                  <div className='form-group input-group row'>
                    <span className='col-md-12 has-float-label'>
                      <input className='form-control' id='first' disabled
                        type='text' placeholder=' ' value={this.props.lastName} />
                      <label htmlFor='first'>&#160; Nom</label>
                    </span>
                  </div>
                  <div className='form-group input-group row'>
                    <span className='col-md-12 has-float-label'>
                      <input className='form-control' id='first' disabled
                        type='text' placeholder=' ' value={this.props.firstName} />
                      <label htmlFor='first'>&#160; Prénom</label>
                    </span>
                  </div>
                  <div className='form-group input-group row'>
                    <label className='col-md-12 has-float-label'>
                      <input className='form-control' type='text' disabled
                        placeholder=' ' value={this.props.tel} />
                      <span>&#160; Tél</span>
                    </label>
                  </div>
                  <div className='form-group input-group row'>
                    <label className='col-md-12 has-float-label'>
                      <input className='form-control' type='text' disabled
                        placeholder=' ' value={this.props.email} />
                      <span>&#160; Email</span>
                    </label>
                  </div>
                </div>
                <ul className='list-inline text-md-center'>
                  <li><button
                    className='btn btn-lg btn-primary next-step next-button'
                    onClick={this.props.action}>
                  Modifier</button></li>
                </ul>
              </div>
            </div>
          </div>
          <div className="col-xs-12 col-sm-12 col-lg-12 col-xl-12">
									     	<h5 className="text-md-center black-text">Votre boisson</h5>
									<div className="list-inline text-md-center">
 									  <label className="btn active">
   										 <input type="radio" name='tempUnit' id="celcius" value="celcius" checked/><i className="fa fa-circle-o fa-2x"></i><i className="fa fa-check-circle-o fa-2x"></i><span> Thé</span>
  									  </label>
                                      <label className="btn">
                                         <input type="radio" name='tempUnit' id="fahrenheit" value="fahrenheit"/><i className="fa fa-circle-o fa-2x"></i><i className="fa fa-check-circle-o fa-2x"></i><span> Café</span>
                                     </label>
                               </div>
                               </div>
          <div className='checkbox mt-1 mb-2'>
            <div className='custom-control custom-checkbox'>
              <input type='checkbox' className='custom-control-input' id='customCheck1' />
              <label className='custom-control-label custom-control-description'
                htmlFor='customCheck1'>J accepte les <a target='_blank'
                  href='https://www.sgmaroc.com/conditions-generales-dutilisation/'>
              conditions générales</a></label>
            </div>
          </div>
        </div>

      </div>
    )
  }
}

Recap.propTypes = {
  dateRdv : PropTypes.string,
  heureRdv : PropTypes.string,
  firstName: PropTypes.string,
  lastName: PropTypes.string,
  tel: PropTypes.string,
  email: PropTypes.string,
  prospect: PropTypes.object,
  action: PropTypes.func,
}
export default Recap
