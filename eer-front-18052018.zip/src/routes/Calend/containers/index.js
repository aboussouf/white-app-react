import Calend from '../components/Calend'
import { connect } from 'react-redux'
// import { updateValidatorOBProspect } from '../../../store/actions/Prospect'
import { inputChange } from '../../../store/actions/Inputs'

const mapStateToProps = (state, props) => {
  const [store, ...storeKey] = props.storeKey.split('.')
  storeKey.push('value')
  return ({
    value: state[store].getIn(storeKey),
  })
}

const mapDispatchToProps = (dispatch) => ({
  selectDate: (value, id) => { dispatch(inputChange(value, id)) },
})

export default connect(mapStateToProps, mapDispatchToProps)(Calend)
