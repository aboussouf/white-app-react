import MapView from '../components/MapView'
import { connect } from 'react-redux'
import { getBranchesByCity } from '../../../store/actions/Geolocs'

const mapStateToProps = (state) => ({
  cities: state.geolocs.getIn(['cities', 'result']),
  agences: state.geolocs.getIn(['cityAgences', 'result']),
  selectedVille: state.prospect.getIn(['ville', 'value']),
  agenceSelectionnee: state.prospect.get('agence'),
})

const mapDispatchToProps = (dispatch) => ({
  getAgencys: (payload) => { dispatch(getBranchesByCity(payload)) },
})

export default connect(mapStateToProps, mapDispatchToProps)(MapView)
