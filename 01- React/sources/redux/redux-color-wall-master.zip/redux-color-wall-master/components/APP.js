import { Colors, AddColor, Menu } from './containers'

const APP = () => <div>
    <Menu />
    <AddColor />
    <Colors />
</div>;

module.exports = APP;