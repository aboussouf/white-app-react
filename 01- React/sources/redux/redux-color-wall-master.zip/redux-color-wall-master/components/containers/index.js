import AddColor from './AddColor'
import Colors from './Colors'
import Menu from './Menu'

module.exports = {AddColor, Colors, Menu};