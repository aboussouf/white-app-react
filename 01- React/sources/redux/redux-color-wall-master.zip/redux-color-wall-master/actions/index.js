import { addColor, rateColor, removeColor } from './colors'
import { sortColors } from './sort'

module.exports = {addColor, rateColor, removeColor, sortColors};