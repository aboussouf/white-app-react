import colors from './colors'
import color from './color'
import sort from './sort'

module.exports = {colors, color, sort};