Color Manager Redux
==================
An application created with `create-react-app` and `color-manager-redux` to demonstrate
the process behind building React/Redux applications using BDD and cucumber.
