const error = f => f

const clearError = f => f

module.exports = {error, clearError}