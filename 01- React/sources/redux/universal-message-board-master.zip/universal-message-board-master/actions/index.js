import socket from './socket'
import messages from './messages'
import errors from './errors'

module.exports = {...socket,...messages,...errors}