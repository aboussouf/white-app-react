import message from './message'

module.exports = {message}