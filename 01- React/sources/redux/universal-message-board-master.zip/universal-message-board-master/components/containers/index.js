import Messages from './Messages'
import Message from './Message'

module.exports = {Messages,Message}