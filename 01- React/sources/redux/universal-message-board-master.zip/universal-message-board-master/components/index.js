import containers from './containers'
import ui from './ui'
import App from './App'

module.exports = {...containers, ...ui, App}