const Whoops404 = () =>
    <h1>Whoops404</h1>

module.exports = Whoops404