const Error = ({ error }) =>
    <h1>Error</h1>

module.exports = Error