require('babel-core/register');

module.exports = require('./server');
