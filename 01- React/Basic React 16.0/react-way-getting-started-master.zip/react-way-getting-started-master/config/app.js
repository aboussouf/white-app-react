var config = {};

config.title = 'My React App';

module.exports = config;
