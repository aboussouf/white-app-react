package sg.df.prospect.domain.type;

public enum TrancheRevenu {
    ENTRE_0_7500("Entre 0 et 7500",0), ENTRE_7500_10000("entre 7 500 et 10 000 MAD",1),
    ENTRE_10000_25000("entre 10000 et 25 000 MAD",2),ENTRE_25000_40000("entre 25000 et 40 000 MAD",3),PLUS_40000("Plus de 40 000 MAD",4) ;
    private String libelleTranche;
    private Integer order;

    TrancheRevenu(String libelleTranche , Integer order ) {
        this.libelleTranche = libelleTranche;
        this.order = order;
    }
}


