package sg.df.prospect.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.ResourceSupport;
import sg.df.prospect.domain.type.*;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
public class ProspectDTO extends ResourceSupport implements Serializable {
    private Long idProspect;
    @NotNull
    private String firstName;
    @NotNull
    private String lastName;
    private String birthDate;
    private String numeroTel;
    @NotNull
    private String numeroMobile;
    @NotNull
    private String email;
    private Sexe sexe;
    @NotNull
    private Civilite civilite;
    @NotNull
    private Boolean acceptCgu;
    @NotNull
    private TypeBoisson boisson;
    @NotNull
    private Date dateRdv;
    @NotNull
    private String heureRdv;
    @NotNull
    private TypeProspect typeProspect;
    @NotNull
    private String codeAgence;
    @NotNull
    private String identifiantProspect;
    @NotNull
    private Boolean validateOB;
    private String address;
    private String addressComplement;
    private String zipCode;
    private Long idCity;
    private Long idBirthCity;
    private SituationFamiliale situationFamiliale;
    private NbrEnfACharge nbrEnfACharge;
    private StatutProfessionnel statutProfessionnel;
    private String secteurActivite;
    private TrancheRevenu trancheRevenu;
    private AgenceDTO agenceDTO;
    private Piece piece;
    private String numeroPiece;


}
