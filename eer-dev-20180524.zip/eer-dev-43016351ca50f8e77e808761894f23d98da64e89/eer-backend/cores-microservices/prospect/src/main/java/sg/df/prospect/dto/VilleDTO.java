package sg.df.prospect.dto;

import lombok.*;
import org.springframework.hateoas.ResourceSupport;

import java.io.Serializable;


@Data
@NoArgsConstructor
public class VilleDTO extends ResourceSupport implements Serializable {
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private  static  final  long serialVersionUID =  1350092881346723535L;
    @NonNull
    private Long idVille;
    @NonNull
    private String libelle;
}
