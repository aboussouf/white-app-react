package sg.df.prospect.util;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.support.LdapNameBuilder;
import sg.df.prospect.dto.ProspectDTO;

import javax.naming.Name;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

@Configuration
public class LdapConfiguration {
        Logger logger = LoggerFactory.getLogger(LdapConfiguration.class) ;

        @Value("${ldap.url}")
        private String ldapUrl  ;
        @Value("${ldap.base}")
        private String ldapBase  ;
        @Value("${ldap.username}")
        private String ldapUser  ;
        @Value("${ldap.password}")
        private String ldapPassword  ;

        @Bean
        public LdapContextSource contextSource() {
                LdapContextSource contextSource= new LdapContextSource();
                contextSource.setUrl(ldapUrl);
                contextSource.setBase(ldapBase);
                contextSource.setUserDn(ldapUser);
                contextSource.setPassword(ldapPassword);
                return contextSource;
        }
        @Bean
        public LdapTemplate ldapTemplate() {
                return new LdapTemplate(contextSource());
        }


        public void authenticate(String username, String password) {
                contextSource().getContext("cn="+username +","+ldapBase , password);
        }

        public boolean createIfNotExist(ProspectDTO prospectDTO,String password) throws UnsupportedEncodingException {
                return true ;
        }
        public void create(String username, String password) {
                Name dn = LdapNameBuilder
                        .newInstance()
                        .add("cn", username)
                        .build();
                DirContextAdapter context = new DirContextAdapter(dn);

                context.setAttributeValues(
                        "objectclass",
                        new String[]
                                { "top",
                                        "person",
                                        "organizationalPerson",
                                        "inetOrgPerson" });
                context.setAttributeValue("cn", username);
                context.setAttributeValue("sn", username);
                context.setAttributeValue("givenName", username);
                context.setAttributeValue("mail", username);
                context.setAttributeValue("userPassword", digestSHA(password));
                ldapTemplate().bind(context);
        }
        private String digestSHA(final String password) {
                String base64;
                try {
                        MessageDigest digest = MessageDigest.getInstance("SHA");
                        digest.update(password.getBytes());
                        base64 = Base64
                                .getEncoder()
                                .encodeToString(digest.digest());
                } catch (NoSuchAlgorithmException e) {
                        throw new RuntimeException(e);
                }
                return "{SHA}" + base64;
        }


        public void modify(final String username, final String password) {
                Name dn = LdapNameBuilder
                        .newInstance()
                        .add("ou", "users")
                        .add("cn", username)
                        .build();
                DirContextOperations context = ldapTemplate().lookupContext(dn);

                context.setAttributeValues("objectclass", new String[]{"top", "person", "organizationalPerson", "inetOrgPerson"});
                context.setAttributeValue("cn", username);
                context.setAttributeValue("sn", username);
                context.setAttributeValue("userPassword", digestSHA(password));

                ldapTemplate().modifyAttributes(context);
        }


  /*  public List<String> getAllPersonNames() {
        return ldapTemplate().search(
                query().where("objectClass").is("person"),
                new AttributesMapper<String>() {
                    public String mapFromAttributes(Attributes attrs)
                            throws NamingException {
                        return (String) attrs.get("cn").get();
                    }
                });
    }*/




}
