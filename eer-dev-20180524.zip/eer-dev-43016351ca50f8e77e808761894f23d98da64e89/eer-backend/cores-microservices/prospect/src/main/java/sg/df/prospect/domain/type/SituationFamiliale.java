package sg.df.prospect.domain.type;

public enum SituationFamiliale {
    CELIBATAIRE("Celibataire"), MARIE("Marie") , DIVORCE("Divorce"),VEUF("Veuf") ;
    private String situationFamiliale ;
    SituationFamiliale(String situationFamiliale) {
        this.situationFamiliale = situationFamiliale;
    }
}
