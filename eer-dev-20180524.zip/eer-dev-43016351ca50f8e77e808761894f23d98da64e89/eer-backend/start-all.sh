#!/usr/bin/env bash
cd supports/eureka
mvn spring-boot:run
cd ../..
cd supports/gateway
mvn spring-boot:run
cd ../..
cd cores-microservices/prospect
mvn spring-boot:run
cd ../..
cd cores-microservices/geoloc
mvn spring-boot:run

