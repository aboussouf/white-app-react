import React from 'react'
import PropTypes from 'prop-types'
import '../../../../node_modules/bootstrap/scss/mixins/_grid-framework.scss'
import '../../../assets/css/font-awesome.scss'
import '../../../assets/css/custom.scss'
import '../../../assets/css/bootstrap-float-label.min.scss'
import '../css/buttons.scss'
import InputText from '../../../components/InputFloatLabel/containers/Input'
import * as constants from '../../../utils/constants'

class FormView extends React.Component {
  render () {
    console.log('Rencontre :', this.props)
    return (
      <div>
        <div className='tab-content'>
          <div className='tab-pane active text-center' role='tabpanel' id='step1'>
            <h3 className='text-md-center'>Informations de base</h3>
            <div className='row'>

              <InputText storeKey='prospect.lastName'
                name='lastName'
                error='Veuillez saisir un nom valide'
                className='form-control'
                placeholder=' '
                pattern={constants.REGEX_PROSPECT_NAME}
                label='Nom' />

              <InputText storeKey='prospect.firstName'
                name='firstName'
                className='form-control'
                placeholder=' '
                error='Veuillez saisir un prénom valide'
                pattern={constants.REGEX_PROSPECT_NAME}
                label='Prenom' />

              <InputText storeKey='prospect.tel'
                name='tele'
                className='form-control'
                placeholder=' '
                error='Veuillez saisir un téléphone valide'
                pattern={constants.REGEX_PROSPECT_PHONE}
                label='Tél' />

              <InputText storeKey='prospect.email'
                name='email'
                className='form-control'
                placeholder=' '
                error='Veuillez saisir un email valide'
                pattern={constants.REGEX_PROSPECT_EMAIL}
                label='Email' />

            </div>

          </div>

        </div>
      </div>
    )
  }
}

FormView.propTypes = {
  prospect : PropTypes.object,
}

export default FormView
