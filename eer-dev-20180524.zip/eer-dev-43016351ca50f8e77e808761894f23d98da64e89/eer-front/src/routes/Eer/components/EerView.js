import React from 'react'
import PropTypes from 'prop-types'
import '../../../../node_modules/bootstrap/scss/mixins/_grid-framework.scss'
import '../../../assets/css/font-awesome.scss'
import '../../../assets/css/custom-stepper.scss'
import '../../../assets/css/style.scss'
import Map from '../../Map/containers'
import Rencontre from '../containers/Rencontre'
import Recap from '../containers/Recap'
import FormView from '../containers/FormView'
import Felicitations from '../containers/Felicitations'
import bannerBottomEER from '../../../assets/images/banner2_df_sogetel.png'

class EerView extends React.Component {
  constructor () {
    super()

    this.state = {
      selectedStep : 1,
    }
  }

  componentWillMount () {
    this.props.getCities()
  }

  next = () => {
    if (this.state.selectedStep === 1) {
      if ((this.props.numeroMobile === undefined || this.props.numeroMobile === '') ||
        (this.props.firstName === undefined || this.props.firstName === '') ||
        (this.props.lastName === undefined || this.props.lastName === '') ||
        (this.props.email === undefined || this.props.email === '')) {
        console.log('Mobile')
      } else {
        this.setState({
          selectedStep : 2
        })
      }
    } else if (this.state.selectedStep === 2) {
      if (this.props.agenceSelectionnee === undefined) {

      } else {
        this.setState({
          selectedStep : 3
        })
      }
    } else if (this.state.selectedStep === 3) {
      if ((this.props.dateRdv === undefined || this.props.dateRdv === '') ||
        (this.props.heureRdv === undefined || this.props.heureRdv === '')) {

      } else {
        this.setState({
          selectedStep : 4
        })
      }
    } else if (this.state.selectedStep === 4) {
      this.setState({
        selectedStep : 5
      })
    }
  }
  valid = () => {
    console.log('valid', this.props.acceptCgu)
    if ((this.props.acceptCgu === undefined || this.props.acceptCgu === false) || (this.props.boisson === undefined)) {

    } else {
      console.log('valid', this.props.prospect)
      this.props.saveProspect(this.props.prospect)
      this.next()
      var x = document.getElementById('myBt')
      x.style.display = 'none'
    }
  }

  form = () => {
    this.setState({
      selectedStep : 1
    })
  }
  navBar = (index) => {
    if (index === 1) {
      if (this.state.selectedStep !== 5) {
        this.setState({
          selectedStep : 1
        })
      }
    } else if (index === 2) {
      if (index <= this.state.selectedStep && this.state.selectedStep !== 5) {
        this.setState({
          selectedStep : 2
        })
      }
    } else if (index === 3) {
      if (index <= this.state.selectedStep && this.state.selectedStep !== 5) {
        this.setState({
          selectedStep : 3
        })
      }
    } else if (index === 4) {
      if (index <= this.state.selectedStep && this.state.selectedStep !== 5) {
        this.setState({
          selectedStep : 4
        })
      }
    } else if (index === 5) {
      this.setState({
        selectedStep : 5
      })
    }
  }

  render () {
    return (
      <div>
        <div className='row mb-5'>
          <div className='col-xs-12 col-sm-4 col-lg-3 col-xl-2' />
          <main className='col-xs-12 col-sm-4 col-lg-6 col-xl-8 '>
            <section className='row'>
              <div className='col-sm-12'>
                <section className='row'>
                  <div className='col-12'>
                    <div className='card mb-4 without-border'>
                      <div className='card-block'>

                        <form className='form cf'>
                          <div className='wizard'>
                            <div className='wizard-inner'>
                              <div className='connecting-line' />
                              <ul className='nav nav-tabs'>
                                <li className='nav-item'>
                                  <a data-toggle='tab' aria-controls='step1'
                                    onClick={() => this.navBar(1)}
                                    role='tab' title='Informations de base'
                                    className={`nav-link${this.state.selectedStep === 1 ? ' active' : ' disabled'}`}>
                                    <span className='round-tab'>
                                      <i className='fa fa-pencil' />
                                    </span>
                                  </a>
                                </li>
                                <li className='nav-item'>
                                  <a data-toggle='tab'
                                    onClick={() => this.navBar(2)}
                                    aria-controls='step2' role='tab'
                                    title='Agence'
                                    className={`nav-link${this.state.selectedStep === 2 ? ' active' : ' disabled'}`}>
                                    <span className='round-tab'>
                                      <i className='fa fa-map-marker' />
                                    </span>
                                  </a>
                                </li>
                                <li role='presentation' className='nav-item'>
                                  <a data-toggle='tab'
                                    onClick={() => this.navBar(3)}
                                    aria-controls='step3' role='tab'
                                    title='Rendez-vous'
                                    className={`nav-link${this.state.selectedStep === 3 ? ' active' : ' disabled'}`}>
                                    <span className='round-tab'>
                                      <i className='fa fa-calendar' />
                                    </span>
                                  </a>
                                </li>
                                <li role='presentation' className='nav-item'>
                                  <a data-toggle='tab'
                                    onClick={() => this.navBar(4)}
                                    aria-controls='step4' role='tab'
                                    title='Récapitulatif'
                                    className={`nav-link${this.state.selectedStep === 4 ? ' active' : ' disabled'}`}>
                                    <span className='round-tab'>
                                      <i className='fa fa-share-square-o' />
                                    </span>
                                  </a>
                                </li>
                                <li role='presentation' className='nav-item'>
                                  <a data-toggle='tab'

                                    aria-controls='step5' role='tab'
                                    title='Validation'
                                    className={`nav-link${this.state.selectedStep === 5 ? ' active' : ' disabled'}`}>
                                    <span className='round-tab'>
                                      <i className='fa fa-check' />
                                    </span>
                                  </a>
                                </li>
                              </ul>
                            </div>

                            {
                              this.state.selectedStep === 1 ? <FormView />
                                : this.state.selectedStep === 2 ? <Map storeKey='prospect.cityAgences' />
                                  : this.state.selectedStep === 3 ? <Rencontre storeKey='prospect.heureRdv' />
                                    : this.state.selectedStep === 4 ? <Recap action={this.form} storeKey='prospect.acceptCgu' />
                                      : this.state.selectedStep === 5 ? <Felicitations /> : <FormView />
                            }
                          </div>
                        </form>

                        <ul className='list-inline text-md-center'>
                          <li><button type='button' id='myBt'
                            // onClick={this.next}
                            onClick={this.state.selectedStep === 4 ? this.valid : this.next}
                            className='btn btn-lg btn-primary next-step next-button hidden'
                          >            {this.state.selectedStep === 4 ? 'Valider' : 'Suivant'}</button></li>
                        </ul>

                      </div>
                    </div>
                  </div>
                </section>
              </div>
            </section>

          </main>
          <div className='col-xs-12 col-sm-4 col-lg-3 col-xl-2' />
        </div>
        <div className="row fixed-bottom">
			<div className="col-xs-12 col-sm-12 col-lg-12 col-xl-12">
					<img src={bannerBottomEER} alt="Societe Generale" />
			</div>
		</div>
      </div>

    )
  }
}
EerView.propTypes = {
  // cities: PropTypes.object.isRequired,
  getCities : PropTypes.func,
  saveProspect : PropTypes.func,
  prospect : PropTypes.object,
  numeroMobile:  PropTypes.string,
  firstName: PropTypes.string,
  lastName: PropTypes.string,
  email: PropTypes.string,
  agenceSelectionnee: PropTypes.object,
  dateRdv: PropTypes.string,
  heureRdv: PropTypes.string,
  acceptCgu:PropTypes.bool,
  boisson : PropTypes.string,
  // agences: PropTypes.array.isRequired,
  // getAgencys: PropTypes.func,
}

export default EerView
