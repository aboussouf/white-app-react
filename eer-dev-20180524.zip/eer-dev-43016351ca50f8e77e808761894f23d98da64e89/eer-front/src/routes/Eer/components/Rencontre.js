import React from 'react'
import PropTypes from 'prop-types'
import '../css/buttons.scss'
import '../../../assets/css/style.scss'
import '../css/TimePicker.scss'
import Calend from '../../Calend/containers'
import TimePicker from 'rc-time-picker'
import moment from 'moment'

class Rencontre extends React.Component {
  constructor () {
    super()

    this.state = {
      dateRenc : '',
    }
  }
  componentWillMount () {
    this.props.getRdvPrisParAgence(this.props.agenceSelectionnee.get('codeAgence'))
  }
  onChange = (value) => {
    const heure = value.format('HH:mm')
    this.props.selectHeure(heure, this.props.storeKey)
    //
  }
  formatDate= (date) => {
    // : 'Veuillez choisir une date'
    if (date !== 'Veuillez choisir une date') {
      var d = new Date(date),
        monthNames = [
          'Janvier', 'Février', 'Mars',
          'Avril', 'Mai', 'Juin', 'Juillet',
          'Aout', 'Septembre', 'Octobre',
          'Novembre', 'Décembre'
        ],
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear()
      console.log('year', day + ' ' + monthNames[month])

      return day + ' ' + monthNames[month - 1]
    } else {
      return 'Veuillez choisir une date'
    }
  }
  componentDidUpdate (prevProps, prevState) {
    console.log('componentDidUpdate')
    if (prevProps.dateRdv !== this.props.dateRdv) {
      console.log('loadmap.agences1', this.formatDate(this.props.dateRdv))
    }
  }

  render () {
    const format = 'HH:mm'
    const now = moment().hour(0).minute(0)
    console.log('date', this.props.dateRdv)
    // console.log('date : ',new Date(occup) )
    // this.setState({
    //   dateRenc : this.props.dateRdv,
    // })
    return (

      <div className='tab-pane' role='tabpanel' id='step3'>
        <h1 className='text-md-center'>Rencontrons-nous</h1>
        <div className='row'>
          <div className='col-lg-6 mb-4 sgma-background'>
            <Calend storeKey='prospect.dateRdv' />
            <br /><br />
            <div className='input-group bootstrap-timepicker timepicker'>

              <TimePicker storeKey='prospect.heureRdv' defaultValue={now}
                style={{ width: '100%',
                  height :100 }}
                showSecond={false}
                minuteStep={30}
                onChange={this.onChange}
                format={format}
              />

              <span className='input-group-addon pt-3' />
            </div>
          </div>
          <div className='col-lg-6 mb-4'>
            <div className='card mb-4'>
              <div className='card-block'>
                <div className='articles-container'>

                  <div className='article border-bottom'>
                    <div className='col-xs-12'>
                      <div className='row'>
                        <div className='col-2 date'>
                          <div className='large fa fa-building-o' />
                        </div>
                        {this.props.agenceSelectionnee && this.props.agenceSelectionnee.libelleAgence !== ''
                          ? <div className='col-10'>
                            <h4><a>AGENCE</a></h4>
                            <p>{this.props.agenceSelectionnee.get('libelleAgence')}</p>
                            <p>Horaire : 9h 13h</p>
                          </div>
                          : null }
                      </div>
                    </div>
                    <div className='clear' />
                  </div>

                  <div className='article border-bottom'>
                    <div className='col-xs-12'>
                      <div className='row'>
                        <div className='col-2 date'>
                          <div className='large fa fa-calendar-check-o' />
                        </div>
                        <div className='col-10'>
                          <h4><a>Date</a></h4>
                          <p>{this.formatDate(this.props.dateRdv)}</p>
                        </div>
                      </div>
                    </div>
                    <div className='clear' />
                  </div>

                  <div className='article'>
                    <div className='col-xs-12'>
                      <div className='row'>
                        <div className='col-2 date'>
                          <div className='large fa fa-clock-o' />
                        </div>
                        <div className='col-10'>
                          <h4><a>Heure</a></h4>
                          <p>{this.props.heureRdv}</p>
                        </div>
                      </div>
                    </div>
                    <div className='clear' />
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
        <ul className='list-inline text-md-center'>
          <li />
        </ul>
      </div>
    )
  }
}

Rencontre.propTypes = {
  dateRdv : React.PropTypes.instanceOf(Date),
  heureRdv : PropTypes.string,
  selectHeure: PropTypes.func,
  storeKey:PropTypes.string,
  agenceSelectionnee: PropTypes.object,
  getRdvPrisParAgence : PropTypes.func,
}

Rencontre.defaultProps = {
  dateRdv : 'Veuillez choisir une date',
  heureRdv : 'Veuillez choisir une heure',
}

export default Rencontre
