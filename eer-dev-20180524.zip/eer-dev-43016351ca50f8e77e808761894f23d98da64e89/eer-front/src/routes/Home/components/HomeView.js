import React from 'react'
import bannerEER from '../../../assets/images/bannerEER.jpg'
import './HomeView.scss'
import '../../../assets/css/custom.scss'

export const HomeView = () => (
  <div>
    <div className='col-xs-12 col-sm-12 col-lg-12 col-xl-12'>
      <img src={bannerEER} alt='Societe Generale' />
    </div>
  </div>
)
export default HomeView
