import React from 'react';
import { shallow } from 'enzyme';
import { expect } from 'chai';
import { spy } from 'sinon';
import Radio from '../../components/Kit/Inputs/Radio';

describe('Radio', () => {
  let inputChange = null;

  beforeEach(() => {
    inputChange = spy();
  });

  it('renders a radio button per item', () => {
    const items = [
      { label: 'Yes', value: 'Yes', isDisabled: false },
      { label: 'No', value: 'No', isDisabled: false },
    ];

    const wrapper = shallow(<Radio items={items} storeKey="myStore.myRadio" inputChange={inputChange} />);
    expect(wrapper.find('input[type="radio"]')).to.have.length(2);
  });

  it('renders a checkbox button per item when multiple selection is allowed', () => {
    const items = [
      { label: 'Yes', value: 'Yes', isDisabled: false },
      { label: 'No', value: 'No', isDisabled: false },
    ];

    const wrapper = shallow(<Radio multiple items={items} storeKey="myStore.myRadio" />);
    expect(wrapper.find('input[type="checkbox"]')).to.have.length(2);
  });

  it('renders the given text as a label', () => {
    const items = [
      { label: 'Yes', value: 'Yes', isDisabled: false },
      { label: 'No', value: 'No', isDisabled: false },
    ];
    const wrapper = shallow(<Radio items={items} storeKey="myStore.myRadio" inputChange={inputChange} />);
    expect(wrapper.find('label')).to.have.length(2);
    const texts = wrapper.find('label').map((node) => node.text());
    expect(texts).to.eql(['Yes', 'No']);
  });

  it('disables the item when isDisabled is passed', () => {
    const items = [
      { label: 'Yes', value: 'Yes', isDisabled: true },
      { label: 'No', value: 'No', isDisabled: false },
      { label: 'Maybe', value: 'Maybe' },
    ];

    const wrapper = shallow(<Radio items={items} storeKey="myStore.myRadio" inputChange={inputChange} />);
    const texts = wrapper.find('input').map((node) => node.props().disabled);
    expect(texts).to.eql([true, false, false]);
  });

  it('selects an item by default when a value is passed', () => {
    const items = [
      { label: 'Yes', value: 'Yes' },
      { label: 'No', value: 'No' },
      { label: 'Maybe', value: 'Maybe' },
    ];

    const wrapper = shallow(
      <Radio items={items} storeKey="myStore.myRadio" value="No" />
    );
    const texts = wrapper.find('input').map((node) => node.props().checked);
    expect(texts).to.eql([false, true, false]);
  });

  it('dispatches an event when the radio changes value', () => {
    const items = [
      { label: 'No !', value: 'nope' },
      { label: 'Hello', value: 'hello' },
      { label: 'World', value: 'world' },
    ];
    const event = {
      target: {
        value: 'hello',
      },
    };
    const wrapper = shallow(
      <Radio items={items} storeKey="hu.tch" inputChange={inputChange} value="nope" />
    );
    wrapper.find('input[type="radio"]').first().simulate('change', event);
    expect(inputChange.called).to.equal(true);
  });
});
