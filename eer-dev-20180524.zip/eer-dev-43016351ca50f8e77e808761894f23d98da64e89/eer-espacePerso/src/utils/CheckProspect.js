import React, { Component } from 'react'
import { connect } from 'react-redux'
import { hashHistory } from 'react-router'

export default function reloaded (PureComponent) {
  function mapStateToProps (state) {
    return {
      exist: state.prospect.getIn(['prospect', 'result']),
    }
  }

  class Reloaded extends Component {
    componentWillMount () {
      this.checkProspect(this.props)
    }

    componentWillReceiveProps (nextProps) {
      this.checkProspect(nextProps)
    }

    checkProspect (props) {
      if (!props.exist) {
        hashHistory.push('/Dashboard')
      }
    }

    render () {
      return <PureComponent {...this.props} />
    }
  }

  const connected = connect(mapStateToProps)(Reloaded)
  connected.displayName = `Reloaded(${PureComponent.name})`

  return connected
}
