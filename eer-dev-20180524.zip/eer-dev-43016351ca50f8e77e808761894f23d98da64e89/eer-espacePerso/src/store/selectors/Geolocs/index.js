import { createSelector } from 'reselect'

const cities = (state) => state.geoloc.cities.result

const makeSelectCitiesList = () => createSelector(
  cities,
  (items) => items.map((item) => ({ value: item.idVille, label: item.libelle })),
)

export {
  makeSelectCitiesList,
}
