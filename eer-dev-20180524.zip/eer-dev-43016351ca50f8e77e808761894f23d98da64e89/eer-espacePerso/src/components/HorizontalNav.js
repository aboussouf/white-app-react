import React, { Component } from 'react'
import PropTypes from 'prop-types'
import '../asserts/css/style_profil.scss'
import '../asserts/css/font-awesome.scss'

class HorizontalNav extends Component {
  constructor (props) {
    super(props)
    this.state = {
      visible: false
    }
    this.handleClick = this.handleClick.bind(this)
  }
  handleClick () {
    this.setState({
      visible: !this.state.visible
    })
  }

  render () {
    return (
      <header className='page-header row justify-center'>
        <div className='col-md-6 col-lg-8'>
          <h1 className='float-left text-center text-md-left'>{this.props.pageName}</h1>
        </div>
        <div className='dropdown user-dropdown col-md-6 col-lg-4 text-center text-md-right' onClick={this.handleClick}>
          <div className='btn btn-stripped dropdown-toggle' href='#/' >
            <img src={this.props.picture} alt='' className='circle float-left profile-photo' width='50' height='auto' />
            <div className='username mt-1'>
              <h4 className='mb-1'>{this.props.name}</h4>
            </div>
          </div>
          <div className={`dropdown-menu dropdown-menu-right${this.state.visible ? ' show' : ''}`} >
            <a className='dropdown-item' href='#/Profil'>
              <em className='fa fa-user-circle mr-1' /> Voir Profile
            </a>
            <a className='dropdown-item' href='#/' onClick={this.props.deconnect} >
              <em className='fa fa-power-off mr-1' /> Déconnexion
            </a>
          </div>
        </div>
      </header>
    )
  }
}

HorizontalNav.propTypes = {
  deconnect: PropTypes.func,
  pageName: PropTypes.string,
  picture: PropTypes.string,
  name: PropTypes.string,
}
export default HorizontalNav
