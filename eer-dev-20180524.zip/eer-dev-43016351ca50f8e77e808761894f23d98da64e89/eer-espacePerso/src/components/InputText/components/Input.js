import React, { Component } from 'react'
import PropTypes from 'prop-types'

class Input extends Component {
  constructor (props) {
    super(props)
    this.onChange = this.onChange.bind(this)
    this.state = {
      isValid: true,
    }
  }

  onChange (event) {
    const regex = new RegExp(this.props.pattern)
    const valid = regex.test(event.target.value)
    this.setState({ isValid: valid })
    if (valid) {
      this.props.inputChange(event.target.value, this.props.storeKey)
    }
  }

  render () {
    return ([
      <label className='col-md-2 col-form-label'>{this.props.label}</label>,
      <div className='col-md-4'>
        <input
          type={this.props.type}
          value={this.props.value}
          onChange={this.onChange}
          disabled={this.props.disabled}
          className={this.props.className}
          placeholder={this.props.placeholder}
        />
        { this.state.isValid ? null
          : <small className='text-danger'>
            {this.props.error}
          </small>
        }
      </div>
    ])
  }
}

Input.propTypes = {
  storeKey: PropTypes.string.isRequired,
  type: PropTypes.string,
  pattern: PropTypes.object,
  label: PropTypes.string,
  value: PropTypes.string,
  placeholder: PropTypes.string,
  error: PropTypes.string,
  disabled: PropTypes.bool,
  className: PropTypes.string,
  inputChange: PropTypes.func,
}

Input.defaultProps = {
  disabled: false,
  className: 'form-control',
  pattern: '^[a-zA-Z0-9_]*$',
}

export default Input
