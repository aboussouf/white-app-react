import React from 'react'
import PropTypes from 'prop-types'
import Card from '../../../components/Card'
import * as user from '../../../asserts/images/user.png'
import * as agence from '../../../asserts/images/agence.png'
import * as catalogue from '../../../asserts/images/catalogue.png'
import * as coffre from '../../../asserts/images/coffre.png'

class Dashboard extends React.Component {
  componentWillMount () {
    this.props.getProspect()
  }

  render () {
    return (
      <section className='row'>
        <div className='col-sm-12'>
          <section className='row'>
            <Card
              cardPicture={user}
              cardInput1={this.props.prospect && this.props.prospect.get('firstName') +
                          ' ' + this.props.prospect.get('lastName')}
              cardTitle={`Votre profil est complet à ${this.props.progress}%`}
              buttonLabel='Compléter mon profil'
              progress={`${this.props.progress}%`}
              linkTo='/Profil'
            />
            <Card
              cardPicture={agence}
              cardInput1={this.props.prospect && 'Agence ' + this.props.prospect.getIn(['agenceDTO', 'libelleAgence'])}
              cardTitle=' Mon Agence'
              buttonLabel='Consulter mon Rendez-Vous'
              linkTo='/Agence'
            />
            <Card
              cardPicture={catalogue}
              cardInput1='Des offres qui vous ressemblent'
              cardTitle='Ma Banque'
            />
            <Card
              cardPicture={coffre}
              cardTitle='Mon Coffre-Fort'
              cardInput1='Vos documents importants'
            />
          </section>
        </div>
      </section>
    )
  }
}

Dashboard.propTypes = {
  getProspect: PropTypes.func.isRequired,
  prospect: PropTypes.object,
  progress: PropTypes.number,
}

export default Dashboard
