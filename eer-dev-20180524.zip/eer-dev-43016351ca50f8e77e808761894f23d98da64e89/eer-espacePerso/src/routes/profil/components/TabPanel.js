import React from 'react'
import PropTypes from 'prop-types'

class customPanel extends React.Component {
  render () {
    return (
      <div id={this.props.tabIndex} className={`tab-pane fade${this.props.active ? ' active show' : ''}`} >
        {this.props.children}
      </div>
    )
  }
}

customPanel.propTypes = {
  active: PropTypes.bool,
  tabIndex: PropTypes.number,
  children: PropTypes.node,
}

export default customPanel
