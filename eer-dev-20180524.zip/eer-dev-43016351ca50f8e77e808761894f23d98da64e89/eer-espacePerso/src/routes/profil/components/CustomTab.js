import React from 'react'
import Panel from './TabPanel'
import PropTypes from 'prop-types'
import InfosPerso from './InfosPerso'
import Coordonnees from './Coordonnees'
import Situation from './Situation'
import Button from '../../../components/Button'

class customTab extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      selected: 1
    }
    this.handleClick = this.handleClick.bind(this)
  }
  handleClick (index) {
    this.setState({
      selected: index
    })
  }

  render () {
    const _index = this.state.selected
    return (

      <section className='container'>
        {
          this.props.status === 'success'
            ? <div className='alert alert-success'>
              <strong>Success!</strong> Modifications effectuées avec succès.
            </div>
            : null
        }
        <div className='row'>
          <div className='col-md-12'>
            <ul id='tabsJustified' className='nav nav-tabs'>
              {this.props.tabs.map((tab) =>
                <li className='nav-item'>
                  <a
                    href='#/Profil'
                    data-toggle='tab'
                    className={`nav-link small text-uppercase${_index === tab.index ? ' active show' : ''}`}
                    onClick={() => { this.handleClick(tab.index) }}
                  >
                    {tab.libelle}
                  </a>
                </li>
              )}
            </ul>
            <br />
            <div id='tabsJustifiedContent' className='tab-content'>
              <Panel active={_index === 1} tabIndex={1} >
                <InfosPerso villes={this.props.villes} />
              </Panel>
              <Panel active={_index === 2} tabIndex={2} >
                <Coordonnees villes={this.props.villes} />
              </Panel>
              <Panel active={_index === 3} tabIndex={3} >
                <Situation />
              </Panel>
              <Button
                className='btn btn-md btn-primary float-right'
                label='Enregistrer mon profil'
                action={this.props.saveProspect}
              />
            </div>
          </div>
        </div>
      </section>
    )
  }
}

customTab.propTypes = {
  tabs: PropTypes.array.isRequired,
  villes: PropTypes.array.isRequired,
  saveProspect: PropTypes.func,
  status: PropTypes.string,
}

export default customTab
