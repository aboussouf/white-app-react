import React from 'react'
import * as constants from '../../utils/constants'
import Tab from './containers/CustomTab'

class Profil extends React.Component {
  render () {
    return (
      <section className='row'>
        <div className='col-sm-12'>
          <Tab tabs={constants.PROFIL_TABS} />
        </div>
      </section>
    )
  }
}

export default Profil
