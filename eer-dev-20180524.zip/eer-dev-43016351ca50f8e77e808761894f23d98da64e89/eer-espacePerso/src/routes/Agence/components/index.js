import React from 'react'
import PropTypes from 'prop-types'
import moment from 'moment'
import Card from '../../../components/Card'
import * as agence from '../../../asserts/images/agence.png'

class Agence extends React.Component {
  render () {
    return (
      <section className='row'>
        <div className='col-sm-12'>
          <section className='row'>
            <Card
              cardPicture={agence}
              cardTitle={`Agence ${this.props.prospect.getIn(['agenceDTO', 'libelleAgence'])}`}
              cardInput1={`Votre rendez-vous est le :
                          ${moment(this.props.prospect.get('dateRdv')).format('MM/DD/YYYY')}`}
              cardInput2={`A : ${moment(this.props.prospect.get('dateRdv')).format('HH:mm')}`}
              buttonLabel='Modifier mon Rendez-vous'
              linkTo='/'
            />
          </section>
        </div>
      </section>
    )
  }
}

Agence.propTypes = {
  prospect: PropTypes.object,
}

export default Agence
