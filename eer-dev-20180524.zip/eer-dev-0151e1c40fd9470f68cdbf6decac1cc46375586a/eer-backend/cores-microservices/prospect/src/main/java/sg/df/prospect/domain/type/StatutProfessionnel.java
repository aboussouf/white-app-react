package sg.df.prospect.domain.type;

public enum StatutProfessionnel {
    SALARIE("SALARIE"), RETRAITE("RETRAITE") , SANS_ACTIVITE("SANS ACTIVITE") , INDEPENDANT("INDEPENDANT");
    private String libelleStatutProf ;

    StatutProfessionnel(String libelleStatutProf) {
        this.libelleStatutProf = libelleStatutProf;
    }
}
