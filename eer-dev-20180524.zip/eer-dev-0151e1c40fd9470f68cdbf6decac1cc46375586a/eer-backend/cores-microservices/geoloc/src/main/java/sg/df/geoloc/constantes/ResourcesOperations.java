package sg.df.geoloc.constantes;

public class ResourcesOperations {
    public static final String AGENCE="agence";
    public static final String AGENCES="agences";
    public static final String QUARTIER="quartier";

}
