import React from 'react'
import PropTypes from 'prop-types'
import '../../assets/css/custom.scss'
import Eer from '../../routes/Eer'

class PageLayout extends React.Component {
  render () {
    return (
      <div className='container-scroller'>
        <div className='container-fluid page-body-wrapper'>
          <div id='wrapper' className='container-fluid' >
            <h2>{this.props.children}</h2>

            <Eer />

          </div>
        </div>
      </div>
    )
  }
}

PageLayout.propTypes = {
  children: PropTypes.node,
  firstName: PropTypes.string,
  lastName: PropTypes.string,
  typeProspect: PropTypes.string,
}

export default PageLayout
