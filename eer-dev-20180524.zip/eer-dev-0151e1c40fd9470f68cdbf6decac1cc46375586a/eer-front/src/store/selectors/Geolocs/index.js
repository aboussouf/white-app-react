import { createSelector } from 'reselect'

// const geolocsState = (state) => state.get('geolocs')
const geolocsState = (state) => state.geolocs

// const makeSelectAgencesList = () => createSelector(
//   geolocsState,
//   (agenceState) => agenceState.agences.toJS()
// )

const makeSelectCitiesList = () => createSelector(
  geolocsState,
  // (refState) => refState.cities.toJS()
  (refState) => refState.toJS()

)

export {
  makeSelectCitiesList,
  // makeSelectAgencesList
}
