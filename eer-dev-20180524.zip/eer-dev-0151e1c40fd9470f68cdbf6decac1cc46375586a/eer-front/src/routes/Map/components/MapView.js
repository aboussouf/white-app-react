import React from 'react'
import PropTypes from 'prop-types'
import InputSelect from '../../../components/Select'
import MapContainer from '../../../components/Geoloc/MapContainer'

class MapView extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      selectedAgence: undefined,
      citiesDefaultValue: 1,
    }
    this.props.getAgencys(1)
  }

  componentWillMount () {
    this.props.getAgencys(this.props.selectedVille)
  }

  componentDidUpdate (prevProps, prevState) {
    if (prevProps.selectedVille !== this.props.selectedVille) {
      this.props.getAgencys(this.props.selectedVille)
    }
  }
  handleCitiesChange = (event, index, citiesDefaultValue) => {
    console.log('onchange :        ', this.props.selectedVille)
    this.props.getAgencys(this.props.selectedVille)
    this.setState({ citiesDefaultValue : this.props.selectedVille })
  }

  render () {
    console.log('agences : ', this.props.agences)
    console.log('selectedAgence : ', this.state.selectedVille)
    const _cities = this.props.cities.map(
      city => ({ value: city.idVille, label: city.libelle, latitude: city.latitude, longitude:city.longitude }))
    /* const _agences = this.props.agences.map(
      agence => ({ latitude: agence.latitude, longitude:agence.longitude, name:agence.libelleAgence })) */
    return (
      <div>
        <div className='row mt-3 mb-2'>
          <div className='col-xs-9 col-md-7'>

            <InputSelect id='select' storeKey='geolocs.ville'
              options={_cities}
              value={this.state.citiesDefaultValue}
              label='Ville :'
              // className='col-md-9 col-sm-12 custom-select form-control'
            /></div>
          <div className='col-xs-3 col-md-5'>
            {this.props.agenceSelectionnee && this.props.agenceSelectionnee.get('libelleAgence') !== ''
              ? <div>
                <label className='col-form-label'>Votre Agence sera </label>
                <h4>{this.props.agenceSelectionnee.get('libelleAgence')}</h4>
                <h6>{this.props.agenceSelectionnee.get('adresseAgence')}</h6>
              </div>
              : null
            }
          </div>
        </div>
        <MapContainer
          ref='map'
          agences={this.props.agences}
          city={_cities[this.props.selectedVille - 1]}
        />

      </div>
    )
  }
}

MapView.propTypes = {
  cities: PropTypes.object.isRequired,
  agences: PropTypes.object.isRequired,
  getAgencys: PropTypes.func,
  selectedVille: PropTypes.string,
  agenceSelectionnee: PropTypes.object,
}
MapView.defaultProps = {
  selectedVille : '1',
}

export default MapView
