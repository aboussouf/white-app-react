import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router'
import ProgressBar from './ProgressBar'
import '../asserts/css/style_profil.scss'

class Card extends Component {
  render () {
    return (
      <div className='col-lg-6 mb-4 bg-default'>
        <div className='card'>
          <div className='card-header'>
            <div className='user-progress justify-center'>
              <div className='col-sm-3 col-md-2 col-xl-1'>
                <img
                  src={this.props.cardPicture} alt=''
                  className='circle profile-photo'
                />
              </div>
              <div className='col-sm-9 col-md-10 col-xl-11'>
                <h6 className='pt-1'>{this.props.cardTitle}</h6>
                {
                  this.props.progress ? <ProgressBar progress={this.props.progress} /> : null
                }
              </div>
            </div></div>
          <div className='card-block'>
            <p>{this.props.cardInput1}</p>
            <p>{this.props.cardInput2}</p>
            <Link to={this.props.linkTo} className='btn btn-md btn-primary float-right'>{this.props.buttonLabel}</Link>
          </div>
        </div>
      </div>
    )
  }
}

Card.propTypes = {
  cardPicture: PropTypes.string,
  cardTitle: PropTypes.string,
  cardInput1: PropTypes.string,
  cardInput2: PropTypes.string,
  buttonLabel: PropTypes.string,
  progress: PropTypes.string,
  linkTo: PropTypes.string,
}

export default Card
