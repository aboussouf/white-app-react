import React, { Component } from 'react'
import PropTypes from 'prop-types'
import '../asserts/css/style_profil.scss'

class MenuItem extends Component {
  render () {
    return (
      <li className='nav-item' key={this.props.id} >

        <a className={this.props.className} href={this.props.href} target='' onClick={this.props.action} >
          <em className={this.props.icon} />
          {this.props.label}
        </a>
      </li>
    )
  }
}

MenuItem.propTypes = {
  id: PropTypes.string,
  href: PropTypes.string,
  label: PropTypes.string,
  icon: PropTypes.string,
  className: PropTypes.string,
  action: PropTypes.func,
}

MenuItem.defaultProps = {
  className : 'nav-link'
}

export default MenuItem
