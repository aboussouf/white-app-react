import { fromJS } from 'immutable'

const prospectInitState = fromJS({})

function profilProgress (Prospect) {
  let count = 0
  for (var key in Prospect) {
    if (Prospect[key] !== null && Prospect[key] !== '') {
      count = count + 1
    }
  }
  // 18 : total profil fields , 12: non profil fields
  return parseInt(((count - 12) * 100) / 18, 10)
}

function prospectReducer (state = prospectInitState, action) {
  switch (action.type) {
    case 'GET_PROSPECT':
      return state.withMutations((ctx) => {
        ctx.setIn(['prospect', 'result'], fromJS({}))
        ctx.setIn(['prospect', 'status'], 'loading')
      })
    case 'GET_PROSPECT_SUCCESS':
      return state.withMutations((ctx) => {
        ctx.setIn(['prospect', 'result'], fromJS(action.result))
        ctx.setIn(['lastName', 'value'], fromJS(action.result.lastName))
        ctx.setIn(['firstName', 'value'], fromJS(action.result.firstName))
        ctx.setIn(['tel', 'value'], fromJS(action.result.numeroMobile))
        ctx.setIn(['email', 'value'], fromJS(action.result.email))
        ctx.setIn(['birthDate', 'value'], fromJS(action.result.birthDate))
        ctx.setIn(['birthCity', 'value'], fromJS(action.result.idBirthCity))
        ctx.setIn(['typePiece', 'value'], fromJS(action.result.piece))
        ctx.setIn(['numPiece', 'value'], fromJS(action.result.numeroPiece))
        ctx.setIn(['address1', 'value'], fromJS(action.result.address))
        ctx.setIn(['address2', 'value'], fromJS(action.result.addressComplement))
        ctx.setIn(['city', 'value'], fromJS(action.result.idCity))
        ctx.setIn(['zipCode', 'value'], fromJS(action.result.zipCode))
        ctx.setIn(['situation', 'value'], fromJS(action.result.situationFamiliale))
        ctx.setIn(['childrens', 'value'], fromJS(action.result.nbrEnfACharge))
        ctx.setIn(['function', 'value'], fromJS(action.result.statutProfessionnel))
        ctx.setIn(['activity', 'value'], fromJS(action.result.secteurActivite))
        ctx.setIn(['revenu', 'value'], fromJS(action.result.trancheRevenu))
        ctx.setIn(['prospect', 'status'], 'success')
        ctx.setIn(['save', 'status'], 'loading')
        ctx.setIn(['prospect', 'progress'], fromJS(profilProgress(action.result)))
      })
    case 'GET_PROSPECT_ERROR':
      return state.withMutations((ctx) => {
        ctx.setIn(['prospect', 'result'], fromJS(action.result))
        ctx.setIn(['prospect', 'status'], 'error')
      })
    case 'ON_CHANGE':
      return state.setIn(action.key.concat(['value']), fromJS(action.newValue))
    case 'SAVE_PROSPECT_SUCCESS':
      return state.withMutations((ctx) => {
        ctx.setIn(['save', 'result'], fromJS(action.result))
        ctx.setIn(['save', 'status'], 'success')
      })
    case 'SAVE_PROSPECT':
      return state.withMutations((ctx) => {
        ctx.setIn(['save', 'result'], fromJS({}))
        ctx.setIn(['save', 'status'], 'loading')
      })
    case 'SAVE_PROSPECT_ERROR':
      return state.withMutations((ctx) => {
        ctx.setIn(['save', 'result'], fromJS(action.result))
        ctx.setIn(['save', 'status'], 'error')
      })
    case 'UPDATE_PROSPECT_SUCCESS':
      return state.withMutations((ctx) => {
        ctx.setIn(['update', 'status'], 'success')
        ctx.setIn(['prospect', 'result', 'validateOB'], true)
      })
    case 'UPDATE_PROSPECT_ERROR':
      return state.withMutations((ctx) => {
        ctx.setIn(['update', 'result'], fromJS(action.result))
        ctx.setIn(['update', 'status'], 'error')
      })
    case 'GET_STATUT_PROFESSIONNEL_SUCCESS':
      return state.withMutations((ctx) => {
        ctx.setIn(['update', 'status'], 'success')
        ctx.setIn(['prospect', 'result', 'validateOB'], true)
      })
    case 'GET_STATUT_PROFESSIONNEL_ERROR':
      return state.withMutations((ctx) => {
        ctx.setIn(['params', 'function', 'result'], fromJS(action.result))
        ctx.setIn(['params', 'function', 'status'], 'error')
      })
    case 'GET_FAMILY_SITUATION_SUCCESS':
      return state.withMutations((ctx) => {
        ctx.setIn(['params', 'familySituation', 'result'], fromJS(action.result))
        ctx.setIn(['params', 'familySituation', 'status'], 'error')
      })
    case 'GET_FAMILY_SITUATION_ERROR':
      return state.withMutations((ctx) => {
        ctx.setIn(['params', 'familySituation', 'result'], fromJS(action.result))
        ctx.setIn(['params', 'familySituation', 'status'], 'error')
      })
    case 'GET_TRANCHE_REVENU_SUCCESS':
      return state.withMutations((ctx) => {
        ctx.setIn(['params', 'revenu', 'result'], fromJS(action.result))
        ctx.setIn(['params', 'revenu', 'status'], 'error')
      })
    case 'GET_TRANCHE_REVENU_ERROR':
      return state.withMutations((ctx) => {
        ctx.setIn(['params', 'revenu', 'result'], fromJS(action.result))
        ctx.setIn(['params', 'revenu', 'status'], 'error')
      })
    default:
      return state
  }
}

export default prospectReducer
