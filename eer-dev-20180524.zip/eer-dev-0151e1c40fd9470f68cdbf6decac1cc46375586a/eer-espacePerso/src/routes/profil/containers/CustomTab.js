import CustomTab from '../components/CustomTab'
import { connect } from 'react-redux'
import { saveProspect } from '../../../store/actions/Prospect'

function mapStateToProps (state, props) {
  const _villes = state.geoloc.getIn(['cities', 'result'])
  return {
    prospect: {
      idProspect: state.prospect.getIn(['prospect', 'result', 'idProspect']),
      identifiantProspect: state.prospect.getIn(['prospect', 'result', 'identifiantProspect']),
      address: state.prospect.getIn(['address1', 'value']),
      addressComplement: state.prospect.getIn(['address2', 'value']),
      civilite: state.prospect.getIn(['civilty', 'value']),
      email: state.prospect.getIn(['email', 'value']),
      firstName: state.prospect.getIn(['firstName', 'value']),
      idBirthCity: state.prospect.getIn(['birthCity', 'value']),
      idCity: state.prospect.getIn(['city', 'value']),
      lastName: state.prospect.getIn(['lastName', 'value']),
      nbrEnfACharge: state.prospect.getIn(['childrens', 'value']),
      numeroMobile: state.prospect.getIn(['tel', 'value']),
      piece: state.prospect.getIn(['typePiece', 'value']),
      numeroPiece: state.prospect.getIn(['numPiece', 'value']),
      secteurActivite: state.prospect.getIn(['activity', 'value']),
      situationFamiliale: state.prospect.getIn(['situation', 'value']),
      statutProfessionnel: state.prospect.getIn(['function', 'value']),
      trancheRevenu: state.prospect.getIn(['revenu', 'value']),
      zipCode:state.prospect.getIn(['zipCode', 'value']),
      dateRdv:state.prospect.getIn(['prospect', 'result', 'dateRdv']),
      codeAgence:state.prospect.getIn(['prospect', 'result', 'agenceDTO', 'codeAgence']),
      acceptCgu:state.prospect.getIn(['prospect', 'result', 'acceptCgu']),
      validateOB:state.prospect.getIn(['prospect', 'result', 'validateOB']),
      boisson:state.prospect.getIn(['prospect', 'result', 'boisson']),
    },
    villes: _villes && _villes.map((item) => ({ value: item.idVille, label: item.libelle })),
    status: state.prospect.getIn(['save', 'status']),
  }
}

const mapDispatchToProps = (dispatch) => ({
  saveProspect: (id) => { dispatch(saveProspect(id)) },
})
function mergeProps (stateProps, dispatchProps, ownProps) {
  return Object.assign({}, ownProps, stateProps, dispatchProps, {
    saveProspect: () => dispatchProps.saveProspect(stateProps.prospect)
  })
}

export default connect(mapStateToProps, mapDispatchToProps, mergeProps)(CustomTab)
