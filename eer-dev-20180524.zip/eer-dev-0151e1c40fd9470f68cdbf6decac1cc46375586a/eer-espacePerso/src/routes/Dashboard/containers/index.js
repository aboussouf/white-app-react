import View from '../components'
import { connect } from 'react-redux'
import { getProspect } from '../../../store/actions/Prospect'

const mapStateToProps = (state, props) => ({
  prospect: state.prospect.getIn(['prospect', 'result']),
  progress: state.prospect.getIn(['prospect', 'progress']),
  identifaintUser: state.keycloak.tokenParsed.preferred_username,
})

const mapDispatchToProps = (dispatch) => ({
  getProspect: (id) => { dispatch(getProspect(id)) },
})
function mergeProps (stateProps, dispatchProps, ownProps) {
  return Object.assign({}, ownProps, stateProps, dispatchProps, {
    getProspect: () => dispatchProps.getProspect(stateProps.identifaintUser)
  })
}

export default connect(mapStateToProps, mapDispatchToProps, mergeProps)(View)
