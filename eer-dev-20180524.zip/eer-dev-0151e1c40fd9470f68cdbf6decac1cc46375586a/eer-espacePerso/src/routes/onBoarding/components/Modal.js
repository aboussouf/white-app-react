import React from 'react'
import PropTypes from 'prop-types'
import ModalAwesome from 'react-awesome-modal'
import Onboarding from './Onboarding'

class Modal extends React.Component {
  constructor (props) {
    super(props)
    this.validateOB = this.validateOB.bind(this)
  }

  validateOB () {
    this.props.updateValidatorOBProspect()
  }

  render () {
    return (
      <div>
        <ModalAwesome visible={!this.props.visible} width='280' height='464' effect='fadeInUp'>
          <div>
            <Onboarding action={() => this.validateOB()} />
          </div>
        </ModalAwesome>
      </div>
    )
  }
}

Modal.propTypes = {
  updateValidatorOBProspect: PropTypes.func.isRequired,
  visible: PropTypes.bool,
}
Modal.defaultProps = {
  visible: true,
}

export default Modal
