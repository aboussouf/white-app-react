/*
 * Copyright (C) 2016 to the original authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package org.springframework.cloud.kubernetes.ribbon;

import java.util.ArrayList;
import java.util.List;

import io.fabric8.kubernetes.api.model.EndpointsBuilder;
import io.fabric8.kubernetes.client.Config;
import io.fabric8.kubernetes.client.KubernetesClient;
import io.fabric8.kubernetes.server.mock.KubernetesServer;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

/**
 * @author <a href="mailto:cmoullia@redhat.com">Charles Moulliard</a>
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class,
                properties = {
	"spring.application.name=testapp",
	"spring.cloud.kubernetes.client.namespace=testns",
	"spring.cloud.kubernetes.client.trustCerts=true",
	"spring.cloud.kubernetes.config.namespace=testns"})
@EnableAutoConfiguration
@EnableDiscoveryClient
public class RibbonTest {

	@ClassRule
	public static KubernetesServer server = new KubernetesServer();

	@ClassRule
	public static KubernetesServer mockEndpointA = new KubernetesServer(false);

	@ClassRule
	public static KubernetesServer mockEndpointB = new KubernetesServer(false);

	public static KubernetesClient mockClient;

	@Autowired
	RestTemplate restTemplate;

	@BeforeClass
	public static void setUpBefore() throws Exception {
		mockClient = server.getClient();

		//Configure the kubernetes master url to point to the mock server
		System.setProperty(Config.KUBERNETES_MASTER_SYSTEM_PROPERTY, mockClient.getConfiguration().getMasterUrl());
		System.setProperty(Config.KUBERNETES_TRUST_CERT_SYSTEM_PROPERTY, "true");
		System.setProperty(Config.KUBERNETES_AUTH_TRYKUBECONFIG_SYSTEM_PROPERTY, "false");
		System.setProperty(Config.KUBERNETES_AUTH_TRYSERVICEACCOUNT_SYSTEM_PROPERTY, "false");

		//Configured
		server.expect().get().withPath("/api/v1/namespaces/testns/endpoints/testapp").andReturn(200, new EndpointsBuilder()
			.withNewMetadata()
			.withName("testapp-a")
			.endMetadata()
			.addNewSubset()
			.addNewAddress().withIp(mockEndpointA.getMockServer().getHostName()).endAddress()
			.addNewPort("http", mockEndpointA.getMockServer().getPort(), "http")
			.endSubset()
			.addNewSubset()
			.addNewAddress().withIp(mockEndpointB.getMockServer().getHostName()).endAddress()
			.addNewPort("http", mockEndpointB.getMockServer().getPort(), "http")
			.endSubset()
			.build()).always();

		mockEndpointA.expect().get().withPath("/greeting").andReturn(200, "Hello from A").always();
		mockEndpointB.expect().get().withPath("/greeting").andReturn(200, "Hello from B").always();
	}

	@Test
	public void testGreetingEndpoint() {
		List<String> greetings = new ArrayList<>();
		for (int i = 0; i < 2 ; i++) {
			greetings.add(restTemplate.getForObject("http://testapp/greeting", String.class));
		}
		greetings.contains("Hello from A");
		greetings.contains("Hello from B");
	}

}
