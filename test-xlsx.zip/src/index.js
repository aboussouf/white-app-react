import React from "react";
import ReactDOM from "react-dom";
import * as XLSX from "xlsx";

import "./styles.css";

function TRContent(props) {
  if (this.props.key === 0) {
    return <tr className="expHeader" />;
  }
  return <tr className="expRow" />;
}

class MainContent extends React.Component {
  render() {
    return (
      <div id="mainContent">
        <table>
          {this.props.data.split("\n").map(function(row, key) {
            return (
              <tr key={key} className="expRow">
                {row.split(",").map(function(cell, key2) {
                  if (cell.match("^(m*)exp(\\d+)")) {
                    return (
                      <td key={key2} class="expCell">
                        <a href={cell + ".pdf"}>{cell}</a>
                      </td>
                    );
                  } else {
                    return (
                      <td key={key2} className="expCell">
                        {cell}
                      </td>
                    );
                  }
                })}
              </tr>
            );
          })}
        </table>
      </div>
    );
  }
}

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: ""
    };
  }
  handleFiles(event) {
    if (window.FileReader) {
      let reader = new FileReader();
      reader.onload = e => {
        this.setState({ data: e.target.result });
      };
      reader.readAsText(event.target.files[0]);
    } else {
      alert("FileReader are not supported in this browser.");
    }
  }
  handleExcel(event) {
    let name = event.target.files[0].name;
    let reader = new FileReader();
    reader.onload = e => {
      let bstr = e.target.result;
      let wb = XLSX.read(bstr, { type: "binary" });
      let wsname = wb.SheetNames[0];
      let ws = wb.Sheets[wsname];
      let wsdata = XLSX.utils.sheet_to_csv(ws, { header: 1 });
      this.setState({ data: wsdata });
    };
    reader.readAsBinaryString(event.target.files[0]);
  }
  render() {
    return (
      <div>
        <div id="parent">
          <div id="csv">
            Choose a comma-separated file containing a list of experiments:{" "}
            <br />
            <input type="file" onChange={this.handleFiles.bind(this)} />
          </div>

          <div id="excel">
            Choose an Excel sheet containing a list of experiments: <br />
            <input type="file" onChange={this.handleExcel.bind(this)} />
          </div>
        </div>
        <MainContent data={this.state.data} />
      </div>
    );
  }
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
