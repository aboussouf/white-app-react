--INSTALL DEPENDENCIES
npm install

-- RUN TESTS
npm run test