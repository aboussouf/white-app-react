const initialState = {
  visibilityFilter: "SHOW_ALL",
  todos: []
};
export default function todoApp(state = initialState, action) {
  switch (action.type) {
    case "ADD_TODO":
      return Object.assign({}, state, {
        todos: [
          ...state.todos,
          {
            text: action.text,
            completed: false,
            id: state.todos.length
          }
        ]
      });
    case "TOGGLE_TODO":
      return {
        visibilityFilter: state.visibilityFilter,
        todos: state.todos.map(
          todo =>
            todo.id === action.id
              ? { ...todo, completed: !todo.completed }
              : todo
        )
      };
    case "SET_VISIBILITY_FILTER":
      return Object.assign({}, state, {
        visibilityFilter: action.filter
      });
    default:
      return state;
  }
}
