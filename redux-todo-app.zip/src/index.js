import React from "react";
import { render } from "react-dom";
import { createStore } from "redux";
import todoApp from "./reducer"; // That we have created in the earlier section
import {Provider} from "react-redux";
import App from "./component/App";
/** 
 * Creating the store by sending the Reducer
 */
var store = createStore(todoApp);

render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById("root")
);
