import React from 'react';
import AddTodo from '../containers/AddToDo';
import TodoList from '../containers/TodoList';
import Filter from '../containers/Filter';

const App = () => (
  <div>
    <AddTodo />
    <TodoList />
    <Filter />
  </div>
)

export default App;