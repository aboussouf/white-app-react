import React from "react";
import { connect } from "react-redux";
import { setVisibilityFilter } from "../actions";

const style = {
  color: "red"
};
const filters = [
  {
    filter: "SHOW_ALL",
    text: "All"
  },
  {
    filter: "SHOW_ACTIVE",
    text: "Active"
  },
  {
    filter: "SHOW_COMPLETED",
    text: "Completed"
  }
];
const Filter = ({ visibilityFilter, updateFilter }) => (
  <p>
    {"Show:"}
    {filters.map((_filter, index) => {
      let divstyle = {};
      if (visibilityFilter == _filter.filter) {
        divstyle = style;
      }
      return (
        <div onClick={() => updateFilter(_filter.filter)} style={divstyle} key={index}>
          {_filter.text}
        </div>
      );
    })}
  </p>
);
const mapDispatchToProps = dispatch => {
  return {
    updateFilter: filter => {
      dispatch(setVisibilityFilter(filter));
    }
  };
};
const mapStateToProps = state => {
  return {
    visibilityFilter: state.visibilityFilter
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Filter);
