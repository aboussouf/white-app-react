import { fromJS } from 'immutable'
import Calend from '../components/Calend'
import { connect } from 'react-redux'
// import { updateValidatorOBProspect } from '../../../store/actions/Prospect'
import { inputChange } from '../../../store/actions/Inputs'
import { getRdvPrisParAgence } from '../../../store/actions/Prospect'

const mapStateToProps = (state, props) => {
  const [store, ...storeKey] = props.storeKey.split('.')
  storeKey.push('value')
  return ({
    value: state[store].getIn(storeKey),
    occuppiedtime: state.prospect.getIn(['occuppiedtime', 'result']) || fromJS([]),
    agenceSelectionnee: state.prospect.get('agence'),
  })
}

const mapDispatchToProps = (dispatch) => ({
  selectDate: (value, id) => { dispatch(inputChange(value, id)) },
  getRdvPrisParAgence :(value) => { dispatch(getRdvPrisParAgence(value)) }
})

export default connect(mapStateToProps, mapDispatchToProps)(Calend)
