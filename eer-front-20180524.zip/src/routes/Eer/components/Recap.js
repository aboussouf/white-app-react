import React from 'react'
import PropTypes from 'prop-types'
import '../../../../node_modules/bootstrap/scss/mixins/_grid-framework.scss'
import '../../../assets/css/font-awesome.scss'
import '../../../assets/css/custom.scss'
import '../../../assets/css/bootstrap-float-label.min.scss'
import '../css/buttons.scss'
import '../css/input.scss'

class Recap extends React.Component {
  constructor () {
    super()
    this.state = {
      checked : false,
      boisson : 'T',
    }
    // this.onChange = this.onChange.bind(this)
  }
  formatDate= (date) => {
    if (date !== 'Veuillez choisir une date') {
      var d = new Date(date),
        monthNames = [
          'Janvier', 'Février', 'Mars',
          'Avril', 'Mai', 'Juin', 'Juillet',
          'Aout', 'Septembre', 'Octobre',
          'Novembre', 'Décembre'
        ],
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear()
      console.log('year', day + ' ' + monthNames[month])

      return day + ' ' + monthNames[month - 1]
    } else {
      return 'Veuillez choisir une date'
    }
  }
  theCafe(index) {
      console.log('functionBoisson ------------------------------------', index)
    if (index === 1) {
      // this.setState({ boisson: 'T' })

      this.props.inputChange('T', 'prospect.boisson')
    } else if (index === 2) {
      this.props.inputChange('C', 'prospect.boisson')
    }
  }
  onChange = () => {
    this.setState({ checked: !this.state.checked })
    console.log('onChange ---------------------------------------------------------', !this.state.checked)
    this.props.inputChange(!this.state.checked, 'prospect.acceptCgu')
  }

  render () {
    console.log('Rencontre :', this.props)
    return (
      <div className='tab-pane' role='tabpanel' id='step4'>
        <h1 className='text-md-center'>Récapitulatif</h1>
        <div className='row'>
          <div className='col-lg-6 mb-4'>
            <div className='card mb-4'>
              <div className='card-block'>
                <div className='articles-container'>

                  <div className='article border-bottom'>
                    <div className='col-xs-12'>
                      <div className='row'>
                        <div className='col-2 date'>
                          <div className='large fa fa-building-o' />
                        </div>
                        {this.props.agenceSelectionnee && this.props.agenceSelectionnee.libelleAgence !== ''
                          ? <div className='col-10'>
                            <h4><a>AGENCE</a></h4>
                            <p>{this.props.agenceSelectionnee.get('libelleAgence')}</p>
                            <p>Horaire : 9h 13h</p>
                          </div>
                          : null }
                      </div>
                    </div>
                    <div className='clear' />
                  </div>

                  <div className='article border-bottom'>
                    <div className='col-xs-12'>
                      <div className='row'>
                        <div className='col-2 date'>
                          <div className='large fa fa-calendar-check-o' />
                        </div>
                        <div className='col-10'>
                          <h4><a>Date</a></h4>
                          <p>{this.formatDate(this.props.dateRdv)}</p>
                        </div>
                      </div>
                    </div>
                    <div className='clear' />
                  </div>

                  <div className='article'>
                    <div className='col-xs-12'>
                      <div className='row'>
                        <div className='col-2 date'>
                          <div className='large fa fa-clock-o' />
                        </div>
                        <div className='col-10'>
                          <h4><a>Heure</a></h4>
                          <p>{this.props.heureRdv}</p>
                        </div>
                      </div>
                    </div>
                    <div className='clear' />
                  </div>

                </div>
              </div>
            </div>
          </div>
          <div className='col-lg-6 mb-4'>
            <div className='card'>
              <div className='card-header bg-primary'>
                <h5 className='text-md-center white-text'>Informations de base</h5>
              </div>
              <div className='card-block'>
                <div className='form-group row'>
                  <div className='form-group input-group row'>
                    <span className='col-md-12 has-float-label'>
                      <input className='form-control' id='first' disabled
                        type='text' placeholder=' ' value={this.props.lastName} />
                      <label htmlFor='first'>&#160; Nom</label>
                    </span>
                  </div>
                  <div className='form-group input-group row'>
                    <span className='col-md-12 has-float-label'>
                      <input className='form-control' id='first' disabled
                        type='text' placeholder=' ' value={this.props.firstName} />
                      <label htmlFor='first'>&#160; Prénom</label>
                    </span>
                  </div>
                  <div className='form-group input-group row'>
                    <label className='col-md-12 has-float-label'>
                      <input className='form-control' type='text' disabled
                        placeholder=' ' value={this.props.tel} />
                      <span>&#160; Tél</span>
                    </label>
                  </div>
                  <div className='form-group input-group row'>
                    <label className='col-md-12 has-float-label'>
                      <input className='form-control' type='text' disabled
                        placeholder=' ' value={this.props.email} />
                      <span>&#160; Email</span>
                    </label>
                  </div>
                </div>
                <ul className='list-inline text-md-center'>
                  <li><button
                    className='btn btn-lg btn-primary next-step next-button'
                    onClick={this.props.action}>
                  Modifier</button></li>
                </ul>
              </div>
            </div>
          </div>
          <div className='col-xs-12 col-sm-12 col-lg-12 col-xl-12'>
            <h5 className='text-md-center black-text'>Votre boisson</h5>
            <div className="radio-tile-group" >
              <div className="input-container">
                <input id="the" className="radio-button" type="radio" name="radio" onClick={() => this.theCafe(1)}/>
                <div className="radio-tile">
                  <div className="icon tea-icon">
                    <i className='fa fa-leaf' />
                  </div>
                  <label for="the" className="radio-tile-label">Thé</label>
                </div>
              </div>

              <div className="input-container" >
                <input id="cafe" className="radio-button" type="radio" name="radio" onClick={() => this.theCafe(2)}/>
                <div className="radio-tile">
                  <div className="icon coffee-icon">
                  <i className="fa fa-coffee"></i>
                  </div>
                  <label for="cafe" className="radio-tile-label">Café</label>
                </div>
              </div>
            </div>

          </div>
          <div className='checkbox mt-1 mb-2'>
            <div className='custom-control custom-checkbox'>
              <input type='checkbox' className='custom-control-input' id='customCheck1' onChange={this.onChange} />
              <label className='custom-control-label custom-control-description'
                htmlFor='customCheck1'>J accepte les <a target='_blank'
                  href='https://www.sgmaroc.com/conditions-generales-dutilisation/'>
              conditions générales</a></label>
            </div>
          </div>
        </div>

      </div>
    )
  }
}

Recap.propTypes = {
  dateRdv : PropTypes.instanceOf(Date),
  heureRdv : PropTypes.string,
  firstName: PropTypes.string,
  lastName: PropTypes.string,
  tel: PropTypes.string,
  email: PropTypes.string,
  prospect: PropTypes.object,
  action: PropTypes.func,
  agenceSelectionnee: PropTypes.object,
  inputChange : PropTypes.func,
  storeKey: PropTypes.string.isRequired,
}

Recap.defaultProps = {
  dateRdv : 'Veuillez choisir une date',
  heureRdv : 'Veuillez choisir une heure',
}

export default Recap
