import React from 'react'
import PropTypes from 'prop-types'
import '../../../../node_modules/bootstrap/scss/mixins/_grid-framework.scss'
import '../../../assets/css/font-awesome.scss'
import '../../../assets/css/custom.scss'
import '../../../assets/css/bootstrap-float-label.min.scss'
import '../css/buttons.scss'

class Felicitations extends React.Component {
  render () {
    return (
      <div className='tab-pane' role='tabpanel' id='step5'>
        <h1 className='text-md-center'>Félicitations {this.props.firstName}</h1>
        <div className='row'>
          <p className='lead'>Bienvenue à la Société Générale Maroc,
                         Nous sommes ravis de vous recevoir pour notre premier rendez-vous en agence!
                         </p><br></br>
                         <p className='lead'> Nous vous avons envoyé un mail avec votre identifiant de connexion à votre espace SGMA.
                          Dans quelques instants, vous recevrez votre mot de passe par SMS.
                          N oubliez pas de vous munir des pièces justificatives qui vous serviront à ouvrir votre compte lors de notre rendez-vous </p>
        </div>
      </div>

    )
  }
}

Felicitations.propTypes = {
  firstName: PropTypes.string,
}

export default Felicitations
