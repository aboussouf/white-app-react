import Eer from './containers/EerView'

export default Eer
