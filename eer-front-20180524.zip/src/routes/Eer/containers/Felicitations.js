import Felicitations from '../components/Felicitations'
import { connect } from 'react-redux'

const mapStateToProps = (state, props) => {
  return ({
    firstName: state.prospect.getIn(['firstName', 'value']),
  })
}

export default connect(mapStateToProps)(Felicitations)
