import Recap from '../components/Recap'
import { connect } from 'react-redux'
import { inputChange } from '../../../store/actions/Inputs'

const mapStateToProps = (state, props) => {
  // console.log("here :",state.prospect._root.entries)
  //  console.log("here :",state.prospect.getIn('prospect'))
  return ({
    // prospect: state.prospect.get('prospect'),
    dateRdv : state.prospect.getIn(['dateRdv', 'value']),
    heureRdv: state.prospect.getIn(['heureRdv', 'value']),
    firstName: state.prospect.getIn(['firstName', 'value']),
    lastName: state.prospect.getIn(['lastName', 'value']),
    tel: state.prospect.getIn(['tel', 'value']),
    email: state.prospect.getIn(['email', 'value']),
    agenceSelectionnee: state.prospect.get('agence'),
    acceptCgu: state.prospect.getIn(['acceptCgu', 'value']),
  })
}

const mapDispatchToProps = (dispatch) => ({
  inputChange : (value, key) => { dispatch(inputChange(value, key)) },
})

export default connect(mapStateToProps, mapDispatchToProps)(Recap)
