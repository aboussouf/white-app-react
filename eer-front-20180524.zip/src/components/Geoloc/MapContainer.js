import MapView from './MapView'
import { connect } from 'react-redux'
import { setAgenceSelectionnee } from '../../store/actions/Geolocs'

const mapStateToProps = (state) => ({
  agences: state.geolocs.getIn(['cityAgences', 'result']),
  ville : state.geolocs.getIn(['ville', 'result']),
  agenceSelectionnee: state.prospect.get('agence'),
})

const mapDispatchToProps = (dispatch) => ({
  setAgenceSelectionnee: (agence) => { dispatch(setAgenceSelectionnee(agence)) },
})

export default connect(mapStateToProps, mapDispatchToProps)(MapView)
