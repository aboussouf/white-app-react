
import { connect } from 'react-redux'
import Select from '../components/Select'
import { inputChange } from '../../../store/actions/Inputs'
import { getBranchesByCity } from '../../../store/actions/Geolocs'

const mapStateToProps = (state, props) => {
  const [store, ...storeKey] = props.storeKey.split('.')
  storeKey.push('value')
  return ({
    value: state[store].getIn(storeKey),
    agences: state.geolocs.getIn(['cityAgences', 'result']),
  })
}

const mapDispatchToProps = (dispatch) => ({
  inputChange: (value, id) => { dispatch(inputChange(value, id)) },
  getAgencys: (payload) => { dispatch(getBranchesByCity(payload)) },
})

export default connect(mapStateToProps, mapDispatchToProps)(Select)
