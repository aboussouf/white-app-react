import React, { Component } from 'react';

class Filtered extends Component {
    render() {
        return (
            <div>
                <h2 className="all_post_heading">Your Posts</h2>
            </div>
        );
    }
}

export default Filtered;