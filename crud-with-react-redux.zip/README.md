# CRUD With React and Redux
The main goal of this was to use Redux and create a multi-user application
where users can sign in or sign up using their email-address and password. They can create,
edit,update and delete posts and view them. 
[Demo](http://tough-interest.surge.sh)