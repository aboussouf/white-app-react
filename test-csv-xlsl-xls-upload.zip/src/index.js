import React from "react";
import { render } from "react-dom";
import SheetJSApp from "./test";

const styles = {
  fontFamily: "sans-serif",
  textAlign: "center"
};

const App = () => (
  <div style={styles}>
    <SheetJSApp />
  </div>
);

render(<App />, document.getElementById("root"));
