package com.logicbig.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJdbcH2ExampleMain implements CommandLineRunner {

    @Autowired
    private ExampleClient exampleClient;

    public static void main(String[] args) {
        SpringApplication sa = new SpringApplication(SpringBootJdbcH2ExampleMain.class);
        sa.setBannerMode(Banner.Mode.OFF);
        sa.run(args);
    }

    @Override
    public void run(String... args) {
        exampleClient.run();
    }
}