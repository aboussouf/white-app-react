package com.logicbig.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import java.util.List;

@Component
public class ExampleClient {
    @Autowired
    private JdbcTemplatePersonDao dao;

    public void run() {
        Person person = Person.create("Dana", "Whitley", "464 Yellow Drive");
        System.out.println("saving person: " + person);
        dao.save(person);

        person = Person.create("Robin", "Cash", "64 Logic Park");
        System.out.println("saving person: " + person);
        dao.save(person);

        System.out.println("-- loading all --");
        List<Person> persons = dao.loadAll();
        persons.forEach(System.out::println);
    }
}