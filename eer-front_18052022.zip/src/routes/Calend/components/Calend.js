import React from 'react'
import PropTypes from 'prop-types'
import Calendar from 'react-calendar'
import InfiniteCalendar from 'react-infinite-calendar'
// import '../../Eer/css/style.scss'
import 'react-infinite-calendar/styles.css'
class calend extends React.Component {
  constructor () {
    super()

    this.state = {
      date: new Date(),
    }
    this.onChange = this.onChange.bind(this)
    this.changeDate = this.changeDate.bind(this)
  }

  changeDate = (date) => {
    date = new Date(date.getFullYear(), date.getMonth() + 1, date.getDate())
    const dateRdv = `${date.getFullYear()}-${date.getMonth() < 10 ? `0${date.getMonth()}`
      : date.getMonth()}-${date.getDate() < 10 ? `0${date.getDate()}` : date.getDate()}`
    const dateParse = new Date(dateRdv)

    return `${date.getDate()} ${dateParse.toLocaleString('fr', { month: 'short' })}`
  }
  changeString = (date) => {
    return `${date}`
  }

  onChange = (event) => {
    console.log('here', event.toISOString())
    // this.props.selectDate(this.changeDate(event), this.props.storeKey)
    this.props.selectDate(event.toISOString(), this.props.storeKey)
  }

  fonction = () => { console.log(' fon here') }
  render () {
    console.log('date :', this.state.date)
    console.log('store :', this.props.value)
    console.log('store :', this.props.value)
    var today = new Date()
    var dis = [new Date(2018, 4, 17), new Date(2018, 4, 21)]
    var lastWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate())
    // var lastYear = new Date(today.getFullYear())
    var eLocal = {

      headerFormat: 'ddd, MMM Do',
      todayLabel: {
        long: 'Auj',
      },
      locale: require('date-fns/locale/fr'),
      weekdays: ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'],
      weekStartsOn: 0,
    }
    var ethem = {
      accentColor: '#448AFF',
      floatingNav: {
        background: '#e2001a',
        chevron: '#FFA726',
        color: '#FFF',
      },
      headerColor: '#e2001a',
      selectionColor: '#e2001a',
      textColor: {
        active: '#FFF',
        default: '#333',
      },
      todayColor: '#e2001a',
      weekdayColor: '#e2001a',
    }

    return (
      <div className='row'>

        <InfiniteCalendar
          height={250}
          width={"100%"}
          className={'col-md-12'}
          selected={today}
          disabledDays={[0]}
          minDate={lastWeek}
          disabledDates={dis}
          locale={eLocal}
          theme={ethem}
          displayOptions={{
            showHeader : false, }}

          onSelect={this.onChange}
        />
      </div>
    )
    /*
    <Calendar
      onChange={this.onChange}
      value={this.state.date}
    /> */
  }
}

calend.propTypes = {
  action: PropTypes.func,
  storeKey: PropTypes.string.isRequired,
  selectDate: PropTypes.func,
}

export default calend
