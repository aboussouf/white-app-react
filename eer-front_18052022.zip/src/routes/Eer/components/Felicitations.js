import React from 'react'
import '../../../../node_modules/bootstrap/scss/mixins/_grid-framework.scss'
import '../../../assets/css/font-awesome.scss'
import '../../../assets/css/custom.scss'
import '../../../assets/css/bootstrap-float-label.min.scss'
import '../css/buttons.scss'

export const Felicitation = () => (
  <div className='tab-pane' role='tabpanel' id='step5'>
    <h1 className='text-md-center'>Félicitations !!</h1>
    <div className='row'>
      <p className='lead'>Bienvenue à la Société Générale Maroc,
                     nous sommes ravis de vous compter parmi nous et très impatients de vous recevoir pour notre premier rendez-vous en agence
                     !  Nous vous avons envoyé un mail avec votre identifiant de connexion à votre espace SGMA.
                      Dans quelques instants, vous recevrez votre mot de passe par SMS.
                      N oubliez pas de vous munir des pièces justificatives qui vous serviront à ouvrir votre compte lors de notre rendez-vous </p>
    </div>
  </div>

)

export default Felicitation
