package com.bmcek.pilotagefin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PilotagefinApplication {

	public static void main(String[] args) {
		SpringApplication.run(PilotagefinApplication.class, args);
	}
}
