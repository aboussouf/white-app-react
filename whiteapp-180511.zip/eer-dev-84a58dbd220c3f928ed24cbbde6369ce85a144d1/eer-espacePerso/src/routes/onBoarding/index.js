import onboarding from './containers'

export default onboarding
