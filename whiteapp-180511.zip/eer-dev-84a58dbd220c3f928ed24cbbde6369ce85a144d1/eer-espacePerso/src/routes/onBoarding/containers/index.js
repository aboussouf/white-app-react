import Modal from '../components/Modal'
import { connect } from 'react-redux'
import { updateValidatorOBProspect } from '../../../store/actions/Prospect'

const mapStateToProps = (state, props) => ({
  visible: state.prospect.getIn(['prospect', 'result', 'validateOB']),
})

const mapDispatchToProps = (dispatch) => ({
  updateValidatorOBProspect: (id) => { dispatch(updateValidatorOBProspect(id)) },
})

export default connect(mapStateToProps, mapDispatchToProps)(Modal)
