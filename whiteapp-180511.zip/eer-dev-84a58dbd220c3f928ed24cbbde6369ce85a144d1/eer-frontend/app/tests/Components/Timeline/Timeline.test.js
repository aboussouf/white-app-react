/* eslint-disable no-unused-expressions */

import React from 'react';
import { shallow } from 'enzyme';
import { expect } from 'chai';
import Timeline from '../../../components/Kit/Timeline';

describe('Timeline', () => {
  const steps = [
    {
      step: 0,
      title: 'first step',
    },
    {
      step: 1,
      title: 'second step',
    },
    {
      step: 2,
      title: 'last one',
    },
  ];
  const stepIndex = 1;

  it('should render 3 steps', () => {
    const wrapper = shallow(<Timeline steps={steps} current={0} />);
    expect(wrapper.find('Step')).to.have.length(3);
  });

  it('should render  the second step activated', () => {
    const wrapperActive = shallow(<Timeline steps={steps} current={stepIndex} />);
    expect(wrapperActive.find('Step').nodes[0].props.active).to.equal(false);
    expect(wrapperActive.find('Step').nodes[1].props.active).to.equal(true);
  });
  it('should render  the last step activated if current >= 2', () => {
    const wrapperActive = shallow(<Timeline steps={steps} current={4} />);
    expect(wrapperActive.find('Step').nodes[0].props.active).to.equal(false);
    expect(wrapperActive.find('Step').nodes[1].props.active).to.equal(false);
    expect(wrapperActive.find('Step').nodes[2].props.active).to.equal(true);
  });
});
