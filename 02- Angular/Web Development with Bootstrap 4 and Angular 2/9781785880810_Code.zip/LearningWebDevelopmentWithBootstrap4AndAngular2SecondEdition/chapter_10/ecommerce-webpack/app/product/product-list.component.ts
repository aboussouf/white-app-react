/*
 * Angular Imports
 */
import {Component} from '@angular/core';

@Component({
  selector: 'db-products',
  templateUrl: 'app/product/product-list.component.html'
})
export class ProductListComponent {}
