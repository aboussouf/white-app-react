/*
 * Angular Imports
 */
import { Component } from '@angular/core';

@Component({
  selector: 'db-navbar',
  templateUrl: 'app/navbar/navbar.component.html'
})
export class NavbarComponent { }

