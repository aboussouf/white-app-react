/*
 * Components
 */
import {Component} from "@angular/core";

@Component({
  selector: "db-footer",
  template: require("./footer.component.html")
})
export class FooterComponent {
}
