/*
 * Angular Imports
 */
import {Component} from "@angular/core";

@Component({
  selector: "db-products",
  template: require("./product-list.component.html")
})
export class ProductListComponent {}
