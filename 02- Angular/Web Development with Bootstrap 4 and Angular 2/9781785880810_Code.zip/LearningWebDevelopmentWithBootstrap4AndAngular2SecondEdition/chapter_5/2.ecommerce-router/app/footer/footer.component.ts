/*
 * Components
 */
import {Component} from '@angular/core';

@Component({
  selector: 'db-footer',
  templateUrl: 'app/footer/footer.component.html'
})
export class FooterComponent { }
