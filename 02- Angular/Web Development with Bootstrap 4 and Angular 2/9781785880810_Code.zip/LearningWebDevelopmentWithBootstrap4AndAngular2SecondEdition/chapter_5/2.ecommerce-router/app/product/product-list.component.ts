/*
 * Angular Imports
 */
import {Component} from '@angular/core';

/*
 * Components
 */

@Component({
  selector: 'db-products',
  templateUrl: 'app/product/product-list.component.html'
})
export class ProductListComponent {}
