import React, { Component } from 'react';
import { render } from 'react-dom';
import FileReaderInput from 'react-file-reader-input';

const styles = {
  fontFamily: 'sans-serif',
  textAlign: 'center'
};

class App extends Component {
  uploadFile = (result, file) => {
    console.log(`${file.name} load successful`);
  };

  handleChange = (e, results) => {
    results.forEach(result => {
      const [e, file] = result;

      this.uploadFile(e.target.result, file);
    });
  };
  render() {
    return (
      <div style={styles}>
        <form>
          <label htmlFor="my-file-input">Upload a File:</label>
          <FileReaderInput
            as="binary"
            id="my-file-input"
            onChange={this.handleChange}
          >
            <button onClick={e => e.preventDefault()}>Select a file!</button>
          </FileReaderInput>
        </form>
      </div>
    );
  }
}

render(<App />, document.getElementById('root'));
