import React from 'react';

class Footer extends React.Component {
    render() {
        return (
            <div className="footer">
                <div className="pull-right">
                    <strong className="footerClass">BMCE CAPITAL BOURSE</strong>
                </div>
                <div className="footerClass">
                    <strong >Copyright</strong> BMCE CAPITAL &copy; 2018
                </div>
            </div>
        )
    }
}

export default Footer
