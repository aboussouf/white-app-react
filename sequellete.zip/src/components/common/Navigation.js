import React, { Component } from 'react';
import { Dropdown } from 'react-bootstrap';
//import { Link, Location } from 'react-router-dom';
import { Link, Location } from 'react-router';
import bmcecap from '../../public/img/bkm.png'
import {Image,Glyphicon} from 'react-bootstrap'
import $ from 'jquery'

class Navigation extends Component {

    componentDidMount() {
        const { menu } = this.refs;
        $(menu).metisMenu();
    }

    activeRoute(routeName) {
      console.log("activeRoute this.props.location.pathname : "+this.props.location.pathname)

      return this.props.location.pathname.indexOf(routeName) > -1 ? "active" : "";
    }

    secondLevelActive(routeName) {
      console.log("secondLevelActive this.props.location.pathname : "+this.props.location.pathname)
      return this.props.location.pathname.indexOf(routeName) > -1 ? "nav nav-second-level collapse in" : "nav nav-second-level collapse";
    }

    render() {
        return (
            <nav className="navbar-default navbar-static-side" role="navigation">
                    <ul className="nav metismenu" id="side-menu" ref="menu">
                        <li className="nav-header">
                            <div className="dropdown profile-element"> <span>
                             </span>
                                <a data-toggle="dropdown" className="dropdown-toggle" href="#">
                                  <Image src={bmcecap} style={{'widt':'195px','heigh':'72px','paddin':'5px'}}/>
                                </a>
                                
                            </div>
                            <div className="logo-element">
                                BKM
                            </div>
                        </li>
                        <li>
                            <Link><i className="fa fa-bar-chart"></i> <span className="nav-label">Reporting</span></Link>
                            <ul className={this.secondLevelActive()}>
                                <li><Link to="/synthese">Synthèse</Link></li>
                                <li><Link to="/historique">Historique</Link></li>
                                <li><Link to="/detail">Détail par produit</Link></li>
                            </ul>
                        </li>
                        <li>
                            <Link><i className="fa fa-database"></i> <span className="nav-label">Data</span></Link>
                            <ul className={this.secondLevelActive()}>
                                <li><Link to="/composition">Composition OPCVM</Link></li>
                                <li><Link to="/suspens">Suspens</Link></li>
                                <li><Link to="/cotations">Cotations Action</Link></li>
                            </ul>
                        </li>
                        <li className={this.activeRoute("/calculcfp")}>
                          <Link to="/calculcfp"><i className="fa fa-refresh"></i> <span className="nav-label">Calcul CFP</span></Link>
                        </li>
                        <li className={this.activeRoute("/administration")}>
                          <Link to="/administration"><i className="fa fa-cogs"></i> <span className="nav-label">Administration</span></Link>
                        </li>
                    </ul>

            </nav>
        )
    }
}

export default Navigation