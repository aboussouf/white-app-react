import React, { Component } from 'react';

class Cotations extends Component {

    render() {
        return (
          <div>
          <div class="row wrapper border-bottom navigation-path page-heading">
              <div class="col-lg-10">
                  <h2>Data / Cotations Action</h2>
              </div>
          </div>
            <div className="wrapper wrapper-content">
                <div className="row">
                    
                </div>
            </div>
            </div>
        )
    }

}

export default Cotations
