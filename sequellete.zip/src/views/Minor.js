import React, { Component } from 'react';

class Minor extends Component {

    render() {
        return (
            <div className="wrapper wrapper-content">
                <div className="row">
                    <div className="col-lg-12">
                        <div className="text-center m-t-lg">
                            <h1>
                                Page 2
                            </h1>
                            
                        </div>
                    </div>
                </div>
            </div>
        )
    }

}

export default Minor