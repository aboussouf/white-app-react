import React, { Component } from 'react';
import '../index.css'

class Synthese extends Component {

    render() {
        return (
          <div>
          <div class="row wrapper border-bottom navigation-path page-heading">
              <div class="col-lg-10">
                  <h2>Reporting / Synthèse</h2>
                  
              </div>
              <div class="col-lg-2">

              </div>
          </div>
            <div className="wrapper wrapper-content">
                <div className="row">
                    <div className="col-lg-12">
                        {/*<div className="text-center m-t-lg">
                            <h1>
                              Synthese
                            </h1>

                        </div>*/}
                    </div>
                </div>
            </div>
            </div>
        )
    }

}

export default Synthese
