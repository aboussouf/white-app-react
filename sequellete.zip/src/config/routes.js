import React from 'react'
import Main from '../components/layouts/Main';
import Blank from '../components/layouts/Blank';

import MainView from '../views/Main';
import MinorView from '../views/Minor';
import Synthese from '../views/Synthese.js';
import Historique from '../views/Historique.js';
import Detail from '../views/Detail.js';

import Composition from '../views/Composition.js';
import Suspens from '../views/Suspens.js';
import Cotations from '../views/Cotations.js';

import CalculCFP from '../views/CalculCFP.js';

import Administration from '../views/Administration.js';

import { Route, Router, IndexRedirect, browserHistory} from 'react-router';
//import {BrowserRouter as Router , Switch,Route } from 'react-router-dom';
export default (
    <Router history={browserHistory}>
        <Route path="/" component={Main}>
            <Route path="main" component={MainView}/>
            <Route path="minor" component={MinorView}/>
            <Route path="/synthese" component={Synthese}/>
            <Route path="/historique" component={Historique}/>
            <Route path="/detail" component={Detail}/>
            <Route path="/composition" component={Composition}/>
            <Route path="/suspens" component={Suspens}/>
            <Route path="/cotations" component={Cotations}/>
            <Route path="/calculcfp" component={CalculCFP}/>
            <Route path="/administration" component={Administration}/>
        </Route>
    </Router>

);