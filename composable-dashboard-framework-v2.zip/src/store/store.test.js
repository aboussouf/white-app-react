import expect from 'expect';
import { createStore } from 'redux';
import rootReducer from '../redux/rootReducer.js';
import * as dashboardActions from '../redux/dashboard/dashboard-actions.js';

describe('Store', function () {
  it('test loadDashboard', function () {
    // arrange
    const store = createStore(rootReducer);
    const layout = {
      title: "Clean Code"
    };

    // act
    const action = dashboardActions.loadDashboard(layout);
    store.dispatch(action);

    // assert
    const actual = store.getState().dashboard.widgetLayout;
    const expected = {
      title: "Clean Code"
    };

    // this is failing, dunno why, come back to it later
    //expect(actual).toEqual(expected);
  });
});
