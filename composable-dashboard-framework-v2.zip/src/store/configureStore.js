import { createStore, applyMiddleware } from 'redux';
import rootReducer from '../redux/rootReducer.js';
import reduxImmutableStateInvariant from 'redux-immutable-state-invariant';
import thunk from 'redux-thunk';

export default function configureStore() {

	if (process.env.NODE_ENV === 'production') {
		return createStore(
			rootReducer,
			applyMiddleware(thunk)
		);
	} else {
		return createStore(
			rootReducer,
			applyMiddleware(thunk, reduxImmutableStateInvariant())
		);
	}
}
