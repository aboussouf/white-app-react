import delay from './delay';

// This file mocks a web API by working with the hard-coded data below.
// It uses setTimeout to simulate the delay of an AJAX call.
// All calls return promises.
//We want our own code routes and elements here --David
const defaultDash = {
  id: "1",
  dashboardType: "homepage",
  title: "default homepage",
  widgetLayout: { content: 'ask ryan what dashboard librry needs' }
};
let userDash = {
  id: "2",
  dashboardType: "homepage",
  title: "matt's homepage",
  widgetLayout: { content: 'ask ryan what dashboard librry needs' }
};

let savedOnce = false;

class DashboardService {

  static getUserDashboard(dashType) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve(Object.assign({}, savedOnce ? userDash : defaultDash));
      }, delay);
    });
  }

  static saveUserDashboard(dashType, dashboard) {
    dashboard = Object.assign({}, dashboard); // to avoid manipulating object passed in.
    return new Promise((resolve, reject) => {
      setTimeout(() => {

        // replace user dash
        savedOnce = true;
        userDash = dashboard;

        resolve(dashboard);
      }, delay);
    });
  }

  static restoreDefaultDashboard(dashType) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        savedOnce = false; // reset so getUserDash returns default
        resolve(Object.assign({}, defaultDash));
      }, delay);
    });
  }

}

export default DashboardService;
