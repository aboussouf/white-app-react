// This class abstracts the client app from knowing the details of the webservice calls

import { checkStatus, fetchWithTimeout } from './httpHelpers'; // use helper from minion project

class AppStoreService {

  static getAllApps() {
    return fetchWithTimeout({ url: '/appstore-service/getAllApps' })
      .then(checkStatus)
      .then(response => response.json())
      .catch(error => error);
  }
	/*
  static updateApp(app) {
    return fetchWithTimeout({
      url: '/appstore-service/updateApp',
      options: {
        method: 'POST',
        body: JSON.stringify(app)
      }
    })
    .then(checkStatus)
    .then(response => response.json())
    .catch(error => error);
  }

   static addApp(app) {
    return fetchWithTimeout({
      url: '/appstore-service/addApp',
      options: {
        method: 'POST',
        body: JSON.stringify(app)
      }
    })
    .then(checkStatus)
    .then(response => response.json())
    .catch(error => error);
  }
	*/

}

export default AppStoreService;
