import delay from './delay';

// This file mocks a web API by working with the hard-coded data below.
// This file is a stub to return hard coded data instead of calling the real webservice.
// It uses setTimeout to simulate the delay of an AJAX call.
// All calls return promises.

// test data that would otherwise come from webservice
const apps = [
  {
    id: 'welcome',
    group: 'all',
    name: 'welcome',
    title: 'Welcome Widget',
    description: 'tutorial on how to use dashboards',
    route: 'widgets/welcome'
  },
  {
    id: 'widgetA',
    group: 'all',
    name: 'widgetA',
    title: 'Widget A',
    description: 'Widget A',
    route: 'widgets/widgetA'
  },
  {
    id: 'workspaceWidgetB',
    group: 'workspaces',
    name: 'workspaceWidgetB',
    title: 'Workspace Widget B',
    description: 'Widget only applicable in workspaces',
    route: 'widgets/workspaces/workspaceWidgetB'
  }
];

class AppStoreService {
  static getAllApps() {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        resolve(Object.assign([], apps));
      }, delay);
    });
  }
  /*
    static updateApp(app) {
      app = Object.assign({}, app); // to avoid manipulating object passed in.
      return new Promise((resolve, reject) => {
        setTimeout(() => {
  
          // simulate updating in db - here we just edit array
          if (app.id) {
            const index = apps.findIndex(a => a.id == app.id);
            apps.splice(index, 1, app);
          }
  
          resolve(app);
        }, delay);
      });
    }
  
  
    static addApp(app) {
      app = Object.assign({}, app); // to avoid manipulating object passed in.
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          const index = apps.findIndex(a => a.id == app.id);
      if (!index){
            apps.push(app);
          }
          resolve(app);
        }, delay);
      });
    }
    */
}

export default AppStoreService;
