// httpHelpers.js

import 'whatwg-fetch';
import { Map, fromJS } from 'immutable';

import appConfig from '../appConfig';
import { getUserDn } from '../util/helpers';

/**
 * Interceptor function for acting on HTTP status codes.
 * 
 * @param  {[Object]} JSON response
 * @return {[type]}
 */
function checkStatus(response) {
  if (response.status >= 200 && response.status < 300) {
    return response;
  }
  else if (response['status'] && response['status'] === 408) {
    throw new Error('The request has timed out.');
  }
  else {
    let error = new Error(response.statusText);
    error.response = response;
    let json = response.json();
    return json.then(errJson => {
      error.json = errJson;
      throw error;
    });
  }
}

/**
 * Wrapper function for whatwg-fetch that allows for fine grain timeout control.
 * 
 * @param  {[Object]} apiConfig [Api configuration object]
 * @return {[Promise]}
 */
function fetchWithTimeout(apiConfig) {
  const config =
    Map(
      fromJS({
        url: '',
        timeoutMs: `${appConfig.requestTimeout}`,
        options: {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'User_Dn': getUserDn()
          }
        }
      })
    ).mergeDeep(
      fromJS(apiConfig)
      ).toJS();

  // leverage ES6 Promise object
  return new Promise(function (resolve, reject) {
    let timeout = setTimeout(function () {
      // HTTP 1.1 408 Request Timeout
      reject({ status: 408 });
      clearTimeout(timeout);
    }, config.timeoutMs);

    return config['options'] ?
      fetch(config.url, config.options).then(resolve, reject) :
      fetch(config.url).then(resolve, reject);

  });
}

export { checkStatus, fetchWithTimeout };