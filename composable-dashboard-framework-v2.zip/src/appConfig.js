//Security setup....
export default {
  requestTimeout: 15000,
  userServiceEndpoint: '/service/userservice/1.0',
  requireAuthentication: true,
  // don't change the value of nodeEnv manually, it will be 
  // replaced when running the 'serve' gulp task
  nodeEnv: '{{NODE_ENV}}',
  capco: {
    unclassified: {
      banner: 'UNCLASSIFIED',
      classif: 'U'
    }
  }
};