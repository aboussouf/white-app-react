import {
  REQUEST_APPS,
  RECEIVE_APPS,
  EXPAND_APPSTORE,
  COLLAPSE_APPSTORE
} from './appstore-actions.js';

const defaultState = () => {
  return {
    apps: [],
    isExpanded: true,
    isFetching: false
  };
};

export default function appstore(state = defaultState(), action = {}) {
  switch (action.type) {
    case REQUEST_APPS:
      return {
        ...state,
        isFetching: true
      };

    case RECEIVE_APPS:
      return {
        ...state,
        isFetching: false,
        apps: action.apps
      };

    case EXPAND_APPSTORE:
      return {
        ...state,
        isExpanded: true
      };

    case COLLAPSE_APPSTORE:
      return {
        ...state,
        isExpanded: false
      };

    default:
      return state;
  }
}
