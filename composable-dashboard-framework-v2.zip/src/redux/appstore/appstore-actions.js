import AppStoreService from '../../service/appStoreService.mock.js';

const REQUEST_APPS = 'REQUEST_APPS';
const RECEIVE_APPS = 'RECEIVE_APPS';
const EXPAND_APPSTORE = 'EXPAND_APPSTORE';
const COLLAPSE_APPSTORE = 'COLLAPSE_APPSTORE';

function receiveApps(apps) {
  return { type: RECEIVE_APPS, apps };
}

function requestApps() {
  return { type: REQUEST_APPS };
}

function fetchApps() {
  return dispatch => {
    dispatch(requestApps());
    return AppStoreService.getAllApps().then(json => dispatch(receiveApps(json)));
  };
}

export {
  fetchApps,
  REQUEST_APPS,
  RECEIVE_APPS,
  EXPAND_APPSTORE,
  COLLAPSE_APPSTORE
};
