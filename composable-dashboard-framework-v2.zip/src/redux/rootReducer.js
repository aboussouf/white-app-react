import { combineReducers } from 'redux';
import appstore from './appstore/appstore-reducer.js';
import dashboard from './dashboard/dashboard-reducer.js';

const rootReducer = combineReducers({
  appstore,
  dashboard
});

export default rootReducer;
