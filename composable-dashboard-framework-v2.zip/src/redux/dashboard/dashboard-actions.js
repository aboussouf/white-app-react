import DashboardService from '../../service/dashboardService.mock.js';

const GET_DASHBOARD_REQUEST = 'GET_DASHBOARD_REQUEST';
const LOAD_DASHBOARD = 'LOAD_DASHBOARD';
const SAVE_DASHBOARD_REQUEST = 'SAVE_DASHBOARD_REQUEST';
const RESTORE_DEFAULT_REQUEST = 'RESTORE_DEFAULT_REQUEST';

function getDashboardsRequest() {
  return { type: GET_DASHBOARD_REQUEST };
}

function loadDashboard(widgetLayout) {
  return { type: LOAD_DASHBOARD, widgetLayout };
}

function saveDashboardRequest() {
  return { type: SAVE_DASHBOARD_REQUEST };
}

function restoreDefaultRequest() {
  return { type: RESTORE_DEFAULT_REQUEST };
}

function saveDashboardsSuccess(result) {
  // what goes here?	nothing to do
}

// fetch user saved or default if they havent saved one yet
function fetchUserDashboard(dashboardType) {
  return dispatch => {
    dispatch(getDashboardsRequest());
    return DashboardService.getUserDashboard(dashboardType).then(json => dispatch(loadDashboard(json)));
  };
}

// save dash
function saveDashboard(dashboardType, widgetLayout) {
  return dispatch => {
    dispatch(saveDashboardRequest());
    return DashboardService.saveUserDashboard(dashboardType, widgetLayout).then(result => dispatch(saveDashboardsSuccess(result)));
  };
}

// delete saved user dash, return default dash
function restoreDefaultDashboard(dashboardType) {
  return dispatch => {
    dispatch(restoreDefaultRequest());
    return DashboardService.restoreDefaultDashboard(dashboardType).then(json => dispatch(loadDashboard(json)));
  };
}

export {
  loadDashboard,
  fetchUserDashboard,
  saveDashboard,
  restoreDefaultDashboard,
  GET_DASHBOARD_REQUEST,
  LOAD_DASHBOARD,
  SAVE_DASHBOARD_REQUEST,
  RESTORE_DEFAULT_REQUEST
};
