import { DashboardType } from '../../components/dashboard/Dashboard.js';

import {
  GET_DASHBOARD_REQUEST,
  LOAD_DASHBOARD,
  SAVE_DASHBOARD_REQUEST,
  RESTORE_DEFAULT_REQUEST
} from './dashboard-actions.js';

const defaultState = () => {
  return {
    dashboardType: DashboardType.homepage,
    widgetLayout: { content: 'loading' },
    isFetching: false
  };
};

export default function dashboard(state = defaultState(), action = {}) {
  switch (action.type) {
    case GET_DASHBOARD_REQUEST:
      return {
        ...state,
        isFetching: true
      };

    case LOAD_DASHBOARD:
      return {
        ...state,
        isFetching: false,
        widgetLayout: action.widgetLayout
      };

    case SAVE_DASHBOARD_REQUEST:
      return {
        ...state,
        widgetLayout: action.widgetLayout
      };

    case RESTORE_DEFAULT_REQUEST:
      return {
        ...state,
        isFetching: true,
        widgetLayout: action.widgetLayout
      };

    default:
      return state;
  }
}
