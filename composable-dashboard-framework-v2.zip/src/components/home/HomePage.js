import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { Link } from 'react-router';
import AppStore from '../appstore/AppStore';
import { Dashboard } from '../dashboard/Dashboard';

class HomePage extends React.Component {

  constructor(props, context) {
    super(props, context);
  }

  render() {
    return (
      <div className="container">
        <table>
          <tbody>
            <tr>
              <td className="container-left"><Dashboard dashboard={this.props.dashboard} /></td>
              <td className="container-right"><AppStore appstore={this.props.appstore} /></td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}

HomePage.propTypes = {
  dashboard: PropTypes.object.isRequired,
  appstore: PropTypes.object.isRequired
};

function mapStateToProps(state, ownProps) {
  return {
    dashboard: state.dashboard,
    appstore: state.appstore
  };
}

function mapDispatchToProps(dispatch) {
  return {
    //actions: bindActionCreators(courseActions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(HomePage);
