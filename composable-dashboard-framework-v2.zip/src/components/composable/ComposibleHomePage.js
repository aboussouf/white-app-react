import React, { Component } from 'react';
import AppStore from '../appstore/AppStore';
import Dashboard from '../dashboard/Dashboard';

class ComposibleHomePage extends Component {
  render() {
    return (
      <div className="container">

        <table>
          <td className="container-left"><Dashboard /></td>
          <td className="container-right"><AppStore /></td>
        </table>
      </div>
    );
  }
}

export default ComposibleHomePage;