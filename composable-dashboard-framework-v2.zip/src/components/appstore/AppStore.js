import React, { Component, PropTypes } from 'react';

class AppStore extends Component {

  constructor(props, context) {
    super(props, context);
  }

  render() {
    return (
      <div>
        <div>AppStore</div>
        <div>{JSON.stringify(this.props.appstore.apps)}</div>
      </div>
    );
  }
}

AppStore.propTypes = {
  appstore: PropTypes.object.isRequired
};

export default AppStore;
