import React, { Component, PropTypes } from 'react';

const DashboardType = {
  homepage: 'homepage',
  country: 'country',
  cocom: 'cocom',
  veo: 'veo',
  workspace: 'workspace'
};


class Dashboard extends Component {
  constructor(props, context) {
    super(props, context);
  }

  render() {
    return (
      <div>
        <div>{JSON.stringify(this.props.dashboard.dashboardType)}</div>
        <div>{JSON.stringify(this.props.dashboard.widgetLayout)}</div>
      </div>
    );
  }
}

Dashboard.propTypes = {
  dashboard: PropTypes.object.isRequired
};

export { DashboardType, Dashboard };
