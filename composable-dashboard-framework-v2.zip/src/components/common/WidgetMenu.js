import React, { PropTypes } from 'react';
import {
  Menu,
  MenuItem,
  MenuDivider,
  Position,
  Popover,
  PopoverInteractionKind
} from "@blueprintjs/core";
require("@blueprintjs/core/dist/blueprint.css")


class WidgetMenu extends React.Component<{}, {}> {
  render() {
    return (
      <Menu>
        <MenuItem iconName="thumbs-up" onClick={this.handleClick} text="Welcome" />
        <MenuItem iconName="globe" onClick={this.handleClick} text="Map" />
        <MenuItem iconName="search" onClick={this.handleClick} text="Search" />
        <MenuDivider />
        <MenuItem text="Settings..." iconName="cog" />
      </Menu>
    );
  }

  handleClick(e) {
    console.log("clicked", e.target);
  }
}

export default WidgetMenu;