import * as types from '../actions/actionTypes';
import initialState from './initialState';

export default function dashboardReducer(state = initialState.dashboards, action) {
  switch (action.type) {
    case types.LOAD_DASHBOARDS_SUCCESS:
      return action.dashboards;

    case types.CREATE_DASHBOARD_SUCCESS:
      return [
        ...state,
        Object.assign({}, action.dashboard)
      ];

    case types.UPDATE_DASHBOARD_SUCCESS:
      return [
        ...state.filter(dashboard => dashboard.id !== action.dashboard.id),
        Object.assign({}, action.dashboard)
      ];

    default:
      return state;
  }
}