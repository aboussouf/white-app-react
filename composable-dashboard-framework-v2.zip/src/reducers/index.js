import { combineReducers } from 'redux';
import dashboards from './dashboardReducer';
import ajaxCallsInProgress from './ajaxStatusReducer';

const rootReducer = combineReducers({
  dashboards,
  ajaxCallsInProgress
});

export default rootReducer;