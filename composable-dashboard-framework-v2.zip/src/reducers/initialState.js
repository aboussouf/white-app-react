export default {
  dashboards: [],
  ajaxCallsInProgress: 0
};