import $ from 'jquery';
import { List } from 'immutable';
import configureStore from '../store/configureStore';
import appConfig from '../appConfig';

/**
 * @param  {Object}  canvasConfig  {canvas: Node, thumnailUrl: String, imageX: Number, imageY: Number}
 * @return {[type]}
 */
function loadCanvasImage(canvasConfig) {
  let loadImage = function (canvas, url, imageX = 0, imageY = 0) {
    let image = new Image();
    image.crossOrigin = 'anonymous';

    image.onload = function () {
      let ctx = canvas.getContext('2d');
      ctx.drawImage(image, imageX, imageY, 100, 100);
      let data = ctx.getImageData(imageX, imageY, 1, 1).data;
      let hex = '#' + ('000000' + rgbToHex(data[0], data[1], data[2])).slice(-6);
      ctx.globalCompositeOperation = 'destination-over';
      ctx.fillStyle = hex;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    };

    let rgbToHex = function (r, g, b) {
      if (r > 255 || g > 255 || b > 255) {
        throw 'Invalid color component';
      }
      return ((r << 16) | (g << 8) | b).toString(16);
    };

    // load image last due to CORS config
    image.src = `img/${url}`;
  };

  // fill canvas
  loadImage(canvasConfig.canvas, canvasConfig.thumbnailUrl, canvasConfig.imageX, canvasConfig.imageY);
}

/**
 * @param  {Node}  el  Node to be searched
 * @param  {String}  moreTags  Comma delimited string of input tag names
 * @return {[Object]}  Map of input names and values
 */
function getFormData(el, moreTags = '') {
  let tags = 'input, select, textarea',
    inputs = {};

  if (moreTags.length) {
    tags = `${tags}, ${moreTags}`;
  }

  $(el).find(tags).toArray().forEach(function (input) {
    inputs[$(input).attr('name')] = $(input).val();
  });

  return inputs;
}

/**
 * Get user's DN from the store.
 *
 * @return {[String]}
 */
function getUserDn() {
  let userDn = '';
  const store = configureStore();
  if (store.getState().user.getIn(['user', 'userData'])) {
    userDn = store.getState().user.getIn(['user', 'userData', 'tokens']).first().get('tokenValue');
  }

  return userDn;
}

/**
 * Parse a date from UTC seconds into 1/1/2016 form.
 *
 * @param  {[Number]} utcSeconds
 * @return {[String]}
 */
function parseUTCDate(utcSeconds) {
  let date = new Date(utcSeconds);
  return `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
}

/**
 * Return a list of ACM objects for rollup
 *
 * @param  {Immutable List or Primitive Array} minions
 * @return {Array} array of ACM objects
 */
function getACMs(minions) {
  // convert minions to an Immutable.List if not of type Immutable.List
  if (List.isList(minions)) {
    minions = minions.toJS();
  }

  function getACMs(channelType) {
    return minions.flatMap((minion) => {
      const inputKeys = Object.keys(minion[channelType].config.trigger.inputs);
      return inputKeys.map((key) => {
        return minion[channelType].config.trigger.inputs[key]['acm'];
      });
    })
      .filter((acm) => acm !== null && acm !== undefined);
  }

  // get all inChannel input ACMs
  let inChannelACMs = getACMs('inChannel');
  let outChannelACMs = getACMs('outChannel');

  // merge all ACMS into the inChannelACMs array
  Array.prototype.push.apply(inChannelACMs, outChannelACMs);

  // if no acms have been found in either channel then default to unclassified
  if (!inChannelACMs.length) {
    inChannelACMs = [appConfig.capco.unclassified];
  }

  return inChannelACMs;
}

/**
 * Some of the inputs have a "order" property to allow channel developers to
 * control the rendering order of the inputs.  As such We need to sort the inputs accordingly.
 *
 * @return {Array} array of ordered input objects
 */
function getOrderedInputs(inputs) {
  if (!inputs) return;

  return Object.keys(inputs)
    .map((key) => {
      inputs[key].name = key;
      return inputs[key];
    })
    .sort((a, b) => {
      if (!a['order'] || !b['order']) return;
      return a.order - b.order;
    });
}

function getHighestClassification(acms) {
  if (acms.length === 1) return acms[0];

  const classifications = {
    U: 1, // unclassified
    C: 2, // confidential
    S: 3, // secret
    TS: 4 // top secret
  };

  let acmList = new List(acms);
  let highest;

  acmList
    .reduce((prev, curr) => {
      highest = classifications[prev.classif] > classifications[curr.classif] ? prev : curr;
    });

  return highest;
}

export {
  loadCanvasImage,
  getFormData,
  getUserDn,
  parseUTCDate,
  getACMs,
  getOrderedInputs,
  getHighestClassification
};
