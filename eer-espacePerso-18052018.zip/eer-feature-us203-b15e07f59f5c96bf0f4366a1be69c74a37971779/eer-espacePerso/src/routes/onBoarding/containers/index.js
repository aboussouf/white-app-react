import Modal from '../components/Modal'
import { connect } from 'react-redux'
import { updateValidatorOBProspect } from '../../../store/actions/Prospect'

const mapStateToProps = (state, props) => ({
  visible: state.prospect.getIn(['prospect', 'result', 'validateOB']),
  userId: state.prospect.getIn(['prospect', 'result', 'idProspect']),
})

const mapDispatchToProps = (dispatch) => ({
  updateValidatorOBProspect: (id) => { dispatch(updateValidatorOBProspect(id)) },
})

function mergeProps (stateProps, dispatchProps, ownProps) {
  return Object.assign({}, ownProps, stateProps, dispatchProps, {
    updateValidatorOBProspect: () => dispatchProps.updateValidatorOBProspect(stateProps.userId)
  })
}

export default connect(mapStateToProps, mapDispatchToProps, mergeProps)(Modal)
