import CustomTab from '../components/CustomTab'
import { connect } from 'react-redux'
import { saveProspect } from '../../../store/actions/Prospect'

const mapStateToProps = (state, props) => ({
  prospect: {
    idProspect: state.prospect.getIn(['prospect', 'value', 'idProspect']),
    address: state.prospect.getIn(['address1', 'value']),
    addressComplement: state.prospect.getIn(['address2', 'value']),
    civilite: state.prospect.getIn(['civilty', 'value']),
    email: state.prospect.getIn(['email', 'value']),
    firstName: state.prospect.getIn(['firstName', 'value']),
    idBirthCity: state.prospect.getIn(['birthCity', 'value']),
    idCity: state.prospect.getIn(['city', 'value']),
    lastName: state.prospect.getIn(['lastName', 'value']),
    nbrEnfACharge: state.prospect.getIn(['childrens', 'value']),
    numeroMobile: state.prospect.getIn(['mobile', 'value']),
    numeroTel: state.prospect.getIn(['tel', 'value']),
    secteurActivite: state.prospect.getIn(['activity', 'value']),
    situationFamiliale: state.prospect.getIn(['situation', 'value']),
    statutProfessionnel: state.prospect.getIn(['function', 'value']),
    zipCode:state.prospect.getIn(['zipCode', 'value']),
  }
})

const mapDispatchToProps = (dispatch) => ({
  saveProspect: (id) => { dispatch(saveProspect(id)) },
})
function mergeProps (stateProps, dispatchProps, ownProps) {
  return Object.assign({}, ownProps, stateProps, dispatchProps, {
    saveProspect: () => dispatchProps.saveProspect(stateProps.prospect)
  })
}

export default connect(mapStateToProps, mapDispatchToProps, mergeProps)(CustomTab)
