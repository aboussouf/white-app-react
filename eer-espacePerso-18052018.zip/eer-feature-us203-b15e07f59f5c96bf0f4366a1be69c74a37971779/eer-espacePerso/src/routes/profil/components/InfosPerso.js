import React from 'react'
import * as constants from '../../../constants/constants'
import Input from '../../../components/InputText'
import Select from '../../../components/Select'

const civilityOptions = [
  { label: 'Madame', value: 'Mme', checked: true },
  { label: 'Monsieur', value: 'Mr' },
]

class infosPerso extends React.Component {
  render () {
    return (
      <div>
        <div className='form-group row'>
          <Select options={civilityOptions} storeKey='prospect.civility' label='Civilité' />
          <Input
            storeKey='prospect.lastName'
            label='Nom '
            placeholder='Mon nom'
            error='Veuillez saisir un nom valide'
            pattern={constants.REGEX_PROSPECT_NAME}
          />
        </div>
        <div className='form-group row' >
          <Input
            storeKey='prospect.firstName'
            label='Prénom '
            placeholder='Mon Prenom'
            error='Veuillez saisir un prénom valide'
            pattern={constants.REGEX_PROSPECT_NAME}
          />
          <Input
            storeKey='prospect.mobile'
            label='Téléphone '
            placeholder='Mon téléphone'
            error='Veuillez saisir un numero téléphone valide'
            pattern={constants.REGEX_PROSPECT_PHONE}
          />
        </div>
        <div className='form-group row' >
          <Input
            storeKey='prospect.birthDate'
            label='Date de naissance '
            placeholder='Ma date de naissance'
            error='Veuillez saisir une date valide : 12/04/1998'
            pattern={constants.REGEX_PROSPECT_DATE}
          />
          <Input
            storeKey='prospect.birthCity'
            label='Ville de naissance'
            placeholder='Ma ville'
            error='Veuillez saisir un ville valide'
            pattern={constants.REGEX_PROSPECT_NAME}
          />
        </div>
      </div>
    )
  }
}

export default infosPerso
