import React from 'react'
import Input from '../../../components/InputText'
import Select from '../../../components/Select'

const situationOptions = [
  { label: 'Célibataire', value: 'CELIBATAIRE' },
  { label: 'Marié(e)', value: 'Marie' },
  { label: 'Divorcé(e)', value: 'MARIE' },
  { label: 'Veuf(ve)', value: 'VEUF' },
]
const childrenOptions = [
  { label: '0', value: '0' },
  { label: '1', value: '1' },
  { label: '2', value: '2' },
  { label: '3 et +', value: '3 et +' },
]
const functionOptions = [
  { label: 'salarié', value: 'SALARIE' },
  { label: 'indépendant', value: 'INDEPENDANT' },
  { label: 'retraité', value: 'RETRAITE' },
  { label: 'sans activité', value: 'SANS_ACTIVITE' },
]
const revenuOptions = [
  { label: 'entre 0 et 7 500 MAD', value: 'ENTRE_0_7500' },
  { label: 'entre 7 500 et 10 000 MAD', value: 'ENTRE_7500_10000' },
  { label: 'entre 10 000 et 25 000 MAD', value: 'ENTRE_10000_25000' },
  { label: 'entre 25 000 et 40 000 MAD', value: 'ENTRE_25000_40000' },
  { label: 'plus de 40 000 MAD', value: 'PLUS_40000' },
]

class Situation extends React.Component {
  render () {
    return (
      <div>
        <div className='form-group row'>
          <Select options={situationOptions} storeKey='prospect.situation' label='Vie privée' />
          <Select options={childrenOptions} storeKey='prospect.childrens' label='Enfants à charge' />
        </div>
        <div className='form-group row' >
          <Select options={functionOptions} storeKey='prospect.function' label='Statut professionnel' />
          <Input
            storeKey='prospect.activity'
            label='Secteur d&apos;activité '
            placeholder=''
            error='Veuillez saisir une activité valide : '
          />
        </div>
        <div className='form-group row' >
          <Select options={revenuOptions} storeKey='prospect.revenu' label='Revenus mensuels (net)' />
        </div>
      </div>
    )
  }
}

export default Situation
