import React from 'react'
import * as constants from '../../../constants/constants'
import Input from '../../../components/InputText'

class Coordonnees extends React.Component {
  render () {
    return (
      <div>
        <div className='form-group row'>
          <Input
            storeKey='prospect.address1'
            label='Adresse 1 '
            placeholder='Mon adresse'
            error='Veuillez saisir une adresse valide'
          />
          <Input
            storeKey='prospect.address2'
            label='Adresse 2 '
            placeholder='Mon adresse'
            error='Veuillez saisir une adresse valide'
          />
        </div>
        <div className='form-group row' >
          <Input
            storeKey='prospect.city'
            label='Ville '
            placeholder='Ma ville'
            error='Veuillez saisir une ville valide : '
          />
          <Input
            storeKey='prospect.zipCode'
            label='Code postal '
            placeholder='Mon code postal'
            error='Veuillez saisir un code valide'
          />
        </div>
        <div className='form-group row' >
          <Input
            storeKey='prospect.email'
            label='Email '
            placeholder='Mon email'
            error='Veuillez saisir un email valide'
            pattern={constants.REGEX_PROSPECT_EMAIL}
          />
          <Input
            storeKey='prospect.emailConfirm'
            label='Confirmation Email  '
            placeholder=''
            error='Veuillez saisir un email valide'
            pattern={constants.REGEX_PROSPECT_EMAIL}
          />
        </div>
        <div className='form-group row' >
          <Input
            storeKey='prospect.tel'
            label='Téléphone '
            placeholder=''
            error='Veuillez saisir un téléphone valide'
            pattern={constants.REGEX_PROSPECT_PHONE}
          />
          <Input
            storeKey='prospect.mobile'
            label='Mobile '
            placeholder=''
            error='Veuillez saisir un téléphone valide'
            pattern={constants.REGEX_PROSPECT_PHONE}
          />
        </div>
      </div>
    )
  }
}

export default Coordonnees
