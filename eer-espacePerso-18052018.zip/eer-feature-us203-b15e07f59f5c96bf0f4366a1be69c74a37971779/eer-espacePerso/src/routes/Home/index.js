import Home from './components/HomeView'

export default Home
