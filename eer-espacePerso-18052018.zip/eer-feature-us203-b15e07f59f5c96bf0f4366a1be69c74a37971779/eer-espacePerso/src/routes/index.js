// We only need to import the modules necessary for initial render

import React from 'react'
import Route from 'react-router/lib/Route'
import CoreLayout from '../layouts/PageLayout/containers'
import Profil from './Profil'
import Dashboard from './Dashboard'

export default function createRoutes () {
  return (
    <div>
      <Route component={CoreLayout}>
        <Route path='/' component={Dashboard} />
        <Route path='/Dashboard' component={Dashboard} />
        <Route path='/Profil' component={Profil} />
        <Route path='*' component={Dashboard} />
      </Route>
    </div>
  )
}
