import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { Link } from 'react-router'
import '../asserts/css/style_profil.scss'

class Card extends Component {
  render () {
    return (
      <div className='col-lg-6 mb-4 bg-default'>
        <div className='card'>
          <div className='card-header'>
            <div className='user-progress justify-center'>
              <div className='col-sm-3 col-md-2 col-xl-1'>
                <img
                  src={this.props.cardPicture} alt=''
                  className='circle profile-photo'
                />
              </div>
              <div className='col-sm-9 col-md-10 col-xl-11'>
                <h6 className='pt-1'>{this.props.cardTitle}</h6>
                <div className='progress progress-custom'>
                  <div
                    className='progress-bar bg-primary'
                    style={{ width: '50% ' }}
                    role='progressbar'
                    aria-valuenow='50' aria-valuemin='0'
                    aria-valuemax='100'
                  />
                </div>
              </div>
            </div></div>
          <div className='card-block'>
            <p>{this.props.cardInput1}</p>
            <p>{this.props.cardInput2}</p>
            <Link to={this.props.linkTo} className='btn btn-success mr-2'>{this.props.buttonLabel}</Link>
          </div>
        </div>
      </div>
    )
  }
}

Card.propTypes = {
  cardPicture: PropTypes.string,
  cardTitle: PropTypes.string,
  cardInput1: PropTypes.string,
  cardInput2: PropTypes.string,
  buttonLabel: PropTypes.string,
  linkTo: PropTypes.string,
}

export default Card
