import React, { Component } from 'react'
import PropTypes from 'prop-types'
import '../asserts/css/style_profil.scss'
import MenuItem from './MenuItem'

class Nav extends Component {
  render () {
    return (
      <nav className='sidebar col-xs-12 col-sm-4 col-lg-3 col-xl-2'>
        <h1 className='site-title'>
          <a href='#/'> Espace EER</a></h1>
        <ul className='nav nav-pills flex-column sidebar-nav'>
          {this.props.options && this.props.options.map((o) =>
            <MenuItem id={o.id} className='nav-link' href={o.href} icon={o.icon} label={o.titre} />
          )}
          <MenuItem href='#/'
            className='purchase-button' classNameA='nav-link' label='Parler à un expert' />
        </ul>
      </nav>
    )
  }
}

Nav.propTypes = {
  options: PropTypes.array,
}

export default Nav
