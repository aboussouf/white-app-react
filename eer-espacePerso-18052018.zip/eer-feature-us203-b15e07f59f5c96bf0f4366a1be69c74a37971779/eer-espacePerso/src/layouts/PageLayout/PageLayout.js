import React from 'react'
import PropTypes from 'prop-types'
import Nav from '../../components/Nav'
import HorizontalNav from '../../components/HorizontalNav'
import Modal from '../../routes/onBoarding'
import * as user from '../../asserts/images/user1.png'

const elementsMenu = [
  { href: '#/Dashboard', icon: 'fa fa-dashboard', titre: '  Mon Espace' },
  { href: '#Profil', icon: 'fa fa-calendar-o', titre: 'Mon Profil' },
  { href: '#', icon: 'fa fa-map-marker', titre: 'Mon Agence' },
]

class PageLayout extends React.Component {
  render () {
    return (
      <div className='container-fluid' id='wrapper'>
        <div className='row'>
          <Nav
            options={elementsMenu}
          />
          <main className='col-xs-12 col-sm-8 col-lg-9 col-xl-10 pt-3 pl-4 ml-auto'>
            <HorizontalNav
              deconnect={this.props.keycloak.logout}
              pageName='Tableau de Bord'
              name={this.props.lastName + ' ' + this.props.firstName}
              picture={user}
            />
            <Modal />
            {this.props.children}
          </main>
        </div>
      </div>
    )
  }
}

PageLayout.propTypes = {
  children: PropTypes.node,
  keycloak: PropTypes.object,
  firstName: PropTypes.string,
  lastName: PropTypes.string,
}

export default PageLayout
