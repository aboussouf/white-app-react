import { fromJS } from 'immutable'

const prospectInitState = fromJS({})

function prospectReducer (state = prospectInitState, action) {
  switch (action.type) {
    case 'GET_PROSPECT_SUCCESS':
      return state.withMutations((ctx) => {
        ctx.setIn(['prospect', 'result'], fromJS(action.result))
        ctx.setIn(['lastName', 'value'], fromJS(action.result.lastName))
        ctx.setIn(['firstName', 'value'], fromJS(action.result.firstName))
        ctx.setIn(['mobile', 'value'], fromJS(action.result.numeroMobile))
        ctx.setIn(['email', 'value'], fromJS(action.result.email))
        ctx.setIn(['prospect', 'status'], 'success')
      })
    case 'GET_PROSPECT_ERROR':
      return state.withMutations((ctx) => {
        ctx.setIn(['prospect', 'result'], fromJS(action.result))
        ctx.setIn(['prospect', 'status'], 'error')
      })
    case 'ON_CHANGE':
      return state.setIn(action.key.concat(['value']), fromJS(action.newValue))
    case 'SAVE_PROSPECT_SUCCESS':
      return state.withMutations((ctx) => {
        ctx.setIn(['save', 'result'], fromJS(action.result))
        ctx.setIn(['save', 'status'], 'success')
      })
    case 'SAVE_PROSPECT_ERROR':
      return state.withMutations((ctx) => {
        ctx.setIn(['save', 'result'], fromJS(action.result))
        ctx.setIn(['save', 'status'], 'error')
      })
    case 'UPDATE_PROSPECT_SUCCESS':
      return state.withMutations((ctx) => {
        ctx.setIn(['update', 'status'], 'success')
        ctx.setIn(['prospect', 'result', 'validateOB'], true)
      })
    case 'UPDATE_PROSPECT_ERROR':
      return state.withMutations((ctx) => {
        ctx.setIn(['update', 'result'], fromJS(action.result))
        ctx.setIn(['update', 'status'], 'error')
      })
    case 'GET_STATUT_PROFESSIONNEL_SUCCESS':
      return state.withMutations((ctx) => {
        ctx.setIn(['update', 'status'], 'success')
        ctx.setIn(['prospect', 'result', 'validateOB'], true)
      })
    case 'GET_STATUT_PROFESSIONNEL_ERROR':
      return state.withMutations((ctx) => {
        ctx.setIn(['params', 'function', 'result'], fromJS(action.result))
        ctx.setIn(['params', 'function', 'status'], 'error')
      })
    case 'GET_FAMILY_SITUATION_SUCCESS':
      return state.withMutations((ctx) => {
        ctx.setIn(['params', 'familySituation', 'result'], fromJS(action.result))
        ctx.setIn(['params', 'familySituation', 'status'], 'error')
      })
    case 'GET_FAMILY_SITUATION_ERROR':
      return state.withMutations((ctx) => {
        ctx.setIn(['params', 'familySituation', 'result'], fromJS(action.result))
        ctx.setIn(['params', 'familySituation', 'status'], 'error')
      })
    case 'GET_TRANCHE_REVENU_SUCCESS':
      return state.withMutations((ctx) => {
        ctx.setIn(['params', 'revenu', 'result'], fromJS(action.result))
        ctx.setIn(['params', 'revenu', 'status'], 'error')
      })
    case 'GET_TRANCHE_REVENU_ERROR':
      return state.withMutations((ctx) => {
        ctx.setIn(['params', 'revenu', 'result'], fromJS(action.result))
        ctx.setIn(['params', 'revenu', 'status'], 'error')
      })
    default:
      return state
  }
}

export default prospectReducer
