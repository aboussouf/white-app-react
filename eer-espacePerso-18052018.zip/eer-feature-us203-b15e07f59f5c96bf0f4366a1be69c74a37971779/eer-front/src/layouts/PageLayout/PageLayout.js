import React from 'react'
import PropTypes from 'prop-types'


class PageLayout extends React.Component {
  render () {
    return (
      <div className='container-scroller'>
        <div className='container-fluid page-body-wrapper'>
          <h2>{this.props.children}</h2>
          <h3> ttttt </h3>
        </div>
      </div>
    )
  }
}

PageLayout.propTypes = {
  children: PropTypes.node,
  firstName: PropTypes.string,
  lastName: PropTypes.string,
  typeProspect: PropTypes.string,
}

export default PageLayout
