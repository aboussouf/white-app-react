import React from 'react'
import PageLayout from 'layouts/PageLayout/PageLayout'
import { shallow } from 'enzyme'

describe('(Layout) PageLayout', () => {
  let wrapper
  beforeEach(() => {
    // given
    wrapper = shallow(<PageLayout />)
  })
  it('should have 2 div', () => {
    // when
    const form = wrapper.find('div')
    // then
    expect(form).to.have.length(2)
  })

  it('should have 1 h2', () => {
    // when
    const form = wrapper.find('h2')
    // then
    expect(form).to.have.length(1)
  })
  /* let _component

  beforeEach(() => {
    _component = PageLayout.component()
  })

  it('Should define a route component', () => {
    expect(_component.type).to.equal('div')
  })

  it('renders as a <div>', () => {
    shallow(<PageLayout />).should.have.tagName('div')
  })

  it('renders its children inside of the viewport', () => {
    const Child = () => <h2>child</h2>
    shallow(
      <PageLayout>
        <Child />
      </PageLayout>
    )
      .find('.page-layout__viewport')
      .should.contain(<Child />)
  }) */
})
