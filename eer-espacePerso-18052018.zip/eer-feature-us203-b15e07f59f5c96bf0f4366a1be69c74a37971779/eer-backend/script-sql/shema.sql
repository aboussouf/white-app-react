drop sequence id_prospect_seq ;
create sequence id_prospect_seq start with 1 increment by 1;

CREATE TABLE PROSPECT(
    ID_PROSPECT BIGINT NOT NULL,
    ACCEPT_CGU BOOLEAN NOT NULL,
    BOISSON VARCHAR(255) NOT NULL,
    CODE_AGENCE VARCHAR(255) NOT NULL,
    DATE_RDV TIMESTAMP NOT NULL,
    EMAIL VARCHAR(255) NOT NULL,
    FIRST_NAME VARCHAR(255) NOT NULL,
    LAST_NAME VARCHAR(255) NOT NULL,
    NUMERO_TEL VARCHAR(255) NOT NULL,
    SEXE VARCHAR(255) NOT NULL,
    TYPE_PROSPECT VARCHAR(255) NOT NULL,
        primary key (ID_PROSPECT)
)


   drop table agence  ;
   drop table ville  ;
   drop sequence  id_ville_seq ;
  create sequence id_ville_seq start with 1 increment by 1 ;
    create table agence (
        code_agence varchar(255) not null,
        adresse_agence varchar(255),
        code_postal varchar(255),
        latitude varchar(255),
        libelle_agence varchar(255),
        longitude varchar(255),
        num_tel varchar(255),
        type_agence varchar(255),
        id_ville bigint,
        primary key (code_agence)
    ) ;
   create table ville (
        idville bigint not null,
        latitude varchar(255),
        libelle varchar(255),
        longitude varchar(255),
        primary key (idville)
    ) ;
    alter table agence
        add constraint FK_VILLE
        foreign key (id_ville)
        references ville ;
