package sg.df.prospect.dto;


import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import org.springframework.hateoas.ResourceSupport;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class AgenceDTO extends ResourceSupport implements Serializable {

    private  static  final  long serialVersionUID =  1350092881346723535L;
    @NonNull
    private String codeAgence;
    @NonNull
    private String libelleAgence;
    @NonNull
    private  String adresseAgence;
    @NonNull
    private  String numTel ;
    @NonNull
    private String typeAgence ;
    @NonNull
    private String codePostal ;
    @NonNull
    private  String latitude;
    @NonNull
    private  String longitude;

    private  VilleDTO ville;

}
