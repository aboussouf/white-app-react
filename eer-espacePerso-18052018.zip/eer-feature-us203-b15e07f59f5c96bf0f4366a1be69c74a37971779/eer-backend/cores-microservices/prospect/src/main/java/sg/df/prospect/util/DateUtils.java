package sg.df.prospect.util;

import org.apache.commons.lang.time.DateFormatUtils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {

    public static String formatDateRDV(Date dateRDV) {
       return  DateFormatUtils.ISO_DATE_FORMAT.format(dateRDV);
    }
}
