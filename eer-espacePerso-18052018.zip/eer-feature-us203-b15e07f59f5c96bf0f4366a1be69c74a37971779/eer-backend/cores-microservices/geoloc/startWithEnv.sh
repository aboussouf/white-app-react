#!/usr/bin/env bash
mvn spring-boot:run -Drun.profiles=dev

#refreshScope
#http://127.0.0.1:8082/geoloc-services/actuator/resfresh