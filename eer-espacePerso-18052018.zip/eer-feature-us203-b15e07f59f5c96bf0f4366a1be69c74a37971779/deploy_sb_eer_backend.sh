#!/bin/bash
sudo sshpass -f /home/gitlab-runner/sb-pass.txt ssh sandbox@10.6.1.42 /sandbox/udd/deploy_eer_backend.sh
