import { createSelector } from 'reselect';

const geolocsState = (state) => state.get('geolocs');

const makeSelectAgencesList = () => createSelector(
  geolocsState,
  (agenceState) => agenceState.get('agences'),
);

const makeSelectCitiesList = () => createSelector(
  geolocsState,
  (refState) => refState.toJS(),

);


export {
  makeSelectAgencesList,
  makeSelectCitiesList,
};
